# ASR10 Instrument for MPC (0.1.0, experimental, not yet run on a device)

Plays Ensoniq ASR-10 / EPS-16+ instruments from **your own** disk images. It is a separate plugin from the ASR10
insert effect and installs next to it.

**What it does:** the key map, velocity layers, sample rate, pitch and loops of the instrument. **What it does not
do yet:** envelopes, filters and LFO are not decoded, so it plays the raw samples (the INFO readout says `RAW`),
and it will not sound like the hardware. Effects are **approximations** (below). No banks, no sequences.

## Build it
Needs one of: `arm-linux-gnueabihf-g++` (`apt install g++-arm-linux-gnueabihf`), Docker, or a GitHub repo (push the
source; the *ARM build* workflow produces `ASR10-Instrument-0.1.0-mpc-armv7.zip` and the effect zip as downloads).
`./scripts/package_inst.sh` builds, runs `scripts/check_arm.sh` against the effect build, and zips.

## Install (on the MPC, as root, over SSH or Terminus)
    sh install.sh            # copies asr10_inst.so to /sdcard/vst, creates /sdcard/Ensoniq, registers the plugin
    sh uninstall.sh          # removes the plugin entry and the .so (your disk images are left alone)
The installer also copies the skin to `/sdcard/Synths/GlueBus - VST - ASR10 Instrument` (same rules as the effect's skin; **untested on a device**). Both back up `MPC.settings` first. Save your project before running either: MPC is restarted.

## Use
1. Copy disk images into `/sdcard/Ensoniq` (one level of sub-folders is scanned): `.img .iso .hfe .hda .ede .eda
   .gkh` disks and `.efe .efa` single instrument files.
2. Add **ASR10 Instrument** as an instrument on a track.
3. The skin is an ASR-10 style panel (`docs/skin-preview-instrument.png`). The display shows the instrument name, the
   disk name, then `INFO` (layers / wavesamples, `RAW` = no envelopes or filters yet), the patch and the voice mode.
   Under it the **LOAD** keys step through what you have: `DISK -` / `DISK +` pick the image, `INST -10 / -1 / +1 /
   +10` move through its instruments (the Instrument slider jumps around quickly; with 500+ instruments use the keys
   to land on one). **PATCH SELECT** 1-4 is the ASR-10 patch select, **VOICES** 31 (ASR-10) or 20 (EPS-16+),
   **DISK LIST / RESCAN** re-reads the folder after you change the files, the Volume slider sets the level. The
   same things are on the Q-Links. A step key is a toggle: each press flips it and steps once.
   **EFFECTS** OFF / ON / MORE switches the effects and scales their amount; the line under it shows what the
   instrument's stored effect is played as, e.g. `~HALL REVERB` (`~` = approximation).
4. The chosen disk, instrument, patch and volume are saved with the project.

Big CD images are fine (they are read in place); an instrument can take a few seconds to load. MIDI: notes with
velocity, sustain pedal (CC64), mod wheel (CC1, stored), pitch bend, all-notes-off (CC123).

## About the effects
Each ASR-10 instrument stores an effect (HALL REVERB, CHORUS+REVRB, DUAL DELAYS ...). The real ones are programs for the
ASR's effects chip, which this plugin does not emulate. It reads the **name** and plays ordinary reverb, chorus, delay,
phaser, tremolo, rotary, distortion or compressor algorithms with fixed defaults in that order. On the demo CD,
485 of 546 instruments that name an effect get one; EQ effects are passed through unchanged, and custom multi-effects
(TRAVEL EFX, GUITAR AMP1 ...) are not guessed at. The effect's saved settings (reverb time, mix, rates) are not
decoded, so they are not applied. Expect the same character, not the same sound.
