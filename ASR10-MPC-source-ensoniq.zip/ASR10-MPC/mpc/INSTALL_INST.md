# ASR10 Instrument for MPC (0.1.0, experimental, not yet run on a device)

Plays Ensoniq ASR-10 / EPS-16+ instruments from **your own** disk images. It is a separate plugin from the ASR10
insert effect and installs next to it.

**What it does:** the key map, velocity layers, sample rate, pitch and loops of the instrument. **What it does not
do yet:** envelopes, filters and LFO are not decoded, so it plays the raw samples (the INFO readout says `RAW`),
and it will not sound like the hardware. No effects, no banks, no sequences.

## Build it
Needs one of: `arm-linux-gnueabihf-g++` (`apt install g++-arm-linux-gnueabihf`), Docker, or a GitHub repo (push the
source; the *ARM build* workflow produces `ASR10-Instrument-0.1.0-mpc-armv7.zip` and the effect zip as downloads).
`./scripts/package_inst.sh` builds, runs `scripts/check_arm.sh` against the effect build, and zips.

## Install (on the MPC, as root, over SSH or Terminus)
    sh install.sh            # copies asr10_inst.so to /sdcard/vst, creates /sdcard/Ensoniq, registers the plugin
    sh uninstall.sh          # removes the plugin entry and the .so (your disk images are left alone)
Both back up `MPC.settings` first. Save your project before running either: MPC is restarted.

## Use
1. Copy disk images into `/sdcard/Ensoniq` (one level of sub-folders is scanned): `.img .iso .hfe .hda .ede .eda
   .gkh` disks and `.efe .efa` single instrument files.
2. Add **ASR10 Instrument** as an instrument on a track.
3. There is no skin yet, so use the plugin's parameter list or Q-Links:
   `DISK` picks the image (its name is shown), `INSTRUMENT` picks the instrument on it (name shown, `LOADING` while
   it loads), `PATCH` 1-4 is the ASR-10 patch select, `VOLUME`, `VOICES` 31 (ASR-10) or 20 (EPS-16+),
   `INFO` shows layers / wavesamples, `RESCAN` re-reads the folder after you change the files.
4. The chosen disk, instrument, patch and volume are saved with the project.

Big CD images are fine (they are read in place); an instrument can take a few seconds to load. MIDI: notes with
velocity, sustain pedal (CC64), mod wheel (CC1, stored), pitch bend, all-notes-off (CC123).
