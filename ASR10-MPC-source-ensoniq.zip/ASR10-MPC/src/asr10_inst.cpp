// ASR10 Instrument (MPC): plays Ensoniq ASR-10 / EPS-16+ instruments from the user's own disk images as a VST2
// instrument. Looks for images (.img .iso .hfe .hda .ede .eda .gkh) and single files (.efe .efa) in
// /sdcard/Ensoniq (override: environment variable ASR10_DISK_DIR), one level of sub-folders included.
//
// DISK and INSTRUMENT select what to load; loading (disk reads, parsing, up to 16 MB of audio) runs on a worker
// thread and the engine swaps the new instrument in without blocking audio. Until the envelope, filter and LFO
// values are decoded (docs/ENSONIQ_FORMATS.md section 3) instruments play as RAW samples: right keys, velocity
// layers, pitch and loops, but no envelopes or filters. The INFO readout says so.
#include "vst2.h"
#include "ensoniq/ens_instrument_file.h"
#include "engine/ens_engine.h"
#include <dirent.h>
#include <math.h>
#include <new>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>

#define ASR_EXPORT extern "C" __attribute__((visibility("default")))

namespace
{
using namespace ens;

enum { P_DISK, P_INST, P_PATCH, P_VOLUME, P_VOICES, P_INFO, P_RESCAN, P_COUNT };
const char* const kParamName[P_COUNT] { "DISK", "INSTRUMENT", "PATCH", "VOLUME", "VOICES", "INFO", "RESCAN" };
enum { S_IDLE, S_SCANNING, S_DISK, S_INST, S_READY, S_ERROR };
constexpr int kMaxFiles = 128, kMaxInsts = 700, kMaxEvents = 256;

struct FileItem { char rel[200]; char shown[28]; bool single; };
struct InstItem { Entry e; char name[14]; };
struct MidiEv { int frame; uint8_t s, a, b; };

void copyStr (void* dst, const char* src, size_t max = 32)
{
    if (! dst) return;
    const size_t n = strnlen (src, max - 1);
    memcpy (dst, src, n);
    ((char*) dst)[n] = 0;
}
bool hasExt (const char* n, const char* ext)
{
    const size_t a = strlen (n), b = strlen (ext);
    return a > b && n[a - b - 1] == '.' && strcasecmp (n + a - b, ext) == 0;
}
int kindOfFile (const char* n)      // 1 = disk image, 2 = single file, 0 = other
{
    static const char* const disk[] { "img", "iso", "hfe", "hda", "ede", "eda", "gkh" };
    static const char* const one[] { "efe", "efa" };
    for (const char* e : disk) if (hasExt (n, e)) return 1;
    for (const char* e : one) if (hasExt (n, e)) return 2;
    return 0;
}

struct Plugin
{
    AEffect fx;
    audioMasterCallback master = nullptr;
    Engine engine;
    float sr = 44100.f;

    // shared with the worker, guarded by mtx
    pthread_mutex_t mtx;
    pthread_cond_t cv;
    pthread_t th;
    bool thStarted = false, quit = false;
    char dir[200] {};
    FileItem files[kMaxFiles];
    int nFiles = 0;
    InstItem insts[kMaxInsts];
    int nInsts = 0;
    int diskSel = 0, instSel = 0;
    bool reqScan = false;
    int reqDisk = -1, reqInst = -1;
    int status = S_IDLE;
    char msg[64] {};
    char info[24] {};
    char loadedName[16] {};
    char wantDisk[200] {}, wantInst[16] {};      // restored from a project, applied after the scan / disk load

    // worker only
    Image img;
    Volume vol;
    bool haveImg = false;
    GieblerFile gf;
    bool haveGf = false;

    // control / audio side
    float volume = 0.8f, smooth = 0.8f;
    int patch = 0, voicesEps = 0;
    bool rescanHeld = false;
    MidiEv ev[kMaxEvents];
    int nEv = 0;
    char chunk[600];
};

void freeInst (Instrument* i)
{
    if (! i) return;
    i->releaseAudio();
    i->~Instrument();
    free (i);
}

// ------------------------------------------------------------------------------------------ worker
void setStatus (Plugin* p, int st, const char* m)
{
    p->status = st;
    copyStr (p->msg, m, sizeof p->msg);
}

void scanDir (const char* base, const char* rel, int depth, FileItem* out, int& n)
{
    char path[400];
    snprintf (path, sizeof path, rel[0] ? "%s/%s" : "%s%s", base, rel);
    DIR* d = opendir (path);
    if (! d) return;
    while (dirent* de = readdir (d))
    {
        if (de->d_name[0] == '.' || n >= kMaxFiles) continue;
        char r[200];
        snprintf (r, sizeof r, rel[0] ? "%s/%s" : "%s%s", rel, de->d_name);
        char full[600];
        snprintf (full, sizeof full, "%s/%s", base, r);
        struct stat st;
        if (stat (full, &st) != 0) continue;
        if (S_ISDIR (st.st_mode)) { if (depth < 1) scanDir (base, r, depth + 1, out, n); continue; }
        const int k = kindOfFile (de->d_name);
        if (! k) continue;
        FileItem& f = out[n++];
        memset (&f, 0, sizeof f);
        copyStr (f.rel, r, sizeof f.rel);
        copyStr (f.shown, de->d_name, sizeof f.shown);
        f.single = k == 2;
    }
    closedir (d);
}

void walkVolume (const Volume& v, uint32_t block, int depth, InstItem* out, int& n)
{
    Dir d; char err[96];
    if (depth > 4 || ! v.readDir (block, d, err, sizeof err)) return;
    for (int i = 0; i < d.n && n < kMaxInsts; ++i)
    {
        const Entry& e = d.e[i];
        if (e.type == FT_DIR) walkVolume (v, e.start, depth + 1, out, n);
        else if (e.type == FT_INSTRUMENT) { out[n].e = e; copyStr (out[n].name, e.name, sizeof out[n].name); ++n; }
    }
}

void doScan (Plugin* p)
{
    FileItem* tmp = (FileItem*) calloc (kMaxFiles, sizeof (FileItem));
    if (! tmp) return;
    int n = 0;
    scanDir (p->dir, "", 0, tmp, n);
    for (int i = 1; i < n; ++i)                              // insertion sort, case-insensitive
        for (int j = i; j > 0 && strcasecmp (tmp[j - 1].rel, tmp[j].rel) > 0; --j) { FileItem t = tmp[j]; tmp[j] = tmp[j - 1]; tmp[j - 1] = t; }
    pthread_mutex_lock (&p->mtx);
    memcpy (p->files, tmp, sizeof (FileItem) * (size_t) n);
    p->nFiles = n;
    int sel = 0;
    if (p->wantDisk[0]) for (int i = 0; i < n; ++i) if (strcmp (p->files[i].rel, p->wantDisk) == 0) { sel = i; break; }
    p->wantDisk[0] = 0;
    p->diskSel = sel;
    if (n > 0) p->reqDisk = sel; else setStatus (p, S_ERROR, "NO DISKS");
    pthread_mutex_unlock (&p->mtx);
    free (tmp);
}

void doDisk (Plugin* p, int k)
{
    pthread_mutex_lock (&p->mtx);
    if (k < 0 || k >= p->nFiles) { pthread_mutex_unlock (&p->mtx); return; }
    const FileItem f = p->files[k];
    setStatus (p, S_DISK, "LOADING DISK");
    pthread_mutex_unlock (&p->mtx);

    if (p->haveImg) { p->img.close(); p->haveImg = false; }
    if (p->haveGf) { p->gf.release(); p->haveGf = false; }
    InstItem* tmp = (InstItem*) calloc (kMaxInsts, sizeof (InstItem));
    if (! tmp) return;
    int n = 0; char err[128] {}; char path[420];
    snprintf (path, sizeof path, "%s/%s", p->dir, f.rel);
    bool ok = false;
    if (f.single)
    {
        if (p->gf.open (path, err, sizeof err))
        {
            p->haveGf = true;
            if (p->gf.type == FT_INSTRUMENT) { copyStr (tmp[0].name, p->gf.name, sizeof tmp[0].name); n = 1; ok = true; }
            else snprintf (err, sizeof err, "NOT AN INSTRUMENT");
        }
    }
    else if (p->img.open (path, err, sizeof err))
    {
        p->haveImg = true;
        if (p->vol.open (p->img, err, sizeof err)) { walkVolume (p->vol, 3, 0, tmp, n); ok = true; }
    }
    pthread_mutex_lock (&p->mtx);
    if (! ok || n == 0) { setStatus (p, S_ERROR, ok ? "NO INSTRUMENTS" : err); p->nInsts = 0; }
    else
    {
        memcpy (p->insts, tmp, sizeof (InstItem) * (size_t) n);
        p->nInsts = n;
        int sel = 0;
        if (p->wantInst[0]) for (int i = 0; i < n; ++i) if (strcmp (p->insts[i].name, p->wantInst) == 0) { sel = i; break; }
        p->wantInst[0] = 0;
        p->instSel = sel;
        p->reqInst = sel;
    }
    pthread_mutex_unlock (&p->mtx);
    free (tmp);
}

void doInst (Plugin* p, int k)
{
    pthread_mutex_lock (&p->mtx);
    if (k < 0 || k >= p->nInsts) { pthread_mutex_unlock (&p->mtx); return; }
    const InstItem it = p->insts[k];
    const bool single = p->haveGf && ! p->haveImg;
    setStatus (p, S_INST, "LOADING");
    pthread_mutex_unlock (&p->mtx);

    void* mem = calloc (1, sizeof (Instrument));
    Instrument* in = mem ? new (mem) Instrument() : nullptr;
    ParseInfo pi; char err[128] {};
    bool ok = false;
    if (in)
    {
        if (single) ok = parseInstrument (p->gf.data.p, p->gf.data.n, *in, pi, err, sizeof err);
        else ok = parseInstrumentEntry (p->vol, it.e, *in, pi, err, sizeof err);
    }
    if (! ok) { freeInst (in); in = nullptr; }
    else p->engine.setInstrument (in, freeInst);
    p->engine.collect (freeInst);

    pthread_mutex_lock (&p->mtx);
    if (ok)
    {
        copyStr (p->loadedName, it.name, sizeof p->loadedName);
        snprintf (p->info, sizeof p->info, "%dL %dWS RAW", pi.layers, pi.wavesamples);   // RAW: no envelopes / filters yet
        setStatus (p, S_READY, "OK");
    }
    else { p->info[0] = 0; setStatus (p, S_ERROR, err[0] ? err : "LOAD FAILED"); }
    pthread_mutex_unlock (&p->mtx);
}

void* workerMain (void* arg)
{
    Plugin* p = (Plugin*) arg;
    pthread_mutex_lock (&p->mtx);
    for (;;)
    {
        while (! p->quit && ! p->reqScan && p->reqDisk < 0 && p->reqInst < 0) pthread_cond_wait (&p->cv, &p->mtx);
        if (p->quit) break;
        if (p->reqScan) { p->reqScan = false; setStatus (p, S_SCANNING, "SCANNING"); pthread_mutex_unlock (&p->mtx); doScan (p); pthread_mutex_lock (&p->mtx); continue; }
        if (p->reqDisk >= 0) { const int k = p->reqDisk; p->reqDisk = -1; p->reqInst = -1; pthread_mutex_unlock (&p->mtx); doDisk (p, k); pthread_mutex_lock (&p->mtx); continue; }
        const int k = p->reqInst; p->reqInst = -1;
        pthread_mutex_unlock (&p->mtx); doInst (p, k); pthread_mutex_lock (&p->mtx);
    }
    pthread_mutex_unlock (&p->mtx);
    return nullptr;
}

// ------------------------------------------------------------------------------------------ plugin
void requestScan (Plugin* p) { pthread_mutex_lock (&p->mtx); p->reqScan = true; pthread_cond_signal (&p->cv); pthread_mutex_unlock (&p->mtx); }

int stepIndex (float norm, int n) { if (n <= 1) return 0; int k = (int) floorf (norm * (float) (n - 1) + 0.5f); return k < 0 ? 0 : (k >= n ? n - 1 : k); }

void setParam (Plugin* p, int i, float v)
{
    if (v < 0.f) v = 0.f;
    if (v > 1.f) v = 1.f;
    switch (i)
    {
        case P_DISK:
        {
            pthread_mutex_lock (&p->mtx);
            const int k = stepIndex (v, p->nFiles);
            if (p->nFiles > 0 && k != p->diskSel) { p->diskSel = k; p->reqDisk = k; p->wantInst[0] = 0; pthread_cond_signal (&p->cv); }
            pthread_mutex_unlock (&p->mtx);
            break;
        }
        case P_INST:
        {
            pthread_mutex_lock (&p->mtx);
            const int k = stepIndex (v, p->nInsts);
            if (p->nInsts > 0 && k != p->instSel) { p->instSel = k; p->reqInst = k; pthread_cond_signal (&p->cv); }
            pthread_mutex_unlock (&p->mtx);
            break;
        }
        case P_PATCH: p->patch = (int) floorf (v * 3.f + 0.5f); p->engine.patchSelect (p->patch); break;
        case P_VOLUME: p->volume = v; break;
        case P_VOICES: p->voicesEps = v > 0.5f ? 1 : 0; p->engine.setMode (p->voicesEps ? MODE_EPS16 : MODE_ASR10); break;
        case P_RESCAN:
            if (v > 0.5f && ! p->rescanHeld) requestScan (p);
            p->rescanHeld = v > 0.5f;
            break;
        default: break;
    }
}

float getParam (Plugin* p, int i)
{
    float r = 0.f;
    switch (i)
    {
        case P_DISK: pthread_mutex_lock (&p->mtx); r = p->nFiles > 1 ? (float) p->diskSel / (float) (p->nFiles - 1) : 0.f; pthread_mutex_unlock (&p->mtx); break;
        case P_INST: pthread_mutex_lock (&p->mtx); r = p->nInsts > 1 ? (float) p->instSel / (float) (p->nInsts - 1) : 0.f; pthread_mutex_unlock (&p->mtx); break;
        case P_PATCH: r = (float) p->patch / 3.f; break;
        case P_VOLUME: r = p->volume; break;
        case P_VOICES: r = (float) p->voicesEps; break;
        case P_RESCAN: r = p->rescanHeld ? 1.f : 0.f; break;
        default: break;
    }
    return r;
}

void display (Plugin* p, int i, char* out, size_t max)
{
    out[0] = 0;
    pthread_mutex_lock (&p->mtx);
    switch (i)
    {
        case P_DISK:
            if (p->nFiles == 0) snprintf (out, max, "%s", p->status == S_SCANNING ? "SCANNING" : "NO DISKS");
            else snprintf (out, max, "%s", p->files[p->diskSel].shown);
            break;
        case P_INST:
            if (p->status == S_DISK || p->status == S_INST || p->status == S_SCANNING) snprintf (out, max, "LOADING");
            else if (p->status == S_ERROR) copyStr (out, p->msg, max);
            else if (p->nInsts > 0) snprintf (out, max, "%s", p->insts[p->instSel].name);
            else snprintf (out, max, "NONE");
            break;
        case P_PATCH: snprintf (out, max, "%d", p->patch + 1); break;
        case P_VOLUME: snprintf (out, max, "%d", (int) (p->volume * 127.f + 0.5f)); break;
        case P_VOICES: snprintf (out, max, p->voicesEps ? "20 EPS16" : "31 ASR10"); break;
        case P_INFO: snprintf (out, max, "%s", p->info[0] ? p->info : "-"); break;
        case P_RESCAN: snprintf (out, max, "%s", p->rescanHeld ? "..." : "PRESS"); break;
        default: break;
    }
    pthread_mutex_unlock (&p->mtx);
}

void midi (Plugin* p, const MidiEv& m)
{
    const uint8_t cmd = m.s & 0xF0;
    if (cmd == 0x90 && m.b > 0) p->engine.noteOn (m.a & 127, m.b & 127);
    else if (cmd == 0x80 || cmd == 0x90) p->engine.noteOff (m.a & 127);
    else if (cmd == 0xB0)
    {
        if (m.a == 1) p->engine.modWheel ((float) m.b / 127.f);
        else if (m.a == 64) p->engine.sustain (m.b >= 64);
        else if (m.a == 123 || m.a == 120) p->engine.allNotesOff();
    }
    else if (cmd == 0xE0) p->engine.pitchBend ((float) (((m.b & 127) << 7 | (m.a & 127)) - 8192) / 8192.f);
}

void process (Plugin* p, float* outL, float* outR, int n)
{
    int pos = 0, e = 0;
    while (pos < n)
    {
        while (e < p->nEv && p->ev[e].frame <= pos) midi (p, p->ev[e++]);
        int end = n < pos + 256 ? n : pos + 256;
        if (e < p->nEv && p->ev[e].frame < end) end = p->ev[e].frame;
        if (end <= pos) end = pos + 1;
        p->engine.render (outL + pos, outR + pos, end - pos);
        pos = end;
    }
    while (e < p->nEv) midi (p, p->ev[e++]);
    p->nEv = 0;
    const float g = p->volume * p->volume;                     // audio-taper volume, smoothed against zipper noise
    for (int i = 0; i < n; ++i)
    {
        p->smooth += (g - p->smooth) * 0.002f;
        outL[i] *= p->smooth; outR[i] *= p->smooth;
    }
}

void processReplacing (AEffect* e, float**, float** out, int32_t n) { process ((Plugin*) e->object, out[0], out[1], n); }
void processAccumulating (AEffect* e, float** in, float** out, int32_t n)
{
    float tl[256], tr[256];
    for (int32_t pos = 0; pos < n; pos += 256)
    {
        const int32_t m = (n - pos) < 256 ? (n - pos) : 256;
        process ((Plugin*) e->object, tl, tr, m);
        for (int32_t i = 0; i < m; ++i) { out[0][pos + i] += tl[i]; out[1][pos + i] += tr[i]; }
    }
    (void) in;
}
void setParameter (AEffect* e, int32_t i, float v) { if (i >= 0 && i < P_COUNT) setParam ((Plugin*) e->object, i, v); }
float getParameter (AEffect* e, int32_t i) { return (i >= 0 && i < P_COUNT) ? getParam ((Plugin*) e->object, i) : 0.f; }

int32_t makeChunk (Plugin* p)
{
    pthread_mutex_lock (&p->mtx);
    const char* disk = p->nFiles ? p->files[p->diskSel].rel : "";
    const char* inst = p->nInsts ? p->insts[p->instSel].name : "";
    const int n = snprintf (p->chunk, sizeof p->chunk, "ASRI1\ndisk=%s\ninst=%s\npatch=%d\nvol=%.3f\nvoices=%d\n", disk, inst, p->patch, (double) p->volume, p->voicesEps);
    pthread_mutex_unlock (&p->mtx);
    return n < (int) sizeof p->chunk ? n : (int) sizeof p->chunk - 1;
}

bool field (const char* text, const char* key, char* out, size_t max)
{
    const char* a = strstr (text, key);
    if (! a || (a != text && a[-1] != '\n')) return false;
    a += strlen (key);
    size_t k = 0;
    while (a[k] && a[k] != '\n' && k + 1 < max) { out[k] = a[k]; ++k; }
    out[k] = 0;
    return true;
}

void applyChunk (Plugin* p, const void* data, int32_t size)
{
    if (! data || size < 6 || size > 2000) return;
    char text[700];
    const size_t n = (size_t) size < sizeof text - 1 ? (size_t) size : sizeof text - 1;
    memcpy (text, data, n); text[n] = 0;
    if (strncmp (text, "ASRI1\n", 6) != 0) return;
    char v[200];
    if (field (text, "patch=", v, sizeof v)) setParam (p, P_PATCH, (float) atoi (v) / 3.f);
    if (field (text, "vol=", v, sizeof v)) { p->volume = (float) atof (v); p->smooth = p->volume * p->volume; }
    if (field (text, "voices=", v, sizeof v)) setParam (p, P_VOICES, (float) atoi (v));
    pthread_mutex_lock (&p->mtx);
    if (field (text, "disk=", v, sizeof v)) copyStr (p->wantDisk, v, sizeof p->wantDisk);
    if (field (text, "inst=", v, sizeof v)) copyStr (p->wantInst, v, sizeof p->wantInst);
    p->reqScan = true;                                    // rescan, then select the saved disk and instrument by name
    pthread_cond_signal (&p->cv);
    pthread_mutex_unlock (&p->mtx);
}

void closePlugin (Plugin* p)
{
    if (p->thStarted)
    {
        pthread_mutex_lock (&p->mtx); p->quit = true; pthread_cond_signal (&p->cv); pthread_mutex_unlock (&p->mtx);
        pthread_join (p->th, nullptr);
    }
    p->engine.shutdown (freeInst);
    if (p->haveImg) p->img.close();
    if (p->haveGf) p->gf.release();
    pthread_mutex_destroy (&p->mtx); pthread_cond_destroy (&p->cv);
    p->~Plugin();
    free (p);                                             // AEffect is embedded in Plugin
}

intptr_t dispatcher (AEffect* e, int32_t op, int32_t idx, intptr_t val, void* ptr, float opt)
{
    Plugin* p = (Plugin*) e->object;
    switch (op)
    {
        case effClose:            closePlugin (p); return 0;
        case effGetProgramName:   copyStr (ptr, "ASR10 Instrument"); return 0;
        case effGetProgramNameIndexed: if (idx != 0) return 0; copyStr (ptr, "ASR10 Instrument"); return 1;
        case effGetParamName:     if (idx >= 0 && idx < P_COUNT) copyStr (ptr, kParamName[idx]); return 0;
        case effGetParamLabel:    copyStr (ptr, ""); return 0;
        case effGetParamDisplay:  if (idx >= 0 && idx < P_COUNT && ptr) { char b[40]; display (p, idx, b, sizeof b); copyStr (ptr, b, 28); } return 0;
        case effCanBeAutomated:   return (idx >= 0 && idx < P_COUNT && idx != P_INFO) ? 1 : 0;
        case effSetSampleRate:    if (opt > 1000.f) { p->sr = opt; p->engine.prepare (opt); } return 0;
        case effMainsChanged:     if (val) p->engine.reset(); return 0;
        case effProcessEvents:
        {
            const VstEvents* evs = (const VstEvents*) ptr;
            if (! evs) return 1;
            for (int32_t i = 0; i < evs->numEvents && p->nEv < kMaxEvents; ++i)
            {
                const VstEvent* v = evs->events[i];
                if (! v || v->type != kVstMidiType) continue;
                const VstMidiEvent* m = (const VstMidiEvent*) v;
                p->ev[p->nEv++] = { m->deltaFrames < 0 ? 0 : m->deltaFrames, (uint8_t) m->midiData[0], (uint8_t) m->midiData[1], (uint8_t) m->midiData[2] };
            }
            return 1;
        }
        case effGetChunk: { const int32_t n = makeChunk (p); if (ptr) *(void**) ptr = p->chunk; return n; }
        case effSetChunk:         applyChunk (p, ptr, (int32_t) val); return 0;
        case effGetEffectName:
        case effGetProductString: copyStr (ptr, "ASR10 Instrument"); return 1;
        case effGetVendorString:  copyStr (ptr, "GlueBus"); return 1;
        case effGetVendorVersion: return 1000;
        case effGetPlugCategory:  return kPlugCategSynth;
        case effGetVstVersion:    return 2400;
        case effGetTailSize:      return 0;
        case effSetProcessPrecision: return val == 0 ? 1 : 0;
        case effCanDo:
            if (ptr && (strcmp ((const char*) ptr, "receiveVstEvents") == 0 || strcmp ((const char*) ptr, "receiveVstMidiEvent") == 0)) return 1;
            return 0;
        default: return 0;
    }
}
} // namespace

ASR_EXPORT AEffect* VSTPluginMain (audioMasterCallback master)
{
    void* mem = calloc (1, sizeof (Plugin));                // no operator new: keeps libstdc++ out of the link
    if (! mem) return nullptr;
    Plugin* p = new (mem) Plugin();
    p->master = master;
    const char* dir = getenv ("ASR10_DISK_DIR");
    copyStr (p->dir, dir && dir[0] ? dir : "/sdcard/Ensoniq", sizeof p->dir);
    pthread_mutex_init (&p->mtx, nullptr);
    pthread_cond_init (&p->cv, nullptr);
    p->engine.prepare (p->sr);
    p->thStarted = pthread_create (&p->th, nullptr, workerMain, p) == 0;
    if (! p->thStarted) setStatus (p, S_ERROR, "NO THREAD");
    else requestScan (p);

    AEffect& fx = p->fx;
    fx.magic = kEffectMagic;
    fx.dispatcher = dispatcher;
    fx.process = processAccumulating;
    fx.processReplacing = processReplacing;
    fx.setParameter = setParameter;
    fx.getParameter = getParameter;
    fx.numPrograms = 1;
    fx.numParams = P_COUNT;
    fx.numInputs = 0;
    fx.numOutputs = 2;
    fx.flags = effFlagsCanReplacing | effFlagsIsSynth | effFlagsProgramChunks;
    fx.ioRatio = 1.f;
    fx.object = p;
    fx.uniqueID = ('A' << 24) | ('S' << 16) | ('R' << 8) | 'I';     // 'ASRI'
    fx.version = 1000;
    return &fx;
}
