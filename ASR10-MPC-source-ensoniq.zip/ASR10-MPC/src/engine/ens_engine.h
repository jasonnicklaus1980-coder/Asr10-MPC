// Sample playback engine for EPS-16+ / ASR-10 instruments (ens::Instrument). Realtime-safe: no allocation, no
// locks, no file access on the audio thread. No libstdc++ (plugin links only libc / libm).
//
// Per voice, in the order the hardware does it:
//   wavesample read at its own sample rate, pitch = read rate, LINEAR interpolation and no band-limiting
//   (OTTO chip behaviour per MAME es5506.cpp: pitching up aliases, pitching down images, as on the hardware)
//   > loop handling (5 Ensoniq loop modes) > OTTO 4-pole filter (2 cutoffs, 4 modes, no resonance)
//   > amplitude envelope (velocity picks between soft and hard levels) > pan
// Mix > 16-bit DAC rounding > master volume.
//
// Threads: noteOn / noteOff / controllers / render() on the audio thread. setInstrument() on one other thread
// (the loader). An instrument handed over is swapped in at the start of the next render(); the instrument it
// replaces is parked in one of two "retired" slots and freed by the loader on its next setInstrument() or
// collect(). Two slots are enough: the loader empties both before every hand-over, so at most one swap can
// land between its collect and its hand-over.
#pragma once
#include "../ensoniq/ens_instrument.h"
#include "../dsp/otto_filter.h"
#include <atomic>

namespace ens
{
enum EngineMode { MODE_ASR10 = 0, MODE_EPS16 = 1 };
constexpr int kMaxVoices = 31;                       // ASR-10: 31 voices; EPS-16+: 20
inline int voicesFor (EngineMode m) { return m == MODE_ASR10 ? 31 : 20; }

struct EnvRun
{
    float level = 0.f, step = 0.f;
    int stage = 0;                                   // 0-3 moving to level stage+1, 4 sustain, 5 release, 6 done
    int left = 0;                                    // samples left in this stage
    float lv[5] {}, tm[4] {}, rel = 0.f;
    void start (const Envelope& e, float vel01, float sr);
    void release (float sr);
    inline float next();
    bool done() const { return stage >= 6; }
private:
    void enter (int s, float sr);
    float sr_ = 44100.f;
};

struct Voice
{
    bool active = false;
    const WaveSample* ws = nullptr;
    int layer = -1;
    uint8_t key = 0, vel = 0;
    uint32_t age = 0;
    bool held = false, sustained = false, released = false;
    double pos = 0.0;
    int dir = 1;
    float kill = 0.f, killStep = 0.f;                // > 0: fading out after a steal (no click)
    EnvRun amp, filt, pitch;
    otto::Filter filter;
    float lfoPhase = 0.f, lfoAge = 0.f, noise = 0.f;
    uint32_t rng = 1;
    float inc = 0.f, k1 = 1.f, k2 = 0.f, gainL = 0.f, gainR = 0.f;
    int ctl = 0;                                     // samples until the next control-rate update
};

class Engine
{
public:
    void prepare (float hostRate);                   // audio thread stopped
    void reset();                                    // all voices off
    void setMode (EngineMode m) { mode.store ((int) m); }
    EngineMode getMode() const { return (EngineMode) mode.load(); }

    // loader thread
    typedef void (*FreeFn) (Instrument*);
    void setInstrument (Instrument* inst, FreeFn freeFn);   // takes ownership; nullptr = silence
    void collect (FreeFn freeFn);                           // free instruments the audio thread let go of
    void shutdown (FreeFn freeFn);                          // audio stopped: free everything

    // audio thread
    void noteOn (uint8_t key, uint8_t vel);
    void noteOff (uint8_t key);
    void allNotesOff();
    void sustain (bool on);
    void pitchBend (float minus1to1) { bend = minus1to1; }
    void modWheel (float zeroTo1) { wheel = zeroTo1; }
    void patchSelect (int zeroTo3) { patch = zeroTo3 & 3; }
    void masterVolumeDb (float db);
    void render (float* outL, float* outR, int n);   // replaces the output
    int activeVoices() const;
    const Instrument* current() const { return cur; }

private:
    void swapIn();
    void startVoice (int layer, const WaveSample& w, uint8_t key, uint8_t vel);
    Voice* allocVoice();
    void control (Voice& v);
    inline float readSample (Voice& v, bool& ended);
    void releaseVoice (Voice& v);
    bool layerOn (int l) const;

    float sr = 44100.f;
    std::atomic<int> mode { MODE_ASR10 };
    std::atomic<Instrument*> pending { nullptr };
    std::atomic<Instrument*> retired[2] { { nullptr }, { nullptr } };
    Instrument* cur = nullptr;
    Voice voice[kMaxVoices];
    uint32_t clock = 0;
    bool pedal = false;
    float bend = 0.f, wheel = 0.f, master = 1.f;
    int patch = 0;
    uint8_t keyVel[128] {};                          // note-on velocity per key, for release-triggered layers
};
} // namespace ens
