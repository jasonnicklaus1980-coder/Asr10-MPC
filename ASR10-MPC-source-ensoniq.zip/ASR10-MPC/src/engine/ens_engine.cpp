// Sample playback engine. See ens_engine.h.
#include "ens_engine.h"
#include <cmath>
#include <cstring>

namespace ens
{
static Instrument gSilence;                          // stands for "no instrument" in the pending slot
static constexpr int kCtl = 16;                      // control-rate period (samples): pitch, filter, LFO
static constexpr float kHeadroom = 0.5f;             // mix gain before the 16-bit DAC (chosen, not measured)
static constexpr float kFcOpen = 19500.f, kFcOff = 21.f;

static inline float clampf (float x, float lo, float hi) { return x < lo ? lo : (x > hi ? hi : x); }
static inline float q16 (float x)                    // 16-bit DAC: clip, round
{
    float c = std::floor (x * 32768.f + 0.5f);
    c = c < -32768.f ? -32768.f : (c > 32767.f ? 32767.f : c);
    return c * (1.f / 32768.f);
}

// ---------------------------------------------------------------- envelope ----------------------------------
void EnvRun::start (const Envelope& e, float vel01, float sr)
{
    sr_ = sr;
    for (int i = 0; i < 5; ++i) lv[i] = e.softLevel[i] + (e.hardLevel[i] - e.softLevel[i]) * vel01;
    for (int i = 0; i < 4; ++i) tm[i] = e.time[i] < 0.f ? 0.f : e.time[i];
    tm[0] *= 1.f - clampf (e.attackVelScale, 0.f, 1.f) * vel01;
    rel = e.release < 0.f ? 0.f : e.release;
    level = lv[0];
    enter (0, sr);
}

void EnvRun::enter (int s, float sr)
{
    stage = s;
    if (s < 4)
    {
        const int n = (int) std::lround (tm[s] * sr);
        left = n < 1 ? 1 : n;
        step = (lv[s + 1] - level) / (float) left;
    }
    else { level = lv[4]; step = 0.f; left = 0; }
}

void EnvRun::release (float sr)
{
    if (stage >= 5) return;
    const int n = (int) std::lround (rel * sr);
    left = n < 1 ? 1 : n;
    step = -level / (float) left;
    stage = 5;
}

inline float EnvRun::next()
{
    if (stage < 4)
    {
        level += step;
        if (--left <= 0) { level = lv[stage + 1]; enter (stage + 1, sr_); }
    }
    else if (stage == 5)
    {
        level += step;
        if (--left <= 0) { level = 0.f; stage = 6; }
    }
    return level;
}

// ---------------------------------------------------------------- engine ------------------------------------
void Engine::prepare (float hostRate)
{
    sr = hostRate > 1000.f ? hostRate : 44100.f;
    reset();
}

void Engine::reset()
{
    for (auto& v : voice) v = Voice();
    pedal = false; bend = 0.f; wheel = 0.f;
}

void Engine::masterVolumeDb (float db) { master = std::pow (10.f, db / 20.f); }

void Engine::collect (FreeFn freeFn)
{
    for (auto& r : retired) { Instrument* p = r.exchange (nullptr); if (p) freeFn (p); }
}

void Engine::setInstrument (Instrument* inst, FreeFn freeFn)
{
    collect (freeFn);
    if (inst) inst->sanitize();
    Instrument* prev = pending.exchange (inst ? inst : &gSilence);
    if (prev && prev != &gSilence) freeFn (prev);   // handed over earlier but never taken: audio never saw it
}

void Engine::shutdown (FreeFn freeFn)
{
    Instrument* p = pending.exchange (nullptr);
    if (p && p != &gSilence) freeFn (p);
    collect (freeFn);
    if (cur) freeFn (cur);
    cur = nullptr;
    reset();
}

void Engine::swapIn()
{
    Instrument* p = pending.exchange (nullptr);
    if (! p) return;
    for (auto& v : voice) v.active = false;
    Instrument* old = cur;
    cur = p == &gSilence ? nullptr : p;
    if (! old) return;
    for (auto& r : retired)
    {
        Instrument* expected = nullptr;
        if (r.compare_exchange_strong (expected, old)) return;
    }
    // unreachable with one loader thread (see ens_engine.h); keeping it playing is safer than freeing here
    cur = old;
}

bool Engine::layerOn (int l) const
{
    return cur && l < cur->numLayers && cur->layer[l].enabled && (cur->patchSelectMask[patch] >> l) & 1;
}

Voice* Engine::allocVoice()
{
    const int nv = voicesFor ((EngineMode) mode.load());
    Voice* best = nullptr;
    for (int i = 0; i < nv; ++i) if (! voice[i].active) return &voice[i];
    for (int i = 0; i < nv; ++i)                   // steal: oldest released voice first, else the oldest
        if (voice[i].released && (! best || voice[i].age < best->age)) best = &voice[i];
    if (best) return best;
    for (int i = 0; i < nv; ++i) if (! best || voice[i].age < best->age) best = &voice[i];
    return best;
}

void Engine::startVoice (int l, const WaveSample& w, uint8_t key, uint8_t vel)
{
    if (! w.data || w.end <= w.start + 1) return;
    Voice* v = nullptr;
    if (cur->layer[l].mono)                        // mono layer: the new note takes over the layer's voice
        for (int i = 0; i < kMaxVoices; ++i) if (voice[i].active && voice[i].layer == l) { v = &voice[i]; break; }
    if (! v) v = allocVoice();
    if (! v) return;
    *v = Voice();
    v->active = true; v->ws = &w; v->layer = l; v->key = key; v->vel = vel; v->age = ++clock;
    v->held = true;
    v->dir = w.loop == LOOP_OFF_BACKWARD ? -1 : 1;
    v->pos = w.loop == LOOP_OFF_BACKWARD ? (double) (w.end - 1) : (double) w.start;
    const float v01 = (float) vel / 127.f;
    v->amp.start (w.ampEnv, v01, sr);
    v->filt.start (w.filterEnv, v01, sr);
    v->pitch.start (w.pitchEnv, v01, sr);
    v->rng = 0x9E3779B9u ^ (uint32_t) (key * 2654435761u) ^ clock;
    const float g = std::pow (10.f, (w.volumeDb + (w.boost ? 12.f : 0.f)) / 20.f);
    const float pa = (clampf (w.pan, -1.f, 1.f) + 1.f) * 0.25f * 3.14159265f;   // constant-power pan
    v->gainL = g * std::cos (pa); v->gainR = g * std::sin (pa);
    v->ctl = 0;
}

void Engine::noteOn (uint8_t key, uint8_t vel)
{
    key &= 127;
    if (vel == 0) { noteOff (key); return; }
    swapIn();                                     // a note in the same block as a freshly loaded instrument must not be lost
    keyVel[key] = vel;
    if (! cur) return;
    for (int l = 0; l < cur->numLayers; ++l)
    {
        const Layer& L = cur->layer[l];
        if (! layerOn (l) || L.triggerOnRelease || vel < L.velLo || vel > L.velHi) continue;
        if (L.hasKeyMap)                              // disk instruments: the key map picks the wavesample
        {
            if (L.keyMap[key]) startVoice (l, cur->ws[L.keyMap[key] - 1], key, vel);
            continue;
        }
        for (int i = 0; i < L.numWs; ++i)
        {
            const WaveSample& w = cur->ws[L.firstWs + i];
            if (key >= w.keyLo && key <= w.keyHi) { startVoice (l, w, key, vel); break; }   // one per layer
        }
    }
}

void Engine::releaseVoice (Voice& v)
{
    v.released = true; v.held = false; v.sustained = false;
    v.amp.release (sr); v.filt.release (sr); v.pitch.release (sr);
}

void Engine::noteOff (uint8_t key)
{
    key &= 127;
    for (auto& v : voice)
        if (v.active && v.key == key && v.held)
        {
            if (pedal) { v.held = false; v.sustained = true; }
            else releaseVoice (v);
        }
    if (! cur) return;
    const uint8_t vel = keyVel[key] ? keyVel[key] : 64;
    for (int l = 0; l < cur->numLayers; ++l)       // note-off layers sound when the key goes up
    {
        const Layer& L = cur->layer[l];
        if (! layerOn (l) || ! L.triggerOnRelease || vel < L.velLo || vel > L.velHi) continue;
        if (L.hasKeyMap)
        {
            if (L.keyMap[key]) { startVoice (l, cur->ws[L.keyMap[key] - 1], key, vel); for (auto& v : voice) if (v.active && v.age == clock) v.held = false; }
            continue;
        }
        for (int i = 0; i < L.numWs; ++i)
        {
            const WaveSample& w = cur->ws[L.firstWs + i];
            if (key >= w.keyLo && key <= w.keyHi)
            {
                startVoice (l, w, key, vel);
                for (auto& v : voice) if (v.active && v.age == clock) v.held = false;   // runs to sustain, then ends
                break;
            }
        }
    }
}

void Engine::allNotesOff() { for (auto& v : voice) if (v.active) releaseVoice (v); pedal = false; }

void Engine::sustain (bool on)
{
    pedal = on;
    if (! on) for (auto& v : voice) if (v.active && v.sustained && ! v.held) releaseVoice (v);
}

int Engine::activeVoices() const { int n = 0; for (auto& v : voice) n += v.active ? 1 : 0; return n; }

void Engine::control (Voice& v)
{
    const WaveSample& w = *v.ws;
    // LFO (advanced by one control period)
    const float dt = (float) kCtl / sr;
    v.lfoAge += dt;
    float ph = v.lfoPhase + w.lfoRate * dt;
    const bool wrapped = ph >= 1.f;
    ph -= std::floor (ph);
    v.lfoPhase = ph;
    if (wrapped || v.lfoAge <= dt)
    {
        v.rng = v.rng * 1664525u + 1013904223u;
        v.noise = (float) (v.rng >> 8) / 8388608.f - 1.f;
    }
    float lfo;
    switch (w.lfoWave)
    {
        case LFO_SINE:     lfo = std::sin (6.2831853f * ph); break;
        case LFO_SAW_UP:   lfo = 2.f * ph - 1.f; break;
        case LFO_SAW_DOWN: lfo = 1.f - 2.f * ph; break;
        case LFO_SQUARE:   lfo = ph < 0.5f ? 1.f : -1.f; break;
        case LFO_NOISE:    lfo = v.noise; break;
        default:           lfo = 4.f * std::fabs (ph - 0.5f) - 1.f; break;
    }
    const float fade = w.lfoDelay > 0.f ? clampf (v.lfoAge / w.lfoDelay, 0.f, 1.f) : 1.f;   // delay = fade-in
    const float cents = w.fineCents + v.pitch.level * w.pitchEnvCents
                      + lfo * fade * (w.lfoPitchCents + wheel * w.lfoModWheelCents);
    const float semis = (float) ((int) v.key - (int) w.rootKey) + cents * 0.01f + bend * w.bendRange;
    v.inc = (w.sampleRate / sr) * std::exp2 (semis / 12.f);

    // filter: cutoffs follow the filter envelope and the keyboard
    const float keyOct = ((float) v.key - (float) w.rootKey) / 12.f;
    const float f1 = w.fc1 * std::exp2 (v.filt.level * w.fc1EnvOct + keyOct * w.fc1KeyTrack);
    const float f2 = w.fc2 * std::exp2 (v.filt.level * w.fc2EnvOct);
    const bool hpModes = w.filterMode <= 1;
    v.k1 = f1 >= kFcOpen ? 1.f : otto::onePoleK (clampf (f1, 20.f, 0.49f * sr), sr);
    v.k2 = hpModes ? (f2 <= kFcOff ? 0.f : otto::onePoleK (clampf (f2, 20.f, 0.49f * sr), sr))
                   : (f2 >= kFcOpen ? 1.f : otto::onePoleK (clampf (f2, 20.f, 0.49f * sr), sr));
}

// One output sample of a voice's wavesample and the read head's next position. OTTO: linear interpolation
// between the two neighbouring samples, nothing else (so pitching up aliases, as on the hardware).
inline float Engine::readSample (Voice& v, bool& ended)
{
    const WaveSample& w = *v.ws;
    const bool looping = w.loop == LOOP_FORWARD || w.loop == LOOP_BIDIRECTIONAL || (w.loop == LOOP_RELEASE && ! v.released);
    const double lsF = w.loopStartF >= 0.0 ? w.loopStartF : (double) w.loopStart;
    const double leF = w.loopEndF >= 0.0 ? w.loopEndF : (double) w.loopEnd;
    double p = v.pos;
    long i = (long) std::floor (p);
    const float f = (float) (p - (double) i);
    long j = i + 1;
    // The interpolation neighbour of the last sample before the loop end is normally real data (hardware
    // instruments store a few samples past the loop end). Only where the data stops does it wrap to the loop start.
    if (looping && w.loop != LOOP_BIDIRECTIONAL && j >= (long) w.end) j -= (long) w.loopEnd - (long) w.loopStart;
    const long lo = (long) w.start, hi = (long) w.end - 1;
    i = i < lo ? lo : (i > hi ? hi : i);
    j = j < lo ? lo : (j > hi ? hi : j);
    const float a = w.data[i], b = w.data[j];
    const float s = (a + f * (b - a)) * (1.f / 32768.f);

    p += (double) v.inc * v.dir;
    switch (w.loop)
    {
        case LOOP_OFF_FORWARD:  if (p >= (double) hi) ended = true; break;
        case LOOP_OFF_BACKWARD: if (p < (double) lo) ended = true; break;
        case LOOP_RELEASE:
            if (v.released) { if (p >= (double) hi) ended = true; break; }
            __attribute__ ((fallthrough));   // loop while held
        case LOOP_FORWARD:
        {
            const double len = leF - lsF;
            while (p >= leF) p -= len;
            break;
        }
        case LOOP_BIDIRECTIONAL:
        {
            const double a0 = (double) w.loopStart, a1 = (double) (w.loopEnd - 1);
            for (int guard = 0; guard < 8; ++guard)
            {
                if (v.dir > 0 && p > a1) { p = 2.0 * a1 - p; v.dir = -1; }
                else if (v.dir < 0 && p < a0) { p = 2.0 * a0 - p; v.dir = 1; }
                else break;
            }
            // the part before the loop plays normally; only a huge step can still overshoot the loop
            if (p > a1) p = a1;
            if (v.dir < 0 && p < a0) p = a0;
            break;
        }
    }
    v.pos = p;
    return s;
}

void Engine::render (float* outL, float* outR, int n)
{
    swapIn();
    if (n <= 0) return;
    std::memset (outL, 0, sizeof (float) * (size_t) n);
    std::memset (outR, 0, sizeof (float) * (size_t) n);
    for (auto& v : voice)
    {
        if (! v.active) continue;
        const WaveSample& w = *v.ws;
        for (int i = 0; i < n; ++i)
        {
            if (v.ctl-- <= 0) { control (v); v.ctl = kCtl - 1; }
            bool ended = false;
            float x = readSample (v, ended);
            x = v.filter.run (x, w.filterMode, v.k1, v.k2);
            const float a = v.amp.next();
            v.filt.next(); v.pitch.next();
            outL[i] += x * a * v.gainL;
            outR[i] += x * a * v.gainR;
            if (! v.held && ! v.sustained && ! v.released && v.amp.stage == 4) releaseVoice (v);   // note-off layers
            if (ended || v.amp.done()) { v.active = false; break; }
        }
    }
    for (int i = 0; i < n; ++i)
    {
        outL[i] = q16 (outL[i] * kHeadroom) * master;
        outR[i] = q16 (outR[i] * kHeadroom) * master;
    }
}
} // namespace ens
