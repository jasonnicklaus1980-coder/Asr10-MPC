// Ensoniq bank parser. See ens_bank.h.
#include "ens_bank.h"
#include <stdio.h>
#include <string.h>

namespace ens
{
static void setErr (char* err, size_t max, const char* msg)
{
    if (err && max) { strncpy (err, msg, max - 1); err[max - 1] = 0; }
}
static void wordText (const uint8_t* p, int chars, char* out)   // one character per 16-bit word, high byte
{
    for (int k = 0; k < chars; ++k) out[k] = (p[2 * k] >= 32 && p[2 * k] < 127) ? (char) p[2 * k] : ' ';
    out[chars] = 0;
    for (int k = chars - 1; k >= 0 && out[k] == ' '; --k) out[k] = 0;
}

bool Bank::parse (const uint8_t* d, size_t n, uint8_t fileType, char* err, size_t errMax)
{
    if (! isBankType (fileType)) { setErr (err, errMax, "not a bank file type"); return false; }
    const size_t rec = fileType == FT_ASR_BANK ? 28 : 16;
    if (n < 0x22 + 9 * rec) { setErr (err, errMax, "bank file too short"); return false; }
    type = fileType;
    wordText (d + 0x08, 12, name);
    mask = d[0x20];
    for (int j = 0; j < 9; ++j)
    {
        const uint8_t* r = d + 0x22 + (size_t) j * rec;
        BankRef& b = j < 8 ? inst[j] : song;
        b = BankRef();
        if (r[0] >= 0x80) { b.kind = j < 8 ? BankRef::COPY : BankRef::NONE; b.copyOf = (r[0] & 0x0F) + 1; continue; }
        if (r[0] == 0x7F) { b.kind = BankRef::DELETED; continue; }
        const int depth = r[0];
        if (4 + 2 * (size_t) depth >= rec || depth > 11) { b.kind = BankRef::NONE; continue; }   // damaged record
        b.kind = BankRef::REF;
        b.media = r[2];
        for (int k = 0; k < 7; ++k) b.label[k] = (r[3 + 2 * k] >= 32 && r[3 + 2 * k] < 127) ? (char) r[3 + 2 * k] : 0;
        for (int k = 6; k >= 0 && (b.label[k] == ' ' || b.label[k] == 0); --k) b.label[k] = 0;
        b.depth = depth;
        for (int k = 0; k < depth; ++k) b.path[k] = r[4 + 2 * k];
        b.slot = r[4 + 2 * depth];
    }
    hasEffect = n > 3 * 512;
    effectName[0] = 0;
    if (hasEffect && n >= 0x600 + 10 + 24) wordText (d + 0x600 + 10, 12, effectName);
    return true;
}

bool Bank::resolve (const Volume& v, const BankRef& r, Entry& out, char* err, size_t errMax, bool isSong) const
{
    if (r.kind != BankRef::REF) { setErr (err, errMax, "record does not point to a file"); return false; }
    // The disk label identifies the disk. The media byte (0 floppy, SCSI ID + 1) only says which drive the
    // hardware used, which means nothing on the MPC: the demo CD's banks say media 5 for their own CD.
    if (strcmp (r.label, v.label) != 0)
    {
        char m[96]; snprintf (m, sizeof m, "on another disk (label \"%s\")", r.label);
        setErr (err, errMax, m); return false;
    }
    uint32_t dirBlock = 3;
    for (int k = 0; k <= r.depth; ++k)
    {
        Dir d;
        if (! v.readDir (dirBlock, d, err, errMax)) return false;
        const uint8_t want = k < r.depth ? r.path[k] : r.slot;
        const Entry* hit = nullptr;
        for (int i = 0; i < d.n; ++i) if (d.e[i].slot == want) { hit = &d.e[i]; break; }
        if (! hit) { setErr (err, errMax, "slot is empty"); return false; }
        if (k < r.depth)
        {
            if (hit->type != FT_DIR) { setErr (err, errMax, "path slot is not a directory"); return false; }
            dirBlock = hit->start;
        }
        else
        {
            const bool songType = hit->type == FT_SONG || hit->type == FT_E16_SONG || hit->type == FT_ASR_SONG;
            if (isSong ? ! songType : hit->type != FT_INSTRUMENT)
            { setErr (err, errMax, isSong ? "slot does not hold a song" : "slot does not hold an instrument"); return false; }
            out = *hit;
        }
    }
    return true;
}
} // namespace ens
