// Ensoniq file system reader. See ens_fs.h and docs/ENSONIQ_FORMATS.md.
#include "ens_fs.h"
#include <stdio.h>
#include <string.h>

namespace ens
{
static void setErr (char* err, size_t max, const char* msg)
{
    if (err && max) { strncpy (err, msg, max - 1); err[max - 1] = 0; }
}
static uint32_t be16 (const uint8_t* p) { return (uint32_t) ((p[0] << 8) | p[1]); }
static uint32_t be24 (const uint8_t* p) { return ((uint32_t) p[0] << 16) | ((uint32_t) p[1] << 8) | p[2]; }
static uint32_t be32 (const uint8_t* p) { return ((uint32_t) p[0] << 24) | ((uint32_t) p[1] << 16) | ((uint32_t) p[2] << 8) | p[3]; }

const char* fileTypeName (uint8_t t, bool* known)
{
    const char* n = nullptr;
    switch (t)
    {
        case FT_EMPTY:      n = "empty"; break;
        case FT_OS:         n = "OS"; break;
        case FT_DIR:        n = "Directory"; break;
        case FT_INSTRUMENT: n = "Instrument"; break;
        case FT_BANK:       n = "Bank"; break;
        case FT_SEQUENCE:   n = "Sequence"; break;
        case FT_SONG:       n = "Song"; break;
        case FT_SYSEX:      n = "SysEx"; break;
        case FT_PARENT:     n = "Parent dir"; break;
        case FT_MACRO:      n = "Macro"; break;
        case FT_E16_BANK:   n = "EPS-16+ Bank"; break;
        case FT_E16_EFFECT: n = "EPS-16+ Effect"; break;
        case FT_E16_SEQUENCE: n = "EPS-16+ Sequence"; break;
        case FT_E16_SONG:   n = "EPS-16+ Song"; break;
        case FT_E16_OS:     n = "EPS-16+ OS"; break;
        case FT_ASR_SEQUENCE: n = "ASR Sequence"; break;
        case FT_ASR_SONG:   n = "ASR Song"; break;
        case FT_ASR_BANK:   n = "ASR Bank"; break;
        case FT_ASR_TRACK:  n = "ASR Audio Track"; break;
        case FT_ASR_OS:     n = "ASR OS"; break;
        case FT_ASR_EFFECT: n = "ASR Effect"; break;
        default: break;
    }
    if (known) *known = n != nullptr;
    return n ? n : "unidentified type";
}

bool Volume::open (const Image& image, char* err, size_t errMax)
{
    img = &image;
    cachedFat = 0xFFFFFFFF;
    uint8_t b[kBlock];
    if (! img->read (1, b)) { setErr (err, errMax, "cannot read the ID block"); return false; }
    hasId = b[38] == 'I' && b[39] == 'D';
    totalBlocks = hasId ? be32 (b + 14) : 0;
    memset (label, 0, sizeof label);
    if (hasId) for (int k = 0; k < 7; ++k) label[k] = (b[31 + k] >= 32 && b[31 + k] < 127) ? (char) b[31 + k] : 0;
    for (int k = 6; k >= 0 && (label[k] == ' ' || label[k] == 0); --k) label[k] = 0;
    if (totalBlocks == 0 || totalBlocks > img->numBlocks) totalBlocks = img->numBlocks;
    if (! img->read (2, b)) { setErr (err, errMax, "cannot read the OS block"); return false; }
    hasOs = b[28] == 'O' && b[29] == 'S';
    freeBlocks = hasOs ? be32 (b) : 0;
    diskOs[0] = b[4]; diskOs[1] = b[5]; romOs[0] = b[6]; romOs[1] = b[7];
    uint8_t f[kBlock];
    if (! img->read (5, f) || f[510] != 'F' || f[511] != 'B') { setErr (err, errMax, "no FAT signature (FB) in block 5"); return false; }
    Dir root;
    return readRoot (root, err, errMax);
}

bool Volume::readDir (uint32_t first, Dir& out, char* err, size_t errMax) const
{
    uint8_t d[2 * kBlock];
    if (! img->read (first, d) || ! img->read (first + 1, d + kBlock))
    { setErr (err, errMax, "cannot read directory blocks"); return false; }
    if (d[1022] != 'D' || d[1023] != 'R') { setErr (err, errMax, "directory signature (DR) missing"); return false; }
    out.n = 0;
    for (int i = 0; i < 39; ++i)
    {
        const uint8_t* p = d + i * 26;
        if (p[1] == FT_EMPTY) continue;
        Entry& e = out.e[out.n++];
        e.typeInfo = p[0]; e.type = p[1];
        memcpy (e.name, p + 2, 12); e.name[12] = 0;
        for (int k = 11; k >= 0 && (e.name[k] == ' ' || e.name[k] == 0); --k) e.name[k] = 0;
        for (int k = 0; k < 12 && e.name[k]; ++k) if ((unsigned char) e.name[k] < 32 || (unsigned char) e.name[k] > 126) e.name[k] = '?';
        e.sizeBlocks = (uint16_t) be16 (p + 14);
        e.contiguous = (uint16_t) be16 (p + 16);
        e.start = be32 (p + 18);
        e.multi = p[22];
        e.slot = i;
    }
    return true;
}

uint32_t Volume::fatNext (uint32_t block) const
{
    const uint32_t fb = 5 + block / 170, off = (block % 170) * 3;
    if (fb != cachedFat)
    {
        if (! img->read (fb, fatBuf) || fatBuf[510] != 'F' || fatBuf[511] != 'B') return 0xFFFFFFFF;
        cachedFat = fb;
    }
    return be24 (fatBuf + off);
}

bool Volume::readFile (const Entry& e, Bytes& out, char* err, size_t errMax) const
{
    if (e.type == FT_DIR || e.type == FT_PARENT) { setErr (err, errMax, "not a file"); return false; }
    if (e.sizeBlocks == 0 || e.start < 5 || e.start >= totalBlocks) { setErr (err, errMax, "file start/size out of range"); return false; }
    if (! out.alloc ((size_t) e.sizeBlocks * kBlock)) { setErr (err, errMax, "out of memory"); return false; }
    uint32_t blk = e.start;
    for (uint32_t i = 0; i < e.sizeBlocks; ++i)
    {
        if (blk < 5 || blk >= totalBlocks) { out.release(); setErr (err, errMax, "FAT chain leaves the disk"); return false; }
        if (! img->read (blk, out.p + (size_t) i * kBlock)) { out.release(); setErr (err, errMax, "read error in file"); return false; }
        const uint32_t next = fatNext (blk);
        if (i + 1 == e.sizeBlocks) break;
        if (next == 0xFFFFFFFF) { out.release(); setErr (err, errMax, "FAT block unreadable"); return false; }
        if (next <= 2)
        {
            out.release();
            char m[96]; snprintf (m, sizeof m, "FAT chain ends after %u of %u blocks (entry %u)", i + 1, e.sizeBlocks, next);
            setErr (err, errMax, m); return false;
        }
        blk = next;
    }
    return true;
}

static bool nameEq (const char* a, const char* b, size_t bn)
{
    size_t i = 0;
    for (; i < bn && a[i]; ++i)
    {
        char x = a[i], y = b[i];
        if (x >= 'a' && x <= 'z') x = (char) (x - 32);
        if (y >= 'a' && y <= 'z') y = (char) (y - 32);
        if (x != y) return false;
    }
    if (i != bn) return false;
    return a[i] == 0;
}

bool Volume::find (const char* path, Entry& out, char* err, size_t errMax) const
{
    uint32_t dirBlock = 3;
    const char* p = path;
    for (int depth = 0; depth < 32; ++depth)
    {
        while (*p == '/') ++p;
        const char* end = p; while (*end && *end != '/') ++end;
        size_t len = (size_t) (end - p);
        while (len && p[len - 1] == ' ') --len;
        Dir d;
        if (! readDir (dirBlock, d, err, errMax)) return false;
        const Entry* hit = nullptr;
        for (int i = 0; i < d.n; ++i) if (d.e[i].type != FT_PARENT && nameEq (d.e[i].name, p, len)) { hit = &d.e[i]; break; }
        if (! hit) { setErr (err, errMax, "not found"); return false; }
        if (*end == 0) { out = *hit; return true; }
        if (hit->type != FT_DIR) { setErr (err, errMax, "path goes through a file"); return false; }
        dirBlock = hit->start;
        p = end;
    }
    setErr (err, errMax, "path too deep");
    return false;
}
} // namespace ens
