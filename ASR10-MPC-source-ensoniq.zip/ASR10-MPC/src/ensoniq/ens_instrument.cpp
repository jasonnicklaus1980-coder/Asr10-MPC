// Instrument model helpers. See ens_instrument.h.
#include "ens_instrument.h"
#include <stdlib.h>

namespace ens
{
bool Instrument::allocAudio (size_t frames)
{
    releaseAudio();
    audio = (int16_t*) calloc (frames ? frames : 1, sizeof (int16_t));
    audioFrames = audio ? frames : 0;
    return audio != nullptr;
}

void Instrument::releaseAudio() { free (audio); audio = nullptr; audioFrames = 0; }

int Instrument::sanitize()
{
    int fixes = 0;
    if (numLayers > 8) { numLayers = 8; ++fixes; }
    if (numWs > 127) { numWs = 127; ++fixes; }
    for (int i = 0; i < numWs; ++i)
    {
        WaveSample& w = ws[i];
        if (! w.data || w.frames < 2) { w.data = nullptr; w.frames = 0; w.start = w.end = w.loopStart = w.loopEnd = 0; continue; }
        if (w.end > w.frames || w.end <= w.start) { w.end = w.frames; ++fixes; }
        if (w.start >= w.end) { w.start = 0; ++fixes; }
        if (w.loopEnd > w.end) { w.loopEnd = w.end; ++fixes; }
        if (w.loopStart < w.start) { w.loopStart = w.start; ++fixes; }
        if (w.loop >= LOOP_FORWARD && w.loopEnd < w.loopStart + 2) { w.loop = LOOP_OFF_FORWARD; ++fixes; }
        if (w.loopEndF >= 0.0 || w.loopStartF >= 0.0)
        {
            if (w.loopStartF < (double) w.start || w.loopStartF >= (double) w.end) { w.loopStartF = (double) w.loopStart; ++fixes; }
            if (w.loopEndF > (double) w.end || w.loopEndF < w.loopStartF + 1.0) { w.loopEndF = (double) w.loopEnd; ++fixes; }
        }
        if (w.sampleRate < 1000.f || w.sampleRate > 100000.f) { w.sampleRate = 29761.9f; ++fixes; }
        if (w.keyLo > w.keyHi) { uint8_t t = w.keyLo; w.keyLo = w.keyHi; w.keyHi = t; ++fixes; }
        if (w.filterMode > 3) { w.filterMode = 0; ++fixes; }
    }
    for (int l = 0; l < numLayers; ++l)
    {
        Layer& L = layer[l];
        if (L.hasKeyMap)
        {
            for (int k = 0; k < 128; ++k)
                if (L.keyMap[k] > numWs || (L.keyMap[k] && ! ws[L.keyMap[k] - 1].data)) { L.keyMap[k] = 0; ++fixes; }
            continue;
        }
        if (L.firstWs >= numWs) { L.firstWs = 0; L.numWs = 0; ++fixes; }
        if (L.firstWs + L.numWs > numWs) { L.numWs = (uint8_t) (numWs - L.firstWs); ++fixes; }
        if (L.velLo > L.velHi) { uint8_t t = L.velLo; L.velLo = L.velHi; L.velHi = t; ++fixes; }
    }
    return fixes;
}
} // namespace ens
