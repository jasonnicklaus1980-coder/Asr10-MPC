// ASR-10 / EPS-16+ instrument file parser. See ens_instrument_file.h and docs/ENSONIQ_FORMATS.md.
#include "ens_instrument_file.h"
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

namespace ens
{
void ParseInfo::addWarn (const char* fmt, ...)
{
    if (nWarn >= 6) return;
    va_list a; va_start (a, fmt);
    vsnprintf (warn[nWarn++], sizeof warn[0], fmt, a);
    va_end (a);
}

static void setErr (char* err, size_t max, const char* msg)
{
    if (err && max) { strncpy (err, msg, max - 1); err[max - 1] = 0; }
}

static const size_t kHeader = 0x290, kLayerBlock = 0xE0, kWsParams = 0x120;
static const int kWords = 139;                       // wavesample parameter words (0..138)

// Block size in bytes: (byte0 | (byte3 >> 4) << 8 | byte2 << 12) x 16.
static size_t blockSize (const uint8_t* b) { return ((size_t) b[0] | ((size_t) (b[3] >> 4) << 8) | ((size_t) b[2] << 12)) * 16; }
static int blockId (const uint8_t* b) { return (int) (((b[4] << 8) | b[5]) >> 6); }
// parameter word k of a wavesample / layer block: value in the high byte, names start at +10
static inline uint8_t hw (const uint8_t* b, int k) { return b[10 + 2 * k]; }
static void readName (const uint8_t* b, size_t off, char* out)   // 12 characters, one per 16-bit word
{
    for (int k = 0; k < 12; ++k) { const uint8_t c = b[off + 2 * k]; out[k] = (c >= 32 && c < 127) ? (char) c : ' '; }
    out[12] = 0;
    for (int k = 11; k >= 0 && out[k] == ' '; --k) out[k] = 0;
}

static bool looksLikeWavesample (const uint8_t* b, size_t size)
{
    if (size < kWsParams) return false;
    for (int k = 0; k < 12; ++k) if (b[10 + 2 * k] < 32 || b[10 + 2 * k] >= 127) return false;
    for (int k = 2; k < 12; ++k) if (b[11 + 2 * k] != 0) return false;
    return hw (b, 132) <= hw (b, 133) && hw (b, 133) <= 127 && hw (b, 114) <= 4;
}

// Sample rate from parameter word 131. 12..70 is a period in 1.6 us units (29761.9 Hz = 21, the ASR-10's own rate);
// 1 is the ASR-10's 44.1 kHz; 0 was measured at about 47.7 kHz (tuned loops: 47723 Hz +-0.3 %) and is taken as
// 47619 Hz = 1/21 us, which is an estimate. Anything else is unknown.
static float rateFromWord (int w, int& kind)
{
    kind = 0;
    if (w >= 12 && w <= 70) return 625000.f / (float) w;
    if (w == 1) return 44100.f;
    if (w == 0) { kind = 1; return 47619.05f; }
    kind = 2;
    return 29761.9f;
}

bool parseInstrument (const uint8_t* d, size_t n, Instrument& out, ParseInfo& info, char* err, size_t errMax)
{
    info = ParseInfo();
    info.fileBytes = n;
    if (n < kHeader + 16) { setErr (err, errMax, "file too short for an instrument"); return false; }

    struct Blk { size_t off, size; };
    Blk wsBlk[128] {}, layerBlk[9] {};                // indexed by wavesample number / layer number
    bool haveWs[128] {}, haveLayer[9] {};

    // ---- pass 1: walk the blocks; they must tile the file exactly
    size_t o = kHeader;
    size_t audioFrames = 0;
    while (o < n)
    {
        if (o + 16 > n) { char m[96]; snprintf (m, sizeof m, "truncated block header at 0x%zx", o); setErr (err, errMax, m); return false; }
        const size_t s = blockSize (d + o);
        if (s < 16 || o + s > n)
        {
            char m[112]; snprintf (m, sizeof m, "block structure breaks at 0x%zx (size field 0x%zx, file 0x%zx)", o, s, n);
            setErr (err, errMax, m); return false;
        }
        ++info.blocks;
        const uint8_t* b = d + o;
        const int id = blockId (b);
        // Classified by block id (header bytes 4-5 >> 6): 17..24 pitch tables, 25..32 layers 1..8, 34..160 wavesamples
        // 1..127, 162 effect. (Header byte 4 alone is not enough: it is 6, 7 and 8 across the layers.)
        if (s == kLayerBlock && id >= 25 && id <= 32 && b[0] == 0x0e && b[1] == 0 && b[2] == 0 && b[3] == 0)
        {
            const int ln = id - 24;
            if (haveLayer[ln]) info.addWarn ("duplicate layer %d ignored", ln);
            else { haveLayer[ln] = true; layerBlk[ln] = { o, s }; ++info.layers; }
        }
        else if (s == kLayerBlock && id < 25) ++info.pitchTables;
        else if (id >= 161) ++info.effectBlocks;
        else if (id >= 34 && id <= 160 && looksLikeWavesample (b, s))
        {
            const int wn = id - 33;
            if (haveWs[wn]) info.addWarn ("duplicate wavesample %d ignored", wn);
            else
            {
                haveWs[wn] = true; wsBlk[wn] = { o, s }; ++info.wavesamples;
                if (hw (b, 12) == 0) audioFrames += (s - kWsParams) / 2;
            }
        }
        else ++info.unknownBlocks;
        o += s;
    }
    if (info.wavesamples == 0 || info.layers == 0) { setErr (err, errMax, "no layers or wavesamples found"); return false; }

    // ---- pass 2: build the instrument
    out.numLayers = 0; out.numWs = 0;
    if (! out.allocAudio (audioFrames)) { setErr (err, errMax, "out of memory for sample data"); return false; }
    info.audioFrames = audioFrames;
    readName (d, 0x0a, out.name);
    for (int k = 0; k < 4; ++k) out.patchSelectMask[k] = d[0x2c + 2 * k] ? d[0x2c + 2 * k] : 0xFF;

    size_t used = 0;
    int highest = 0;
    for (int wn = 1; wn <= 127; ++wn)                  // originals first: they own the audio
    {
        if (! haveWs[wn]) continue;
        highest = wn;
        const uint8_t* b = d + wsBlk[wn].off;
        WaveSample& w = out.ws[wn - 1];
        readName (b, 10, w.name);
        for (int k = 0; k < kWords; ++k) w.raw[k] = hw (b, k);
        if (hw (b, 12) == 0)
        {
            const size_t frames = (wsBlk[wn].size - kWsParams) / 2;
            const uint8_t* src = b + kWsParams;
            int16_t* dst = out.audio + used;
            for (size_t i = 0; i < frames; ++i) dst[i] = (int16_t) ((src[2 * i] << 8) | src[2 * i + 1]);
            w.data = dst; w.frames = (uint32_t) frames; used += frames;
        }
    }
    out.numWs = (uint8_t) highest;
    for (int wn = 1; wn <= highest; ++wn)              // copies share the audio of the wavesample they name
    {
        if (! haveWs[wn]) continue;
        WaveSample& w = out.ws[wn - 1];
        const int ref = w.raw[12];
        if (ref == 0) continue;
        ++info.copies;
        int hops = 0, r = ref;
        while (r >= 1 && r <= 127 && haveWs[r] && out.ws[r - 1].raw[12] != 0 && hops++ < 4) r = out.ws[r - 1].raw[12];
        if (r < 1 || r > 127 || ! haveWs[r] || ! out.ws[r - 1].data)
        { ++info.missingCopyRefs; info.addWarn ("wavesample %d copies missing wavesample %d", wn, ref); continue; }
        w.data = out.ws[r - 1].data; w.frames = out.ws[r - 1].frames;
    }

    for (int wn = 1; wn <= highest; ++wn)              // parameters
    {
        if (! haveWs[wn]) continue;
        WaveSample& w = out.ws[wn - 1];
        if (! w.data) continue;
        const uint8_t* r = w.raw;
        auto P32 = [&] (int k) { return ((uint32_t) r[k] << 24) | ((uint32_t) r[k + 1] << 16) | ((uint32_t) r[k + 2] << 8) | r[k + 3]; };
        const uint32_t startPos = P32 (115) >> 9, endPos = P32 (119) >> 9;
        const double lsF = (double) P32 (123) / 512.0, leF = (double) P32 (127) / 512.0;
        w.loop = r[114] <= 4 ? (LoopMode) r[114] : LOOP_OFF_FORWARD;
        w.start = startPos;
        // last real sample is endPos (inclusive); a looping sample may read past its loop end, so keep one more
        uint32_t endEx = endPos + 1;
        if (w.loop >= LOOP_FORWARD)
        {
            w.loopStartF = lsF; w.loopEndF = leF;
            w.loopStart = (uint32_t) lsF; w.loopEnd = (uint32_t) ceil (leF);
            if (w.loopEnd + 1 > endEx) endEx = w.loopEnd + 1;
        }
        else { w.loopStart = w.start; w.loopEnd = endEx; }
        w.end = endEx > w.frames ? w.frames : endEx;
        int kind; w.sampleRate = rateFromWord (r[131], kind);
        if (kind == 1) ++info.rateEstimated;
        if (kind == 2) { ++info.rateUnknown; info.addWarn ("wavesample %d has unknown rate word %d", wn, r[131]); }
        w.keyLo = r[132]; w.keyHi = r[133]; w.rootKey = r[80] & 127;
        const int ft = r[86] < 128 ? r[86] : r[86] - 256;
        w.fineCents = (float) ft * 0.6f;               // empirical (corr -0.41 over 127 tuned loops): needs hardware check
        w.volumeDb = 20.f * log10f ((float) (r[99] > 0 ? r[99] : 1) / 127.f);
        // pan word: 3 is the default (centre), 0 / 7 hard left / right; larger values (seen in ~1%) are taken as centre
        w.pan = (r[105] > 7 || r[105] == 3) ? 0.f : ((float) r[105] - 3.5f) / 3.5f;
        // filters, envelopes and LFO are kept in raw[] but not decoded: the engine runs neutral envelopes and no filter
        w.fc1 = 20000.f; w.fc2 = 20.f; w.filterMode = 0;
        w.ampEnv.release = 0.1f;
    }

    // layers: velocity window at words 3/4 after the name, key map (keys 21..108) at +0x30
    int highestLayer = 0;
    for (int ln = 1; ln <= 8; ++ln)
    {
        Layer& L = out.layer[ln - 1];
        if (! haveLayer[ln]) { L.enabled = false; continue; }
        highestLayer = ln;
        const uint8_t* b = d + layerBlk[ln].off;
        readName (b, 10, L.name);
        L.enabled = true; L.hasKeyMap = true;
        L.velLo = b[0x22 + 6]; L.velHi = b[0x22 + 8];
        if (L.velHi == 0 && L.velLo == 0) L.velHi = 127;
        for (int k = 0; k < 128; ++k)
        {
            const int kk = k < 21 ? 21 : (k > 108 ? 108 : k);     // outside the 88-key map: the edge entry (assumed)
            const int num = b[0x30 + 2 * (kk - 21)];
            if (num == 0) continue;
            if (num > 127 || ! haveWs[num] || ! out.ws[num - 1].data) { ++info.badKeymapRefs; continue; }
            L.keyMap[k] = (uint8_t) num;
        }
    }
    out.numLayers = (uint8_t) highestLayer;
    info.sanitizeFixes = out.sanitize();
    return true;
}

bool parseInstrumentEntry (const Volume& v, const Entry& e, Instrument& out, ParseInfo& info, char* err, size_t errMax)
{
    if (e.type != FT_INSTRUMENT) { setErr (err, errMax, "not an instrument file"); return false; }
    Bytes data;
    if (! v.readFile (e, data, err, errMax)) return false;
    const bool ok = parseInstrument (data.p, data.n, out, info, err, errMax);
    data.release();
    return ok;
}
} // namespace ens
