// 64-bit file offsets: on the MPC (32-bit ARM) a plain `long` would break images over 2 GB (SCSI disks).
#define _FILE_OFFSET_BITS 64
#define _LARGEFILE_SOURCE 1
// Ensoniq image containers. See ens_image.h and docs/ENSONIQ_FORMATS.md.
#include "ens_image.h"
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>

namespace ens
{
bool Bytes::alloc (size_t size)
{
    release();
    p = (uint8_t*) calloc (size ? size : 1, 1);
    n = p ? size : 0;
    return p != nullptr;
}
void Bytes::release() { free (p); p = nullptr; n = 0; }

const char* imageKindName (ImageKind k)
{
    switch (k)
    {
        case IMG_RAW:          return "raw block image";
        case IMG_HFE:          return "HFE floppy image";
        case IMG_GIEBLER_DISK: return "Giebler disk image";
        case IMG_GKH:          return "GKH disk image";
        default:               return "none";
    }
}

static void setErr (char* err, size_t max, const char* msg)
{
    if (err && max) { strncpy (err, msg, max - 1); err[max - 1] = 0; }
}
static uint16_t le16 (const uint8_t* p) { return (uint16_t) (p[0] | (p[1] << 8)); }

bool looksLikeEnsoniq (const uint8_t* b1, const uint8_t* b3, const uint8_t* b4)
{
    const bool id = b1[38] == 'I' && b1[39] == 'D';
    const bool dr = b4[510] == 'D' && b4[511] == 'R';     // bytes 1022-1023 of the 2-block root directory
    (void) b3;
    return id || dr;
}

static bool readWhole (const char* path, Bytes& out, size_t maxSize, char* err, size_t errMax)
{
    FILE* f = fopen (path, "rb");
    if (! f) { setErr (err, errMax, "cannot open file"); return false; }
    fseeko (f, 0, SEEK_END);
    const off_t sz = ftello (f);
    fseeko (f, 0, SEEK_SET);
    if (sz <= 0 || (size_t) sz > maxSize) { fclose (f); setErr (err, errMax, "file empty or too large for this container"); return false; }
    if (! out.alloc ((size_t) sz)) { fclose (f); setErr (err, errMax, "out of memory"); return false; }
    const bool ok = fread (out.p, 1, (size_t) sz, f) == (size_t) sz;
    fclose (f);
    if (! ok) { out.release(); setErr (err, errMax, "read error"); }
    return ok;
}

// ---------------------------------------------------------------- CRC-16/CCITT (IBM MFM sector CRC) ----
uint16_t crc16Ccitt (const uint8_t* d, size_t n, uint16_t crc)
{
    for (size_t i = 0; i < n; ++i)
    {
        crc ^= (uint16_t) (d[i] << 8);
        for (int b = 0; b < 8; ++b) crc = (uint16_t) ((crc & 0x8000) ? (crc << 1) ^ 0x1021 : crc << 1);
    }
    return crc;
}

// ---------------------------------------------------------------- HFE v1 --------------------------------
// Header (little-endian): "HXCPICFE", rev, tracks, sides, encoding, bitrate(2), rpm(2), interface, dnu,
// track list offset (2, in 512-byte blocks). Track list: per track {offset in blocks (2), length in bytes (2)}.
// Track data interleaves 256-byte chunks of side 0 and side 1; bits are stored LSB first.
namespace
{
struct Sector { uint8_t track, side, r; const uint8_t* data; };

struct Bits
{
    const uint8_t* trk; uint32_t len, side;           // len = bytes of this side
    inline int at (uint32_t i) const                   // cell i of this side
    {
        const uint32_t byte = i >> 3, chunk = byte >> 8, off = byte & 255;
        return (trk[chunk * 512 + side * 256 + off] >> (i & 7)) & 1;
    }
    uint32_t cells() const { return len * 8; }
    uint8_t dataByte (uint32_t firstCell) const        // firstCell = clock cell of the first bit
    {
        uint8_t v = 0;
        for (int k = 0; k < 8; ++k) v = (uint8_t) ((v << 1) | at (firstCell + 1 + 2 * (uint32_t) k));
        return v;
    }
};
}

bool decodeHfe (const uint8_t* file, size_t size, Bytes& blocks, uint32_t& numBlocks, uint32_t& bad,
                char* err, size_t errMax)
{
    if (size < 512 || memcmp (file, "HXCPICFE", 8) != 0)
    {
        if (size >= 8 && memcmp (file, "HXCHFEV3", 8) == 0) setErr (err, errMax, "HFE v3 (HXCHFEV3) is not supported yet; save as HFE v1");
        else setErr (err, errMax, "not an HFE file");
        return false;
    }
    const int tracks = file[9], sides = file[10];
    const uint32_t tlo = (uint32_t) le16 (file + 18) * 512;
    if (tracks < 1 || sides < 1 || sides > 2 || tlo + (uint32_t) tracks * 4 > size)
    { setErr (err, errMax, "HFE header out of range"); return false; }

    // pass 1: collect every good sector (up to 255 tracks: the extended 2550 / 5100 KB Ensoniq layouts)
    const int kMax = tracks * sides * 40;
    Sector* sec = (Sector*) calloc (kMax, sizeof (Sector));
    uint8_t* copy = (uint8_t*) malloc ((size_t) kMax * 512);
    if (! sec || ! copy) { free (sec); free (copy); setErr (err, errMax, "out of memory"); return false; }
    int ns = 0, crcBad = 0, minR = 255, maxR = -1;

    for (int t = 0; t < tracks; ++t)
    {
        const uint32_t off = (uint32_t) le16 (file + tlo + t * 4) * 512, tlen = le16 (file + tlo + t * 4 + 2);
        if (off + tlen > size || tlen < 512) continue;
        for (int s = 0; s < sides; ++s)
        {
            Bits b { file + off, tlen / 2, (uint32_t) s };
            // the side's bytes are spread over 256-byte chunks; cells() counts only this side's bytes
            const uint32_t n = b.cells();
            uint16_t reg = 0;
            int lastR = -1, lastN = 2;
            for (uint32_t i = 0; i + 16 * 8 < n; ++i)
            {
                reg = (uint16_t) ((reg << 1) | b.at (i));
                if (reg != 0x4489) continue;                  // A1 with a missing clock: address mark sync
                uint32_t p = i + 1;
                while (p + 16 < n && b.dataByte (p) == 0xA1)
                {   // skip further syncs (they decode as A1)
                    uint16_t w = 0; for (int k = 0; k < 16; ++k) w = (uint16_t) ((w << 1) | b.at (p + (uint32_t) k));
                    if (w != 0x4489) break;
                    p += 16;
                }
                const uint8_t mark = b.dataByte (p);
                if (mark == 0xFE && p + 16 * 7 < n)            // ID address mark: C H R N CRC
                {
                    uint8_t h[10] { 0xA1, 0xA1, 0xA1, 0xFE };
                    for (int k = 0; k < 6; ++k) h[4 + k] = b.dataByte (p + 16 * (uint32_t) (k + 1));
                    if (crc16Ccitt (h, 10) == 0) { lastR = h[6]; lastN = h[7] & 3; }
                    else { lastR = -1; ++crcBad; }
                    i = p + 16 * 7 - 1; reg = 0;
                }
                else if ((mark == 0xFB || mark == 0xF8) && lastR >= 0)   // data mark: 128 << N bytes + CRC
                {
                    const uint32_t len = 128u << lastN;
                    if (len != 512 || p + 16 * (len + 3) > n || ns >= kMax) { lastR = -1; continue; }
                    uint8_t* d = copy + (size_t) ns * 512;
                    uint8_t buf[4 + 512 + 2] = { 0xA1, 0xA1, 0xA1, mark };
                    for (uint32_t k = 0; k < len + 2; ++k) buf[4 + k] = b.dataByte (p + 16 * (k + 1));
                    if (crc16Ccitt (buf, sizeof buf) == 0)
                    {
                        memcpy (d, buf + 4, 512);
                        sec[ns++] = { (uint8_t) t, (uint8_t) s, (uint8_t) lastR, d };
                        if (lastR < minR) minR = lastR;
                        if (lastR > maxR) maxR = lastR;
                    }
                    else ++crcBad;
                    lastR = -1;
                    i = p + 16 * (len + 3) - 1; reg = 0;
                }
            }
        }
    }
    if (ns == 0) { free (sec); free (copy); setErr (err, errMax, "no readable MFM sectors in HFE"); return false; }

    const int spt = maxR - minR + 1;
    numBlocks = (uint32_t) (tracks * sides * spt);
    if (! blocks.alloc ((size_t) numBlocks * 512)) { free (sec); free (copy); setErr (err, errMax, "out of memory"); return false; }
    uint8_t* have = (uint8_t*) calloc (numBlocks, 1);
    for (int k = 0; k < ns; ++k)
    {
        const uint32_t blk = (uint32_t) ((sec[k].track * sides + sec[k].side) * spt + (sec[k].r - minR));
        if (blk < numBlocks && ! have[blk]) { memcpy (blocks.p + (size_t) blk * 512, sec[k].data, 512); have[blk] = 1; }
    }
    uint32_t missing = 0;
    for (uint32_t k = 0; k < numBlocks; ++k) missing += have[k] ? 0 : 1;
    bad = missing;
    (void) crcBad;
    free (have); free (sec); free (copy);
    return true;
}

// ---------------------------------------------------------------- Giebler disk image ---------------------
// EpsLin v1.42 ConvertToImage / ConvertFromImage: 512-byte header ("\r\nEPS-16 Disk" or "\r\nASR-10 Disk", ID in
// byte 511: 0x03 EDE, 0xCB EDA), skip bitmap (EDE 0xA0 / 200 bytes = 1600 blocks, EDA 0x60 / 400 bytes = 3200
// blocks), MSB first, set bit = block not stored. Stored blocks follow the header in order, then one 0x1A byte.
// A skipped block is one that was free in the FAT; it is rebuilt with the 6D B6 pattern Ensoniq formats with.
bool decodeGieblerDisk (const uint8_t* file, size_t size, int asr, Bytes& blocks, uint32_t& numBlocks,
                        char* note, size_t noteMax, char* err, size_t errMax)
{
    if (size < 512) { setErr (err, errMax, "Giebler disk image too short"); return false; }
    if (asr < 0)
    {
        if (file[511] == 0xCB || memcmp (file + 2, "ASR-10 Disk", 11) == 0) asr = 1;
        else if (file[511] == 0x03 || memcmp (file + 2, "EPS-16 Disk", 11) == 0) asr = 0;
        else { setErr (err, errMax, "no EDE/EDA header (ID byte and label missing)"); return false; }
    }
    const uint32_t mapOff = asr ? 0x60 : 0xA0, mapBytes = asr ? 400 : 200, N = mapBytes * 8;
    uint32_t stored = 0;
    for (uint32_t b = 0; b < N; ++b) stored += ((file[mapOff + b / 8] >> (7 - (b & 7))) & 1) ? 0 : 1;
    if (512 + (size_t) stored * 512 > size)
    {
        char m[128]; snprintf (m, sizeof m, "Giebler image truncated: bitmap lists %u stored blocks, file holds %u",
                                stored, (uint32_t) ((size - 512) / 512));
        setErr (err, errMax, m); return false;
    }
    if (! blocks.alloc ((size_t) N * 512)) { setErr (err, errMax, "out of memory"); return false; }
    uint32_t src = 0;
    for (uint32_t b = 0; b < N; ++b)
    {
        uint8_t* dst = blocks.p + (size_t) b * 512;
        if ((file[mapOff + b / 8] >> (7 - (b & 7))) & 1)
            for (int k = 0; k < 512; k += 2) { dst[k] = 0x6D; dst[k + 1] = 0xB6; }
        else
            memcpy (dst, file + 512 + (size_t) (src++) * 512, 512);
    }
    numBlocks = N;
    if (note) snprintf (note, noteMax, "%s: %u blocks, %u stored", asr ? "EDA (ASR-10)" : "EDE (EPS/EPS-16+)", N, stored);
    return true;
}

// ---------------------------------------------------------------- GKH -------------------------------------
// EpsLin v1.42: "II" (little-endian) tagged file; tag count at 6-7, 10-byte tags from offset 8. Tag 0x0A: geometry
// (three 16-bit values multiplied = blocks), tag 0x0B: image length (32-bit at 2) and offset (32-bit at 6).
// Motorola ("MM") GKH files are not supported by EpsLin either. Not yet tested on a real GKH file.
bool decodeGkh (const uint8_t* file, size_t size, Bytes& blocks, uint32_t& numBlocks, char* err, size_t errMax)
{
    if (size < 8) { setErr (err, errMax, "GKH too short"); return false; }
    if (file[4] != 'I') { setErr (err, errMax, "GKH in Motorola byte order is not supported"); return false; }
    const uint32_t tags = le16 (file + 6);
    uint32_t nb = 0, offset = 0;
    for (uint32_t t = 0; t < tags && 8 + (size_t) (t + 1) * 10 <= size; ++t)
    {
        const uint8_t* g = file + 8 + t * 10;
        if (g[0] == 0x0A) nb = (uint32_t) le16 (g + 2) * le16 (g + 4) * le16 (g + 6);
        if (g[0] == 0x0B) offset = (uint32_t) (g[6] | (g[7] << 8) | (g[8] << 16) | ((uint32_t) g[9] << 24));
    }
    if (nb == 0 || offset == 0 || offset + (size_t) nb * 512 > size) { setErr (err, errMax, "GKH geometry/offset tags missing or out of range"); return false; }
    if (! blocks.alloc ((size_t) nb * 512)) { setErr (err, errMax, "out of memory"); return false; }
    memcpy (blocks.p, file + offset, (size_t) nb * 512);
    numBlocks = nb;
    return true;
}

bool undoMacLineEnds (Bytes& file)
{
    if (file.n < 3 || file.p[0] != 0x0D || file.p[1] != 0x0D || file.p[2] != 0x0A) return false;
    size_t w = 0;                                   // drop the byte in front of every 0x0A (EpsLin's rule)
    for (size_t i = 0; i < file.n; ++i)
    {
        if (i + 1 < file.n && file.p[i + 1] == 0x0A) continue;
        file.p[w++] = file.p[i];
    }
    file.n = w;
    return true;
}

// ---------------------------------------------------------------- Image ----------------------------------
static bool hasExt (const char* path, const char* ext)
{
    const size_t n = strlen (path), e = strlen (ext);
    if (n < e) return false;
    for (size_t i = 0; i < e; ++i)
    {
        char c = path[n - e + i]; if (c >= 'A' && c <= 'Z') c = (char) (c + 32);
        if (c != ext[i]) return false;
    }
    return true;
}

bool Image::open (const char* path, char* err, size_t errMax)
{
    close();
    if (err && errMax) err[0] = 0;
    FILE* fp = fopen (path, "rb");
    if (! fp) { setErr (err, errMax, "cannot open file"); return false; }
    uint8_t head[512] {};
    const size_t got = fread (head, 1, 512, fp);
    fseeko (fp, 0, SEEK_END);
    const long long sz = (long long) ftello (fp);
    fclose (fp);

    const bool isHfe = got >= 8 && (memcmp (head, "HXCPICFE", 8) == 0 || memcmp (head, "HXCHFEV3", 8) == 0);
    const bool isGkh = hasExt (path, ".gkh");
    const bool isEdx = hasExt (path, ".ede") || hasExt (path, ".eda")
                    || (got == 512 && head[0] == 0x0D && (head[1] == 0x0A || head[1] == 0x0D)
                        && (head[511] == 0x03 || head[511] == 0xCB));

    if (isHfe || isGkh || isEdx)
    {
        Bytes file;
        if (! readWhole (path, file, 64u << 20, err, errMax)) return false;
        bool ok;
        if (isHfe)
        {
            ok = decodeHfe (file.p, file.n, mem, numBlocks, badSectors, err, errMax);
            kind = IMG_HFE;
            if (ok) snprintf (note, sizeof note, "HFE: %u blocks, %u missing/bad", numBlocks, badSectors);
        }
        else if (isGkh)
        {
            ok = decodeGkh (file.p, file.n, mem, numBlocks, err, errMax);
            kind = IMG_GKH;
            if (ok) snprintf (note, sizeof note, "GKH: %u blocks", numBlocks);
        }
        else
        {
            const bool mac = undoMacLineEnds (file);
            const int asr = hasExt (path, ".eda") ? 1 : hasExt (path, ".ede") ? 0 : -1;
            ok = decodeGieblerDisk (file.p, file.n, asr, mem, numBlocks, note, sizeof note, err, errMax);
            kind = IMG_GIEBLER_DISK;
            if (ok && mac) strncat (note, " (Mac line endings undone)", sizeof note - strlen (note) - 1);
        }
        file.release();
        if (! ok) { close(); return false; }
        uint8_t b1[512], b3[512], b4[512];
        read (1, b1); read (3, b3); read (4, b4);
        if (! looksLikeEnsoniq (b1, b3, b4)) { close(); setErr (err, errMax, "decoded, but it is not an Ensoniq disk (no ID/DR)"); return false; }
        return true;
    }

    // raw: signatures at their natural place
    if (sz >= 5 * 512)
    {
        uint8_t b[5][512] {};
        fp = fopen (path, "rb");
        if (fp && fread (b, 1, sizeof b, fp) == sizeof b && looksLikeEnsoniq (b[1], b[3], b[4]))
        {
            f = fp; kind = IMG_RAW; numBlocks = (uint32_t) (sz / 512);
            const uint32_t idTotal = ((uint32_t) b[1][14] << 24) | ((uint32_t) b[1][15] << 16) | ((uint32_t) b[1][16] << 8) | b[1][17];
            snprintf (note, sizeof note, "raw: %u blocks%s", numBlocks,
                      (b[1][38] == 'I' && idTotal > numBlocks) ? ", shorter than its ID block says (normal for CD-ROM images, else truncated?)" : "");
            return true;
        }
        if (fp) fclose (fp);
    }
    if (hasExt (path, ".efe") || hasExt (path, ".efa"))
        setErr (err, errMax, "this is a single-file image (.efe/.efa), open it with GieblerFile");
    else
        setErr (err, errMax, "not an Ensoniq disk image (no ID/DR signature)");
    return false;
}

bool Image::read (uint32_t block, uint8_t out[kBlock]) const
{
    if (block >= numBlocks) { memset (out, 0, kBlock); return false; }
    if (kind == IMG_RAW)
    {
        if (fseeko (f, (off_t) block * (off_t) kBlock, SEEK_SET) != 0) return false;
        return fread (out, 1, kBlock, f) == kBlock;
    }
    if (! mem.p) return false;
    memcpy (out, mem.p + (size_t) block * kBlock, kBlock);
    return true;
}

void Image::close()
{
    if (f) fclose (f);
    f = nullptr; mem.release(); kind = IMG_NONE; numBlocks = 0; badSectors = 0; note[0] = 0;
}

// ---------------------------------------------------------------- Giebler single file --------------------
bool GieblerFile::parse (const uint8_t* file, size_t size, char* err, size_t errMax)
{
    if (size <= 512 || file[0] != 0x0D || file[1] != 0x0A)
    { setErr (err, errMax, "no Giebler header (expected CR LF at the start)"); return false; }
    memcpy (name, file + 0x12, 12); name[12] = 0;
    for (int k = 11; k >= 0 && (name[k] == ' ' || name[k] == 0); --k) name[k] = 0;
    for (int k = 0; k < 12 && name[k]; ++k) if ((unsigned char) name[k] < 32 || (unsigned char) name[k] > 126) name[k] = '?';
    type = file[0x32];
    sizeBlocks = (uint16_t) ((file[0x34] << 8) | file[0x35]);
    contiguous = (uint16_t) ((file[0x36] << 8) | file[0x37]);
    multi = file[0x3A];
    // some tools append an EOF byte; the data is the whole blocks after the header
    const size_t dataLen = ((size - 512) / 512) * 512;
    sizeMatches = (size_t) sizeBlocks * 512 == dataLen;
    if (! data.alloc (dataLen)) { setErr (err, errMax, "out of memory"); return false; }
    memcpy (data.p, file + 512, dataLen);
    return true;
}

bool GieblerFile::open (const char* path, char* err, size_t errMax)
{
    Bytes file;
    if (! readWhole (path, file, 64u << 20, err, errMax)) return false;
    undoMacLineEnds (file);
    const bool ok = parse (file.p, file.n, err, errMax);
    file.release();
    return ok;
}
} // namespace ens
