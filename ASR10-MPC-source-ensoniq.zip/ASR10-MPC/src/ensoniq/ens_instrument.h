// The EPS / EPS-16+ / ASR-10 instrument as the sound engine plays it, independent of how it is stored on disk.
// The disk parser (not written yet: the byte layout needs real instrument files) fills this in; the engine only
// ever sees this model. Structure from the Ensoniq manuals and the MIDI SysEx parameter list:
//   instrument = up to 8 layers + up to 127 wavesamples; a layer owns a velocity window, mono/poly and
//   note-on / note-off triggering; each wavesample owns its key range, pitch, loop, three envelopes (pitch,
//   filter, amplitude), two filters in series and an LFO. Patch selects switch layers on and off.
// Units here are physical (Hz, seconds, cents, 0..1 levels). How the hardware's 0-99 / 0-127 settings map to
// them is NOT known yet and is the parser's job; docs/ENSONIQ_FORMATS.md tracks what is and isn't known.
#pragma once
#include <stdint.h>
#include <stddef.h>

namespace ens
{
enum LoopMode : uint8_t
{
    LOOP_OFF_FORWARD = 0,    // play start -> end once
    LOOP_OFF_BACKWARD = 1,   // play end -> start once (reverse)
    LOOP_FORWARD = 2,        // start -> loop end, then loop start -> loop end forever
    LOOP_BIDIRECTIONAL = 3,  // loop back and forth between loop start and loop end
    LOOP_RELEASE = 4         // loop forward while the key is held, then play on to the end
};

// Ensoniq envelope: 5 levels (initial, peak, break 1, break 2, sustain), each with a soft and a hard value that
// key velocity interpolates between, 4 times to reach them and a release time. Mode cycle/repeat is not modelled.
struct Envelope
{
    float softLevel[5] {0, 1, 1, 1, 1};
    float hardLevel[5] {0, 1, 1, 1, 1};
    float time[4] {0.001f, 0.f, 0.f, 0.f};   // seconds to go from level i to level i+1
    float release = 0.05f;                   // seconds from wherever it is to 0 after the key is released
    float attackVelScale = 0.f;              // 0..1: how much a hard hit shortens the attack (0 = not at all)
};

enum LfoWave : uint8_t { LFO_TRIANGLE, LFO_SINE, LFO_SAW_UP, LFO_SAW_DOWN, LFO_SQUARE, LFO_NOISE };

struct WaveSample
{
    char name[13] {};
    // audio: 16-bit mono frames, owned by the Instrument (one block of memory for all wavesamples)
    const int16_t* data = nullptr;
    uint32_t frames = 0;
    float sampleRate = 29761.9f;             // Hz the wavesample was recorded at
    uint32_t start = 0, end = 0;             // play range (end exclusive), frames
    uint32_t loopStart = 0, loopEnd = 0;     // loop range (end exclusive), frames
    // Hardware loops are tuned to fractions of a sample (e.g. end 262.75). When >= 0 these override the integer
    // loop points for looping; the data then extends past the loop end so interpolation can read across it.
    double loopStartF = -1.0, loopEndF = -1.0;
    uint8_t raw[139] {};                     // high bytes of the 139 parameter words as stored (kept for fields not decoded yet)
    LoopMode loop = LOOP_OFF_FORWARD;

    uint8_t keyLo = 0, keyHi = 127, rootKey = 60;
    float fineCents = 0.f;
    float bendRange = 2.f;                   // semitones
    float volumeDb = 0.f;
    float pan = 0.f;                         // -1 left .. +1 right
    bool boost = false;                      // Edit/Amp BOOST: +12 dB (ASR-10 manual)

    uint8_t filterMode = 0;                  // OTTO modes: 0 LP2/HP2, 1 LP3/HP1, 2 LP2/LP2, 3 LP3/LP1
    float fc1 = 20000.f, fc2 = 20.f;         // Hz
    float fc1EnvOct = 0.f, fc2EnvOct = 0.f;  // filter envelope depth, octaves
    float fc1KeyTrack = 0.f;                 // octaves per octave from the root key

    Envelope ampEnv, filterEnv, pitchEnv;
    float pitchEnvCents = 0.f;

    LfoWave lfoWave = LFO_TRIANGLE;
    float lfoRate = 5.f, lfoDelay = 0.f;     // Hz, seconds
    float lfoPitchCents = 0.f;               // always-on depth
    float lfoModWheelCents = 0.f;            // extra depth at full mod wheel
};

struct Layer
{
    char name[13] {};
    bool enabled = true;
    uint8_t velLo = 0, velHi = 127;
    bool mono = false;
    bool triggerOnRelease = false;           // plays when the key is released (Ensoniq "note-off" layers)
    uint8_t firstWs = 0, numWs = 0;          // wavesamples [firstWs, firstWs + numWs) belong to this layer
    // Disk instruments map every key to a wavesample through the layer's key map instead: keyMap[key] is the
    // wavesample NUMBER (1..127, ws[number-1]), 0 = silent. Used when hasKeyMap is set.
    bool hasKeyMap = false;
    uint8_t keyMap[128] {};
};

struct Instrument
{
    char name[13] {};
    uint8_t numLayers = 0;
    Layer layer[8];
    uint8_t numWs = 0;                                     // highest wavesample number in use
    char fxName[13] {};                                    // name of the effect stored with the instrument ("HALL REVERB"), '\0' if none
    uint32_t serial = 0;                                   // changes with every loaded instrument (lets the audio thread notice)
    WaveSample ws[127];
    uint8_t patchSelectMask[4] {0xFF, 0xFF, 0xFF, 0xFF};   // layers heard in each patch-select position
    int16_t* audio = nullptr;                              // malloc'd; all wavesample data points into it
    size_t audioFrames = 0;

    // Allocate one audio block for all wavesamples (zeroed). Frees any previous one.
    bool allocAudio (size_t frames);
    void releaseAudio();
    // Clamp every range so the engine can never read outside the data. Returns the number of fixes made.
    int sanitize();
};
} // namespace ens
