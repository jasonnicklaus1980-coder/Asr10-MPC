// Ensoniq EPS / EPS-16+ / ASR-10 file system (floppy, SCSI and CD-ROM share it).
//   block 1        Device ID block ("ID" at bytes 38-39, total blocks at 14-17 big-endian)
//   block 2        OS block (free-block count at 0-3, "OS" at 28-29)
//   blocks 3-4     root directory: 39 entries x 26 bytes, "DR" at bytes 1022-1023
//   blocks 5..     FAT: 170 x 3-byte big-endian entries per block, "FB" at 510-511;
//                  entry = next block of the file, 0 = free, 1 = end of file, 2 = bad block
// Disk label: ID block bytes 31-37. OS block 4-5 / 6-7: OS versions. (EpsLin v1.42)
// Directory entry (26 bytes): 0 type-dependent, 1 type, 2-13 name, 14-15 size in blocks, 16-17 contiguous
// blocks, 18-21 first block, 22 multi-file index, 23-25 reserved. Sources and confidence: docs/ENSONIQ_FORMATS.md
#pragma once
#include "ens_image.h"

namespace ens
{
// File type codes (EpsLin v1.42). Instruments are type 3 on all three samplers; the rest are per model.
enum FileType : uint8_t
{
    FT_EMPTY = 0, FT_OS = 1, FT_DIR = 2, FT_INSTRUMENT = 3, FT_BANK = 4, FT_SEQUENCE = 5, FT_SONG = 6,
    FT_SYSEX = 7, FT_PARENT = 8, FT_MACRO = 9,
    FT_E16_BANK = 23, FT_E16_EFFECT = 24, FT_E16_SEQUENCE = 25, FT_E16_SONG = 26, FT_E16_OS = 27,
    FT_ASR_SEQUENCE = 28, FT_ASR_SONG = 29, FT_ASR_BANK = 30, FT_ASR_TRACK = 31, FT_ASR_OS = 32, FT_ASR_EFFECT = 33
};
inline bool isBankType (uint8_t t) { return t == FT_BANK || t == FT_E16_BANK || t == FT_ASR_BANK; }
// Name of a type code; *known = false for codes EpsLin does not name.
const char* fileTypeName (uint8_t type, bool* known = nullptr);

struct Entry
{
    uint8_t typeInfo = 0, type = 0, multi = 0;
    char name[13] {};                // trailing spaces trimmed
    uint16_t sizeBlocks = 0, contiguous = 0;
    uint32_t start = 0;
    int slot = 0;                    // 0..38 in its directory
};

struct Dir
{
    Entry e[39];
    int n = 0;                       // non-empty entries (parent pointers included)
};

struct Volume
{
    const Image* img = nullptr;
    uint32_t totalBlocks = 0, freeBlocks = 0;
    bool hasId = false, hasOs = false;
    char label[8] {};                // ID block bytes 31-37
    uint8_t diskOs[2] {}, romOs[2] {};   // OS block bytes 4-5 / 6-7: OS version on the disk / of the ROM

    bool open (const Image& image, char* err, size_t errMax);
    bool readDir (uint32_t firstBlock, Dir& out, char* err, size_t errMax) const;   // root = 3
    bool readRoot (Dir& out, char* err, size_t errMax) const { return readDir (3, out, err, errMax); }
    uint32_t fatNext (uint32_t block) const;                                          // 0xFFFFFFFF on error
    // Whole file following the FAT chain; checks the chain length against the directory size.
    bool readFile (const Entry& e, Bytes& out, char* err, size_t errMax) const;
    // Resolve "DIR/SUBDIR/NAME" (case-insensitive, trailing spaces ignored)
    bool find (const char* path, Entry& out, char* err, size_t errMax) const;

private:
    mutable uint32_t cachedFat = 0xFFFFFFFF;
    mutable uint8_t fatBuf[kBlock] {};
};
} // namespace ens
