// Parser for ASR-10 / EPS-16+ instrument files (file types 3) -> ens::Instrument.
// Layout (docs/ENSONIQ_FORMATS.md section 3): a 0x290-byte instrument header, then a sequence of blocks. Every block
// starts with a 10-byte header whose size field gives its length, so the file can always be walked block by block:
//   layer        0xE0 bytes   key map (keys 21..108 -> wavesample number), velocity window, name
//   wavesample   0x120 bytes of parameters + its audio (big-endian 16-bit) unless it is a copy of another
//   effect, pitch table, other: skipped (counted, reported)
// Block ids (header bytes 4-5 >> 6): layer n = 24 + n, wavesample n = 33 + n.
// Everything decoded here was checked against the 581 real ASR-10 demo-CD instruments (make realtest).
#pragma once
#include "ens_fs.h"
#include "ens_instrument.h"

namespace ens
{
struct ParseInfo
{
    size_t fileBytes = 0;
    int blocks = 0, layers = 0, wavesamples = 0, copies = 0;
    int effectBlocks = 0, pitchTables = 0, unknownBlocks = 0;
    int missingCopyRefs = 0, badKeymapRefs = 0;
    int rateEstimated = 0;       // wavesamples whose rate word is 0 (about 47.6 kHz, not exactly known)
    int rateUnknown = 0;         // rate word outside anything seen: played at 29761.9 Hz
    int sanitizeFixes = 0;
    char fxName[13] {};          // name of the first effect block ("HALL REVERB")
    size_t audioFrames = 0;
    char warn[6][110] {};
    int nWarn = 0;
    void addWarn (const char* fmt, ...);
};

// data = the Ensoniq file without any Giebler header. `out` is filled in (and its audio allocated); on failure
// `err` says why and `out` must not be used.
bool parseInstrument (const uint8_t* data, size_t n, Instrument& out, ParseInfo& info, char* err, size_t errMax);

// Convenience: read an instrument file from a volume and parse it.
bool parseInstrumentEntry (const Volume& v, const Entry& e, Instrument& out, ParseInfo& info, char* err, size_t errMax);
} // namespace ens
