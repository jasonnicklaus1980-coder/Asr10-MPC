// Ensoniq EPS / EPS-16+ / ASR-10 image containers: turns a file on the MPC's storage into 512-byte Ensoniq blocks.
// No libstdc++ (the plugin links only libc/libm): plain malloc/free, no exceptions.
//
// Supported containers (details and confidence: docs/ENSONIQ_FORMATS.md):
//   raw     .img / .iso / .hda / anything: block N at byte N*512 (floppy dumps, CD-ROM and SCSI images)
//   HFE v1  HxC floppy emulator image: MFM decoded here, sector CRCs checked
//   Giebler disk image (.ede EPS 1600 blocks / .eda ASR 3200 blocks): 512-byte header with a skip bitmap
//           (EDE at 0xA0, 200 bytes; EDA at 0x60, 400 bytes; MSB first; set bit = block not stored, i.e. free in
//           the FAT, rebuilt as the 6D B6 fill pattern). Layout from EpsLin v1.42 (J. Forsten, GPL).
//   GKH     tagged image ("II" little-endian only, as EpsLin): disk geometry tag 0x0A, image offset tag 0x0B
//   Giebler single file (.efe / .efa / ...): 512-byte header + the file's blocks; not a disk (see ens::GieblerFile)
#pragma once
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

namespace ens
{
constexpr uint32_t kBlock = 512;

struct Bytes
{
    uint8_t* p = nullptr;
    size_t n = 0;
    bool alloc (size_t size);        // zero-filled
    void release();
};

enum ImageKind { IMG_NONE, IMG_RAW, IMG_HFE, IMG_GIEBLER_DISK, IMG_GKH };
const char* imageKindName (ImageKind k);

// A disk as a block device. Raw images stay on disk (a CD-ROM image can be 650 MB); decoded ones live in memory.
struct Image
{
    ImageKind kind = IMG_NONE;
    uint32_t numBlocks = 0;
    FILE* f = nullptr;               // raw
    Bytes mem;                       // HFE / Giebler: decoded blocks
    uint32_t badSectors = 0;         // HFE: sectors with a CRC error or missing (their blocks read as zeros)
    char note[128] {};               // how the container was recognised

    bool open (const char* path, char* err, size_t errMax);
    bool read (uint32_t block, uint8_t out[kBlock]) const;
    void close();
};

// True when blocks 1 / 3-4 carry the Ensoniq "ID" or directory "DR" signatures.
bool looksLikeEnsoniq (const uint8_t* block1, const uint8_t* block3, const uint8_t* block4);

// Giebler single-file image (.efe, .efa, ...). Header (EpsLin, checked on real ASR-10 OS files):
//   0-1 CR LF, 2 "Eps File:", 0x12-0x1D name, 0x1E type text, 0x2F-0x31 CR LF EOF,
//   0x32 file type, 0x34-0x35 size in blocks, 0x36-0x37 contiguous blocks, 0x38-0x39 start (low word), 0x3A multi-file index
struct GieblerFile
{
    char name[13] {};
    uint8_t type = 0, multi = 0;
    uint16_t sizeBlocks = 0, contiguous = 0;
    bool sizeMatches = false;        // header block count == data length
    Bytes data;                      // the Ensoniq file itself
    bool open (const char* path, char* err, size_t errMax);
    bool parse (const uint8_t* file, size_t size, char* err, size_t errMax);
    void release() { data.release(); }
};

// Some Mac tools turned every 0x0A into 0x0D 0x0A; EpsLin detects that by the file starting 0D 0D 0A and undoes it.
bool undoMacLineEnds (Bytes& file);

// MFM helpers, exposed for the tests
uint16_t crc16Ccitt (const uint8_t* d, size_t n, uint16_t crc = 0xFFFF);
bool decodeHfe (const uint8_t* file, size_t size, Bytes& blocks, uint32_t& numBlocks, uint32_t& bad,
                char* err, size_t errMax);
// asr: -1 = decide from the header (ID byte 511: 0x03 EDE, 0xCB EDA, or its label text), 0 = EDE, 1 = EDA
bool decodeGieblerDisk (const uint8_t* file, size_t size, int asr, Bytes& blocks, uint32_t& numBlocks,
                        char* note, size_t noteMax, char* err, size_t errMax);
bool decodeGkh (const uint8_t* file, size_t size, Bytes& blocks, uint32_t& numBlocks, char* err, size_t errMax);
} // namespace ens
