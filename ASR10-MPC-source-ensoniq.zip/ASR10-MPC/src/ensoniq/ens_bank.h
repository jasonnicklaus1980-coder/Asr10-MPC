// Ensoniq bank files (EPS type 4, EPS-16+ type 23, ASR-10 type 30). A bank loads up to 8 instruments and a song
// and can carry an effect; it refers to instruments by their place on a disk, it does not contain them.
// Layout from EpsLin v1.42 (bank info, option -b), offsets here are into the Ensoniq file (no Giebler header):
//   0x08-0x1F  bank name, one character per 16-bit word (high byte)
//   0x20       instrument mask (bit n = instrument n+1 present)
//   0x22       9 records (8 instruments, then the song): 16 bytes each on EPS / EPS-16+, 28 on the ASR-10
//              byte 0: >= 0x80 copy of instrument (low nibble + 1) / 0x7F deleted / else path depth
//              byte 2: media (0 = floppy, SCSI ID + 1); odd bytes 3..15: disk label (7 characters)
//              even bytes 4, 6, ...: directory slot of each path level, then the file's slot
//   0x600      effect (if the bank is longer than 3 blocks); its name one character per word from 0x60A
// Single source (EpsLin); not yet checked against a bank saved by real hardware.
#pragma once
#include "ens_fs.h"

namespace ens
{
struct BankRef
{
    enum Kind { NONE, REF, COPY, DELETED } kind = NONE;
    int copyOf = 0;                  // COPY: 1..8
    uint8_t media = 0;               // 0 floppy, SCSI ID + 1
    char label[8] {};
    int depth = 0;
    uint8_t path[12] {};             // directory slots from the root
    uint8_t slot = 0;                // the file's slot in its directory
};

struct Bank
{
    uint8_t type = 0;                // 4 EPS, 23 EPS-16+, 30 ASR-10
    char name[13] {};
    uint8_t mask = 0;
    BankRef inst[8], song;
    bool hasEffect = false;
    char effectName[13] {};

    // data = the bank file without a Giebler header, type = its directory / EFE type
    bool parse (const uint8_t* data, size_t n, uint8_t fileType, char* err, size_t errMax);
    // Find the instrument a record points to on this volume. Fails with a reason when it lives on another disk
    // (different label) or the slot does not hold an instrument. The media byte is ignored (see .cpp).
    bool resolve (const Volume& v, const BankRef& r, Entry& out, char* err, size_t errMax, bool isSong = false) const;
};
} // namespace ens
