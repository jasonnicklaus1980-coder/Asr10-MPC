// OTTO (ES5505/ES5506) voice filter, as in the ASR10 effect (src/asr10.cpp, docs/CIRCUIT.md): four one-pole stages,
// poles 1-2 low-pass on K1 (Filter 1), poles 3-4 chosen by the mode bits (MAME es5506.cpp). One channel per
// instance, since the engine filters each voice before panning it. The effect keeps its own stereo copy.
#pragma once
#include <cmath>
#include <cstring>

namespace otto
{
inline float flushDenormal (float x) { return std::fabs (x) < 1e-20f ? 0.f : x; }
inline float onePoleK (float hz, float fs) { return 1.f - std::exp (-6.2831853f * hz / fs); }

struct Filter
{
    float s[4] {};
    int lastMode = -1;
    void clear() { std::memset (s, 0, sizeof s); lastMode = -1; }
    static inline float lp (float& st, float x, float k) { st = flushDenormal (st + k * (x - st)); return st; }
    static inline float hp (float& st, float x, float k) { return x - lp (st, x, k); }
    // k = 1: open low-pass (y = x), k = 0: off high-pass (y = x)
    inline float run (float x, int mode, float k1, float k2)
    {
        x = lp (s[0], x, k1);
        x = lp (s[1], x, k1);
        if (mode != lastMode)      // re-purposed poles start by passing their input (no click)
        {
            const bool lp3 = mode == 1 || mode == 3, lp4 = mode >= 2;
            s[2] = lp3 ? x : 0.f;
            s[3] = lp4 ? x : 0.f;
            lastMode = mode;
        }
        switch (mode)
        {
            case 0:  x = hp (s[2], x, k2); return hp (s[3], x, k2);   // LP2 / HP2
            case 1:  x = lp (s[2], x, k1); return hp (s[3], x, k2);   // LP3 / HP1
            case 2:  x = lp (s[2], x, k2); return lp (s[3], x, k2);   // LP2 / LP2
            default: x = lp (s[2], x, k1); return lp (s[3], x, k2);   // LP3 / LP1
        }
    }
};
} // namespace otto
