// APPROXIMATE effects for the ASR10 Instrument, chosen from the name of the effect stored in the instrument
// ("HALL REVERB", "CHORUS+REVRB", "DUAL DELAYS" ...). These are ordinary reverb / chorus / delay / phaser / tremolo /
// rotary / distortion / compressor algorithms, NOT the ASR-10's own effect programs (those run on its ES5510 chip and
// are not emulated). The effect's saved settings (reverb time, mix, rates) are not decoded either, so each algorithm
// runs with fixed, plausible defaults; `level` scales the wet amount. EQ effects are passed through unchanged.
// No STL, no allocation after construction (the object is ~1 MB: create it once, off the audio thread).
#pragma once
#include <math.h>
#include <stdint.h>
#include <string.h>

namespace ens
{
enum FxKind : uint8_t { FX_NONE = 0, FX_REVERB, FX_CHORUS, FX_DELAY, FX_PHASER, FX_TREM, FX_ROTARY, FX_DIST, FX_COMP, FX_EQ };

struct FxPlan
{
    uint8_t kind[6] {};         // effects in the order they appear in the name
    uint8_t n = 0;
    float reverbRt60 = 1.8f;    // seconds (reverb variant picked from the name)
    float reverbSize = 1.f;
    float delayTime = 0.f;      // 0 = default stereo pair; otherwise seconds (tempo names)
    bool hasEq = false;         // EQ present in the name: not implemented, passed through
    int implemented() const { int c = 0; for (int i = 0; i < n; ++i) c += kind[i] != FX_EQ; return c; }
};

// Build a plan from an effect name. Returns the number of implemented effects.
inline int fxPlanFromName (const char* rawName, FxPlan& plan)
{
    plan = FxPlan();
    char s[40]; int len = 0;
    for (; rawName && rawName[len] && len < 39; ++len) s[len] = (char) ((rawName[len] >= 'a' && rawName[len] <= 'z') ? rawName[len] - 32 : rawName[len]);
    s[len] = 0;
    struct Tok { const char* text; FxKind kind; };
    static const Tok toks[] { { "HALL", FX_REVERB }, { "ROOM", FX_REVERB }, { "HOUSE", FX_REVERB }, { "DENSE", FX_REVERB }, { "VRB", FX_REVERB }, { "VERB", FX_REVERB }, { "REV", FX_REVERB },
                              { "CHO", FX_CHORUS }, { "DDL", FX_DELAY }, { "DELAY", FX_DELAY }, { "BPM", FX_DELAY }, { "PHAS", FX_PHASER }, { "TREM", FX_TREM },
                              { "ROT", FX_ROTARY }, { "DIST", FX_DIST }, { "CMPR", FX_COMP }, { "COMP", FX_COMP }, { "EQ", FX_EQ } };
    int first[10]; for (int& f : first) f = 1000;
    for (const Tok& t : toks)
    {
        const char* at = strstr (s, t.text);
        if (at && (int) (at - s) < first[t.kind]) first[t.kind] = (int) (at - s);
    }
    for (int round = 0; round < 6; ++round)                // order by first appearance
    {
        int best = -1;
        for (int k = 1; k <= FX_EQ; ++k) if (first[k] < 1000 && (best < 0 || first[k] < first[best])) best = k;
        if (best < 0) break;
        plan.kind[plan.n++] = (uint8_t) best; first[best] = 1000;
    }
    plan.hasEq = strstr (s, "EQ") != nullptr;
    if (strstr (s, "LARGE")) { plan.reverbRt60 = 1.4f; plan.reverbSize = 1.2f; }
    else if (strstr (s, "SMALL")) { plan.reverbRt60 = 0.5f; plan.reverbSize = 0.6f; }
    else if (strstr (s, "HALL")) { plan.reverbRt60 = 2.6f; plan.reverbSize = 1.3f; }
    else if (strstr (s, "HOUSE")) { plan.reverbRt60 = 1.5f; plan.reverbSize = 1.0f; }
    else if (strstr (s, "ROOM")) { plan.reverbRt60 = 0.9f; plan.reverbSize = 0.7f; }
    else if (strstr (s, "DENSE")) { plan.reverbRt60 = 2.0f; plan.reverbSize = 1.1f; }
    if (strstr (s, "BPM")) plan.delayTime = 0.5f;
    return plan.implemented();
}

class Fx
{
public:
    void prepare (float sampleRate)
    {
        sr = sampleRate < 8000.f ? 8000.f : (sampleRate > kMaxRate ? kMaxRate : sampleRate);
        configure (curName);
    }
    // audio thread, no allocation. Clears all effect memory.
    void configure (const char* name)
    {
        if (name != curName) { strncpy (curName, name ? name : "", 12); curName[12] = 0; }     // prepare() re-configures with its own name
        fxPlanFromName (curName, plan);
        memset (mem, 0, sizeof mem);
        rvPos = 0; chPos = 0; dlPos = 0;
        for (int i = 0; i < 8; ++i) { rvLp[i] = 0.f; rvPosI[i] = 0; }
        lfo1 = lfo2 = 0.f; envC = 0.f; for (int c = 0; c < 2; ++c) for (int k = 0; k < 4; ++k) apZ[c][k] = 0.f; fbZ[0] = fbZ[1] = 0.f; dlLp[0] = dlLp[1] = 0.f;
        const float scale = sr / 44100.f * plan.reverbSize;
        static const int base[8] { 1117, 1367, 1559, 1783, 1999, 2203, 2467, 2801 };   // mutually prime lengths at 44.1 kHz
        for (int i = 0; i < 8; ++i)
        {
            int l = (int) ((float) base[i] * scale); l = l < 64 ? 64 : (l > kRvMax - 1 ? kRvMax - 1 : l);
            rvLen[i] = l;
            rvGain[i] = powf (10.f, -3.f * (float) l / (sr * plan.reverbRt60 * 1.25f));   // x1.25: the damping filters shorten the measured time
        }
        preLen = (int) (0.012f * sr * (plan.reverbSize > 1.f ? 1.6f : 1.f)); if (preLen > kPre - 1) preLen = kPre - 1;
    }
    void setLevel (float l) { level = l < 0.f ? 0.f : (l > 2.f ? 2.f : l); }     // 0 = bypass, 1 = default wet, 2 = more
    const FxPlan& getPlan() const { return plan; }
    const char* name() const { return curName; }

    void process (float* L, float* R, int n)
    {
        if (level <= 0.f || plan.implemented() == 0) return;
        for (int i = 0; i < plan.n; ++i)
        {
            switch ((FxKind) plan.kind[i])
            {
                case FX_REVERB: reverb (L, R, n); break;
                case FX_CHORUS: chorus (L, R, n); break;
                case FX_DELAY:  delay (L, R, n); break;
                case FX_PHASER: phaser (L, R, n); break;
                case FX_TREM:   tremolo (L, R, n, 4.5f, 0.5f, false); break;
                case FX_ROTARY: tremolo (L, R, n, 5.5f, 0.35f, true); break;
                case FX_DIST:   dist (L, R, n); break;
                case FX_COMP:   comp (L, R, n); break;
                default: break;
            }
        }
    }

private:
    static constexpr float kMaxRate = 96000.f;
    static constexpr int kRvMax = 8192 * 2, kPre = 4096, kCh = 4096, kDl = 70000;
    static inline float flush (float v) { return (v > -1e-18f && v < 1e-18f) ? 0.f : v; }

    // ---- 8-line feedback delay network reverb (orthogonal mixing matrix: stable for any gains below 1) ----
    void reverb (float* L, float* R, int n)
    {
        float* base = mem;
        float* lines[8]; for (int i = 0; i < 8; ++i) lines[i] = base + (size_t) i * kRvMax;
        float* pre = base + (size_t) 8 * kRvMax;
        const float damp = 0.35f, wet = 0.22f * level;
        for (int s = 0; s < n; ++s)
        {
            const float in = 0.5f * (L[s] + R[s]);
            pre[rvPos] = in;
            const float x = pre[(rvPos + kPre - preLen) % kPre] * 0.35f;
            float o[8], f[8];
            for (int i = 0; i < 8; ++i)
            {
                o[i] = lines[i][rvPosI[i]];
                rvLp[i] += (o[i] - rvLp[i]) * (1.f - damp);
                f[i] = rvLp[i] * rvGain[i];
            }
            // fast Walsh-Hadamard transform, scaled to be orthogonal
            for (int h = 1; h < 8; h <<= 1)
                for (int a = 0; a < 8; a += h << 1)
                    for (int b = a; b < a + h; ++b) { const float u = f[b], v = f[b + h]; f[b] = u + v; f[b + h] = u - v; }
            const float k = 0.35355339f;
            for (int i = 0; i < 8; ++i)
            {
                lines[i][rvPosI[i]] = flush (f[i] * k + ((i & 1) ? -x : x));
                if (++rvPosI[i] >= rvLen[i]) rvPosI[i] = 0;
            }
            const float wl = (o[0] - o[2] + o[4] - o[6]) * 0.5f, wr = (o[1] - o[3] + o[5] - o[7]) * 0.5f;
            L[s] += wl * wet * 2.f; R[s] += wr * wet * 2.f;
            if (++rvPos >= kPre) rvPos = 0;
        }
    }

    // ---- chorus: two modulated delays, one per side ----
    void chorus (float* L, float* R, int n)
    {
        float* b0 = mem + (size_t) 8 * kRvMax + kPre;      // the chorus's own region, behind the reverb's
        float* bl = b0; float* br = b0 + kCh;
        const float rate1 = 0.35f / sr, rate2 = 0.55f / sr, mix = 0.5f * level;
        const float c1 = 0.014f * sr, c2 = 0.020f * sr, dep = 0.003f * sr;
        for (int s = 0; s < n; ++s)
        {
            bl[chPos] = L[s]; br[chPos] = R[s];
            lfo1 += rate1; if (lfo1 >= 1.f) lfo1 -= 1.f;
            lfo2 += rate2; if (lfo2 >= 1.f) lfo2 -= 1.f;
            const float d1 = c1 + dep * sinf (6.2831853f * lfo1), d2 = c2 + dep * sinf (6.2831853f * lfo2 + 1.7f);
            L[s] += mix * (tap (bl, d1, kCh) + 0.4f * tap (br, d2, kCh) - L[s] * 0.4f);
            R[s] += mix * (tap (br, d2, kCh) + 0.4f * tap (bl, d1, kCh) - R[s] * 0.4f);
            if (++chPos >= kCh) chPos = 0;
        }
    }
    float tap (const float* b, float d, int size) const          // linear-interpolated read `d` samples behind chPos
    {
        float p = (float) chPos - d; while (p < 0.f) p += (float) size;
        int i = (int) p; const float f = p - (float) i; int j = i + 1; if (j >= size) j -= size; if (i >= size) i -= size;
        return b[i] + (b[j] - b[i]) * f;
    }

    // ---- stereo delay with darkening feedback ----
    void delay (float* L, float* R, int n)
    {
        float* dl = mem + (size_t) 8 * kRvMax + kPre + 2 * kCh; float* dr = dl + kDl;
        const float t = plan.delayTime > 0.f ? plan.delayTime : 0.33f;
        int lenL = (int) (t * sr), lenR = (int) (t * 1.33f * sr);
        lenL = lenL < 16 ? 16 : (lenL > kDl - 1 ? kDl - 1 : lenL); lenR = lenR < 16 ? 16 : (lenR > kDl - 1 ? kDl - 1 : lenR);
        const float fb = 0.38f, mix = 0.32f * level;
        for (int s = 0; s < n; ++s)
        {
            const float el = dl[(dlPos + kDl - lenL) % kDl], er = dr[(dlPos + kDl - lenR) % kDl];
            dlLp[0] += (el - dlLp[0]) * 0.55f; dlLp[1] += (er - dlLp[1]) * 0.55f;
            dl[dlPos] = flush (L[s] + dlLp[1] * fb); dr[dlPos] = flush (R[s] + dlLp[0] * fb);    // cross-fed
            L[s] += el * mix; R[s] += er * mix;
            if (++dlPos >= kDl) dlPos = 0;
        }
    }

    // ---- four-stage phaser ----
    void phaser (float* L, float* R, int n)
    {
        const float rate = 0.4f / sr, mix = 0.5f * level;
        for (int s = 0; s < n; ++s)
        {
            lfo1 += rate; if (lfo1 >= 1.f) lfo1 -= 1.f;
            float* ch[2] { L, R };
            for (int c = 0; c < 2; ++c)
            {
                const float ph = lfo1 + (c ? 0.25f : 0.f);
                const float f = 300.f * powf (10.f, 1.f * (0.5f + 0.5f * sinf (6.2831853f * ph)));   // 300 Hz .. 3 kHz
                const float t = tanf (3.14159265f * f / sr), a = (t - 1.f) / (t + 1.f);
                float x = ch[c][s] + fbZ[c] * 0.3f, y = x;
                for (int k = 0; k < 4; ++k) { const float v = a * y + apZ[c][k]; apZ[c][k] = flush (y - a * v); y = v; }
                fbZ[c] = y;
                ch[c][s] = ch[c][s] * (1.f - 0.5f * mix) + y * mix;
            }
        }
    }

    // ---- tremolo (both sides together) / rotary speaker approximation (sides in opposition) ----
    void tremolo (float* L, float* R, int n, float hz, float depth, bool opposed)
    {
        const float rate = hz / sr;
        for (int s = 0; s < n; ++s)
        {
            lfo2 += rate; if (lfo2 >= 1.f) lfo2 -= 1.f;
            const float m = 0.5f + 0.5f * sinf (6.2831853f * lfo2);
            L[s] *= 1.f - depth * level * m;
            R[s] *= 1.f - depth * level * (opposed ? 1.f - m : m);
        }
    }

    void dist (float* L, float* R, int n)
    {
        const float drive = 1.f + 3.f * level, norm = 1.f / tanhf (drive);
        for (int s = 0; s < n; ++s) { L[s] = tanhf (L[s] * drive) * norm; R[s] = tanhf (R[s] * drive) * norm; }
    }

    // ---- feed-forward compressor: threshold -18 dB, ratio 4:1, make-up to match ----
    void comp (float* L, float* R, int n)
    {
        const float att = 1.f - expf (-1.f / (0.005f * sr)), rel = 1.f - expf (-1.f / (0.12f * sr));
        const float thr = 0.125f, make = 1.6f;
        for (int s = 0; s < n; ++s)
        {
            const float a = fabsf (L[s]) > fabsf (R[s]) ? fabsf (L[s]) : fabsf (R[s]);
            envC += (a - envC) * (a > envC ? att : rel);
            const float g = envC > thr ? powf (envC / thr, 1.f / 4.f - 1.f) : 1.f;
            L[s] *= g * make; R[s] *= g * make;
        }
    }

    float sr = 44100.f, level = 1.f;
    FxPlan plan;
    char curName[13] {};
    float mem[8 * kRvMax + kPre + 2 * kCh + 2 * kDl] {};
    int rvPos = 0, chPos = 0, dlPos = 0, rvLen[8] {}, rvPosI[8] {}, preLen = 0;
    float rvGain[8] {}, rvLp[8] {}, lfo1 = 0.f, lfo2 = 0.f, envC = 0.f, apZ[2][4] {}, fbZ[2] {}, dlLp[2] {};
};
} // namespace ens
