# ASR10 (MPC)

Ensoniq ASR-10 sampler character as a **native MPC OS VST2 insert effect** for the MPC X (and the other Gen1
devices), built from the GlueBus / SP1200 components: the same dependency-free VST2 core, parameter/preset model,
installer, packaging and skin pipeline (tested on an MPC X with SP1200).

- **Signal path:** input > 16-bit sigma-delta ADC at **30 kHz** (29.76, band-limited ~13.4 kHz, the dark ASR sound)
  or **44.1 kHz** > OTTO playback with **linear interpolation** (tuning = read rate) > OTTO **4-pole filter** (Filter 1 /
  Filter 2, the chip's four modes, 6-24 dB/oct, no resonance) > 16-bit DAC > mix / volume. Details and sources: `docs/CIRCUIT.md`
- **Tuning:** -12 .. +12 semitones plus Fine -50 .. +50 cents; *Pitch* mode (interpolated pitch shift, within a few
  cents in the tests) or *Rate* mode (tune changes the sampling rate, pitch stays)
- **ASR-10 style screen, no pads or keys (it's an effect):** floppy drive, the ASR-10's **two sliders (Volume and Data
  Entry)**, Edit buttons under a blue-green display ("TUNE +3"), grey keys with red LEDs for the modes. Press an Edit
  button, move Data Entry, like the hardware; Q-Links still reach every parameter. See `docs/skin-preview.png`
- 36 presets for drums, loops, pitch / rate tricks, keys, bass and textures (list in `mpc/INSTALL.md`)
- Links only libc + libm. Installs to `/sdcard/vst/asr10.so`, skin to `/sdcard/Synths/GlueBus - VST - ASR10/`

## Ensoniq disk support (in progress)
`src/ensoniq/` reads Ensoniq EPS / EPS-16+ / ASR-10 disks: raw IMG / ISO, HFE, Giebler EDE / EDA, GKH and
EFE / EFA, with the full directory tree, FAT chains and bank files, following EpsLin v1.42's source and
cross-checked against disks EpsLin writes (`make crosscheck EPSLIN=...`). `ensoniq_inspect` lists, extracts, shows
banks and probes instruments. `src/ensoniq/ens_instrument_file.*` parses ASR-10 instrument files (layers, key maps,
velocity windows, wavesample audio, copies, root key, sample rate, fractional loops), decoded from the 581
instruments of the ASR Demo CD-ROM and checked against the audio: `docs/ENSONIQ_FORMATS.md` section 3 lists every
field as verified, inferred or not decoded. `src/engine/` is the sample engine that plays them (OTTO-style playback
and filter, Ensoniq loop modes, envelopes and layers, 31 / 20 voices): `docs/ENGINE.md`. **Envelopes, filter and LFO
of loaded instruments are not decoded yet, so they play as raw samples, not as the hardware sounds.** There is no
`asr10_inst.so` is a separate VST2 instrument that plays them (`mpc/INSTALL_INST.md`): raw playback, no skin, **not yet run on an MPC**. `docs/ROADMAP.md` has the status and plan.

## Build + install
    make test                         # native x86 build + offline VST2 host test + Ensoniq parser tests
    make inspect                      # build/native/ensoniq_inspect (make inspect-arm for the MPC)
    make realtest ISO=demo-cd.iso     # parse + play every instrument on an ASR CD image (you supply the image)
    make inst-test                    # ASR10 Instrument through an offline VST2 host (ASan/UBSan)
    ./scripts/package_inst.sh         # ARM build of the instrument, dist/ASR10-Instrument-0.1.0-mpc-armv7.zip
    make arm-all check-arm            # both plugins with a cross g++; check-arm compares them to the known-good effect build
    # no toolchain? push to GitHub: .github/workflows/arm.yml builds and checks both in armv7 containers, zips as artifacts
    make render                       # build/native/ensoniq_render IMAGE "DIR/NAME" out.wav [key[:vel] ...]
    ./scripts/package.sh              # ARM build, ELF checks, dist/ASR10-1.2.0-mpc-armv7.zip
    python3 tools/make_skin.py docs/skin-preview.png   # regenerate the skin (needs Pillow)
Device install (Terminus): `mpc/INSTALL.md`.

## Not covered / unverified
- Not yet run on an MPC. The skin reuses SP1200's rules that work on an MPC X (square fader frames, skin folder
  `<manufacturer> - VST - <plugin>`), but new here: labels bound to parameters as a display, the 6-key Edit group,
  and Data Entry as a proxy parameter (the plugin tells MPC to redraw when the selection changes).
- Not compared against recordings of a real ASR-10; the ESP effects chip is not modelled.
