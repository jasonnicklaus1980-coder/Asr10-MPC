# ASR-10 / EPS-16+ sample engine (src/engine)

What the engine does, what each behaviour is based on, and which parts are choices that still need checking
against a real ASR-10. `make test` runs `test/engine_test.cpp`, which covers every point in the first table.

## Modelled, with a source

| Behaviour | Source | Tested |
|---|---|---|
| Each wavesample plays at its own recorded rate; pitch = read speed | Ensoniq manuals; MAME es5506.cpp | 12 cases, 44.1 and 48 kHz host, within 3 cents |
| Linear interpolation between neighbouring samples, no band-limiting: pitching up aliases, as the OTTO chip does | MAME es5506.cpp | 27 kHz tone folds to 17.1 kHz at -12.6 dB |
| OTTO filter: 4 one-pole stages, 2 cutoffs, 4 modes, no resonance (same model as the ASR10 effect) | MAME es5506.cpp, docs/CIRCUIT.md | 4 kHz 36 dB down with a 1 kHz 4-pole low-pass |
| 16-bit output | ASR-10 spec | a -86 dB tone gives 3 output levels |
| 31 voices (ASR-10) / 20 (EPS-16+), oldest released voice stolen first | Wikipedia spec sheets | voice counts |
| Up to 8 layers, velocity windows, patch selects switching layers | Ensoniq manuals, Wikipedia | key split, velocity layers, patch select |
| Mono layers, note-off-triggered layers, sustain pedal | Ensoniq manuals | yes |
| Loop modes: forward once, backward once (reverse), loop forward, loop bidirectional, loop and release | SysEx parameter list (via epstool) | all 5 |
| Envelopes: 5 levels with soft and hard values chosen by velocity, 4 times, release; pitch, filter and amplitude | SysEx parameter list (via epstool) | velocity 1 vs 127 sustain ratio 0.206 (expected 0.206) |
| BOOST (+12 dB per wavesample) | ASR-10 manual | - |
| Disk instruments: a layer's key map picks the wavesample per key; copies share audio | real instruments (docs/ENSONIQ_FORMATS.md section 3) | 581 real instruments parsed and played, none unsafe |
| Fractional loop points (tuned loops, e.g. end 262.75) with the interpolator reading data past the loop end | real instruments | synthetic tuned loop within 3 cents; real organ within 9 cents of its root key |
| Instrument swap while playing: loader thread hands over, audio thread swaps, old one freed off the audio thread | - | 2000 swaps under load, each freed once; ThreadSanitizer clean |

## Choices that still need a real ASR-10 to confirm

- **Mix level before the 16-bit DAC**: -6 dB (a chosen headroom value, not measured). Too little would clip chords, too much would lose resolution.
- **Envelope segments are straight lines**. Whether Ensoniq's are linear or exponential, and how the 0-99 settings map to seconds, is unknown.
- **Pan is constant-power**. The hardware's pan steps are not documented.
- **Voice stealing is a hard cut**, as a chip voice being reassigned would be.
- **Note-off layers run through their envelope to the sustain level and then release.**
- **LFO**: triangle, sine, saw up, saw down, square and noise; its delay is treated as a fade-in.
- **Output rate**: voices are rendered at the host rate. The chip's own output rate, and any imaging it adds, is not modelled.
- **Differences between ASR-10 and EPS-16+ mode**: only the voice count so far. Other differences (converter, output stage) need recordings from both machines.

## Not yet implemented

Transwave (start/loop modulation), the 15-source modulation routing, aftertouch, random modulation, layer
crossfades, the EPS classic's 13-bit samples, and the effects (ESP chip).

**Loaded instruments currently run with neutral envelopes (instant attack, full sustain, 0.1 s release), no filter
and no LFO**, because those parameters are stored but not decoded yet (they are kept in `WaveSample::raw`). The
engine can do all three; what is missing is the mapping from the stored values to times, levels and cutoffs.
Until that is decoded a loaded instrument plays its raw samples (correct key map, velocity layers, rate, pitch and
loops) and will not sound like the hardware.

## CPU

31 voices with filters and LFO: 42x realtime on one 2.1 GHz Xeon core (`-O2`). The MPC's ARM cores are
several times slower, so this has to be measured on the device.
