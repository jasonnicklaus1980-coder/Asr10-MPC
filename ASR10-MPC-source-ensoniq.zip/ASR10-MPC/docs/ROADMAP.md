# Roadmap: ASR-10 / EPS-16+ emulation for MPC

Status of each part of the project brief. The rule throughout: nothing is called authentic until it has been
tested against real files or real hardware.

## Where things stand

| Brief section | Status |
|---|---|
| 8.1-8.3 Existing plugin examined and preserved | Done. `asr10.so` (insert effect, 1.2.0) is unchanged and its tests still pass. |
| 8.4 Research the formats | Done for what is public: `docs/ENSONIQ_FORMATS.md`, with confidence per field. |
| 1 / 6 Disk images and file system | Done. Raw IMG / ISO / HDA, HFE v1 (incl. 2550 / 5100 KB layouts), Giebler EDE / EDA, GKH, EFE / EFA; directories, FAT chains, labels, OS versions. Layouts from EpsLin's source; cross-checked byte for byte against EpsLin-written disks; real Ensoniq OS files read correctly. |
| 1 Bank parser | Done (EpsLin layout), matches `epslin -b`. Not yet checked on a hardware-saved bank. |
| 1 Instrument parser (ASR-10) | **Done for what plays back**: block structure, layers, key maps, velocity windows, wavesample audio, copies, root key, rate, fractional loops, patch-select masks. Decoded from 581 real ASR-10 instruments and checked against the audio (`docs/ENSONIQ_FORMATS.md` section 3). **Not decoded:** envelopes, filter, LFO, layer flags, volume / pan curves; rate word 0 is estimated. EPS-16+ and EPS classic files have not been tried (none available). |
| 2 Sound engine | Core done (`src/engine`, `docs/ENGINE.md`), tested on synthetic instruments and on all 581 real ones: per-wavesample rate, OTTO interpolation and filter, 5 loop modes, velocity-switched envelopes, layers, patch selects, mono / note-off layers, 31 / 20 voices, realtime-safe instrument swapping. Not yet: transwave, modulation routing, effects. Unconfirmed choices listed in ENGINE.md. |
| Instrument plugin (brief section 2 / 5) | **Built, raw playback only, not run on an MPC.** `src/asr10_inst.cpp` -> `asr10_inst.so`, a VST2 instrument (`isInstrument=1`) next to the effect: scans `/sdcard/Ensoniq` for images and `.efe` files, DISK / INSTRUMENT parameters select, loading on a worker thread with realtime-safe swap, MIDI (velocity, sustain, bend, mod wheel, sample-accurate timing), project chunk (disk + instrument by name), 31 / 20 voices. Tested offline through the VST2 API (ASan, UBSan and ThreadSanitizer clean; 21 of 21 sampled real instruments sound). Installer, uninstaller and `scripts/package_inst.sh` exist; the installer was tested against a fake device root only. **Skin** in the effect's ASR-10 style (`tools/make_skin_inst.py`, preview `docs/skin-preview-instrument.png`): display, Volume and Instrument sliders, disk / instrument step keys, patch, voices, rescan; generated with the effect's proven pipeline but **untested on a device**.   **the ARM build has not been made**: this environment has no ARM toolchain, Docker or network. Everything needed is in place: `make arm-all` (cross g++), `make docker` / `docker-inst` (armv7 containers), `.github/workflows/arm.yml` (builds and checks both on GitHub), and `scripts/check_arm.sh`, which holds a built `.so` to the exact ELF flags and ARM attributes of the known-good `asr10.so` (verified here: accepts it, rejects an x86 build). The ARM flags are identical to the effect's. |
| 3 Effects | **Approximations only** (`src/dsp/fx_approx.h`, tested by `make fx-test`): the effect named in an instrument is played as a generic reverb / chorus / delay / phaser / tremolo / rotary / distortion / compressor chain with fixed defaults (485 of the 546 effect-bearing CD instruments get one). Not the ASR-10's own programs: the ES5510 chip is **not** emulated, the stored settings are not decoded, EQ is passed through. Real emulation needs the chip's instruction format, and the blocks also contain 68000 parameter-handling code (see below). Not compared with hardware. Was: Not started. See the note on the ESP chip below. |
| 4 Presets | Not started. See the note on factory sounds below. |
| 5 Interface | Not started. See the note on MPC skins below. |
| 8.9 Test on the MPC | Not possible here: no ARM toolchain or MPC in this environment. `make inspect-arm` and `scripts/package.sh` build for it on your machine. |

## What unblocks the rest of the instrument format
The demo CD settled structure, key maps, loops and pitch. To finish the sound: (1) **hardware reference for the
envelopes, filter and LFO**: a few instruments whose envelope times and filter cutoffs are read off the ASR-10's
screens (or recordings of one note played on the hardware), so the stored values can be mapped to seconds and
Hz; (2) **EPS-16+ and EPS classic instrument files** to see whether they differ; (3) a **stereo** wavesample if
one exists; (4) a recording of a word-131-equals-0 instrument against the hardware's pitch to settle 47,619 vs
48,000 Hz. `ensoniq_render` (make render) plays any instrument on an image through the engine to a WAV.

## Planned order after that
1. **Instrument parser**: done for ASR-10 (above). Left: decode envelopes / filter / LFO, EPS-16+ and EPS classic
   variants. Unknown fields are kept raw and listed in the loader's report.
2. **Instrument plugin**: built (see the table). Left: a device test (does MPC show the parameter strings and accept the MIDI path; does the
   worker thread's libpthread dependency load), bank loading, and Load-page style browsing inside one image.
3. **Effects**: see below.
4. **MPC screen and on-device testing**.

## Constraints that change parts of the brief

**MPC skins.** On Gen1 MPC OS a VST2 plugin has no screen of its own: MPC draws a JSON skin whose controls are
each bound to one plugin parameter, and text labels show parameter values (that's how the current Data Entry
display works). So a file browser becomes a Disk / Instrument selector driven by Data Entry, with the names on
the display line, like the ASR-10's own Load page. A live waveform display and a drawn keyboard map are not
possible with that system as far as the existing skin work has found.

**Effects.** The EPS-16+ and ASR-10 effects run on Ensoniq's ESP chip (ES5510), and the effect programs are
microcode stored in effect and instrument files. The authentic route is emulating the ES5510 running that
microcode (MAME has an ES5510 core to learn from), which reproduces any effect on the user's disks, including
third-party ones. That is a large piece of work and CPU-heavy on the MPC; lighter approximations are possible
but would be labelled as approximations, not original algorithms.

**Factory presets.** Ensoniq's factory library is copyrighted and can't be shipped with the plugin. The plugin
can load it from the user's own disks, with the original names. The 36 presets in the current effect are
GlueBus's own and stay labelled that way.
