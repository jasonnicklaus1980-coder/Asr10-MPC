# Ensoniq EPS / EPS-16+ / ASR-10 file formats

What the parsers in `src/ensoniq/` assume, where each point comes from, and how sure it is. The EPS, EPS-16+
and ASR-10 share one disk file system; they differ inside the instrument files.

Confidence levels used below:
- **Sourced**: described the same way by more than one independent source.
- **Single source**: one source only, or worked out by someone from example files.
- **Unknown**: not publicly documented; the code finds it by trial or leaves it out, and says so.

Primary source since 2026-09-30: the C source of **EpsLin v1.42** (Juha Forsten, GPL; the Windows build
`eps_lin_lu2.c` shipped in the Ensoniq_EFE2HFEv2 toolkit), a tool that has read and written real Ensoniq disks
for years. Where this document says "EpsLin", the layout was taken from that code.

Three levels of testing:
- **Unit tests** (`make ensoniq-test`): synthetic images built from this description.
- **Cross-check** (`tools/crosscheck_epslin.sh`): EpsLin, compiled for Linux, formats ASR-10 and EPS disks, puts
  files on them and converts them to EDA / EDE; our reader must return every file byte-identical. 22 / 22 pass.
- **Real files**: Ensoniq's own ASR-10 OS 1.61 and 3.53 and EPS-16+ OS files (Giebler EFE) parse correctly, and
  OS 3.53 written to a disk by EpsLin reads back byte-identical with its version (3.53) from the OS block.
  A real blank ASR-10 HD floppy supplied as both IMG and HFE: the HFE decodes with no bad or missing sectors
  and is identical to the IMG over all 3200 blocks; label "DISK000", 3176 free blocks (the ASR-10 manual's
  figure for an Ensoniq-format HD disk), 19 FAT blocks, block 0 filled with 0x6D.
Still missing: any instrument.

## 1. Disk file system (floppy, SCSI, CD-ROM) — implemented, tested

| Block | Content | Confidence |
|---|---|---|
| 0 | unused | Sourced |
| 1 | Device ID block: total blocks big-endian at 14-17, SCSI medium type 18, density 19, disk label 31-37, `"ID"` at 38-39 | Sourced, EpsLin |
| 2 | OS block: free-block count at 0-3, OS version on disk 4-5, ROM OS version 6-7, `"OS"` at 28-29 | Sourced, EpsLin |
| 3-4 | Root directory: 39 entries x 26 bytes, `"DR"` at bytes 1022-1023 | Sourced |
| 5.. | FAT: 170 entries x 3 bytes big-endian per block, `"FB"` at 510-511. 0 = free, 1 = end of file, 2 = bad, else next block | Sourced |

Blocks are 512 bytes and all numbers are big-endian (68000 CPU). A DD floppy has 1600 blocks (80 tracks,
2 sides, 10 sectors), an HD floppy 3200 (20 sectors). SCSI and CD-ROM use the same layout with a longer FAT.

**Directory entry (26 bytes):** 0 type-dependent byte, 1 file type, 2-13 name (12 ASCII, space padded),
14-15 size in blocks, 16-17 contiguous blocks, 18-21 first block, 22 multi-file index, 23-25 reserved.
Subdirectories are type 2 and point at their own 2-block directory, which holds a type 8 entry back to the
parent. Confidence: Sourced, EpsLin. EpsLin rebuilds free blocks of EDE/EDA images with the pattern 6D B6; the
real blank floppy has zeros in its free blocks. Free blocks are never read as file data, so this doesn't matter.

**File types (EpsLin):** 1 EPS OS, 2 directory, **3 instrument (all three samplers)**, 4 EPS bank, 5 EPS sequence,
6 EPS song, 7 EPS SysEx, 8 parent pointer, 9 EPS macro; 23 EPS-16+ bank, 24 EPS-16+ effect, 25 EPS-16+ sequence,
26 EPS-16+ song, 27 EPS-16+ OS; 28 ASR sequence, 29 ASR song, 30 ASR bank, 31 ASR audio track, 32 ASR OS,
33 ASR effect. Confirmed on the real OS files (ASR OS = 32, EPS-16+ OS = 27). The epstool write-up's "0x19 =
EPS-16+ instrument" is wrong: 0x19 = 25 is an EPS-16+ sequence.

The reader follows each file's FAT chain and checks that its length matches the directory size, so a damaged
or misread disk is reported ("FAT chain ends after 2 of 4 blocks") rather than returning short data.

## 2. Containers — implemented, tested

**Raw image** (`.img`, `.iso`, `.hda`, OmniFlop / dd / Greaseweazle sector dumps, CD-ROM images): block N at byte
N x 512. Recognised by the ID / DR signatures. Large images are read from storage block by block, never loaded
whole. Sourced.

**HFE v1** (HxC floppy emulator, Gotek): `"HXCPICFE"` header, track table, track data in 256-byte chunks
alternating side 0 and side 1, bits LSB first, MFM encoded. The decoder finds the A1 sync marks, reads the ID and
data address marks, checks both CRCs, and maps sector (track, side, R) to block
`(track x sides + side) x sectors + (R - lowest R)`. Missing or bad sectors are counted and read as zeros.
HFE v3 (`"HXCHFEV3"`) is refused with a message. Sourced (HxC's published format); confirmed on a real
ASR-10 HD floppy image (500 kbit/s, 80 tracks, 20 sectors), which decodes identical to its IMG.

**Giebler disk image** (`.ede` EPS / EPS-16+, `.eda` ASR-10), EpsLin: 512-byte header (CR LF, "EPS-16 Disk" or
"ASR-10 Disk", ID byte at 511: 0x03 EDE, 0xCB EDA), skip bitmap at 0xA0 / 200 bytes (EDE, 1600 blocks) or
0x60 / 400 bytes (EDA, 3200 blocks), most significant bit first, **set bit = block not stored** (it was free in the
FAT), then the stored blocks in order and one 0x1A byte. Skipped blocks are rebuilt with the 6D B6 fill. Files
from some Mac tools have every 0x0A expanded to 0x0D 0x0A; they start 0D 0D 0A and are converted back.
Cross-checked against EpsLin-written EDA and EDE files. (The trial-and-error detection used before this source
was found has been removed.)

**GKH**, EpsLin: little-endian ("II") tagged file, tag count at 6-7, 10-byte tags from offset 8; tag 0x0A holds
the geometry (three 16-bit values whose product is the block count), tag 0x0B the image length and offset.
Motorola-order GKH is not supported (EpsLin doesn't either). Not yet tested on a real GKH file.

**Giebler single file** (`.efe`, `.efa`, ...), EpsLin, confirmed on real OS files: 0-1 CR LF, 2 "Eps File:",
0x12-0x1D name, 0x1E type text, 0x2F-0x31 CR LF 0x1A, **0x32 file type**, 0x34-0x35 size in blocks,
0x36-0x37 contiguous blocks, 0x38-0x39 start block (low word), 0x3A multi-file part index; the file's blocks
follow from 0x200. The reader checks the block count against the data length.

**HFE extended layouts:** the HxC layouts in the toolkit use sector IDs starting at 0 (matches the decoder) and
also define 2550 KB (EPS-16+) and 5100 KB (ASR-10, 255 tracks) extended floppies; the HFE decoder accepts up to
255 tracks.

**Not supported yet:** HFE v3, Motorola-order GKH, Mirage disks.

## 3. Instrument file — layout decoded from 581 real ASR-10 instruments (`src/ensoniq/ens_instrument_file.*`)

Worked out from the ASR-10 Demo CD-ROM (581 instrument files, 12,102 wavesamples), starting from the parameter
list in the SysEx spec as quoted by epstool (which documents the original EPS only). Every field below is marked
**verified** (checked against the audio or against structure in all files), **inferred** (consistent with the
data, no independent check) or **not decoded**. `make realtest ISO=...` re-runs the checks; the file is data, not
a copy of any other project's code.

**Blocks.** After a fixed 0x290-byte header the file is a sequence of blocks that tile it exactly (true for all
581 files). Each block starts with a 10-byte header. *Size* in bytes = (b0 | (b3 >> 4) << 8 | b2 << 12) × 16
(**verified**: it predicts the next block in every file; an audio-length rule did not). *Block id* = (b4 << 8 | b5)
>> 6 (**verified**): 17-24 pitch tables, 25-32 layers 1-8, 34-160 wavesamples 1-127, 162 effect, and one id-33
trailer block (0x80-0x1D0 bytes) per file (**not decoded**). File order is *not* layer membership.

**Header (0x290 bytes).** Name: 12 characters at 0x0A, one per 16-bit word, in the high byte (**verified**). Patch
select masks: high bytes of the words at 0x2C, 0x2E, 0x30, 0x32, one bit per layer (**inferred**: e.g. 3,12,48,192
on an 8-layer drum kit, 3,3,3,3 on a 2-layer organ). An allocation-like table at 0x66-0x118 is **not decoded**
and not needed. Effect blocks (0x680 bytes, or other sizes) sit before or after the layers: skipped.

**Layer block (0xE0 bytes).** Name at +0x0A (12 words). Velocity window: high bytes of the words at +0x28
(low) and +0x2A (high) (**verified**: a 3-layer Rhodes reads 0-40 / 41-110 / 111-127). Key map: 88 words at +0x30,
high byte = wavesample **number**, for keys 21-108 (**verified**: 7,427 of 7,431 entries lie inside their
wavesample's own key range). Keys outside 21-108 use the edge entry (**assumed**). Other words (mono, glide,
pitch table, note-off trigger) are **not decoded**.

**Wavesample block (0x120 bytes of parameters, then audio).** 139 parameter words starting at +0x0A, value in the
high byte, numbered as in the SysEx list. Audio follows the parameters: big-endian signed 16-bit, length = the rest
of the block (it extends a few samples past the sample end and loop end, which the interpolator reads across).
A *copy* wavesample (word 12 = number of the wavesample it copies) has no audio and shares the original's
(**verified**: 7,246 of 7,247 referents exist and 94 % keep the same end point; word 13 is not needed).

| Word | Field | Status |
|---|---|---|
| 0-11 | name (first two words carry extra low-byte data) | verified |
| 12 | copy of wavesample number (0 = original) | verified |
| 14-79 | three 22-word envelopes (pitch, filter, amplitude) | kept raw, **not decoded** |
| 80 | root key | **verified** by measured loop pitch (39 exact-semitone matches at 29.76 kHz; 4 more rates agree) |
| 86 | fine tune, signed | **inferred**: pitch error correlates (r = -0.41, n = 127), about 0.6 cents per unit; scale not exact |
| 88-98 | filter mode, cutoffs, amounts | raw, **not decoded** (the engine runs with the filter open) |
| 99 | volume 0-127 | used as linear gain / 127 (**approximation**) |
| 105 | pan: 3 default, 0 / 7 extremes | **inferred**; values above 7 (about 1 %) treated as centre |
| 107-113 | LFO | raw, **not decoded** |
| 114 | loop mode 0-4 | verified (loop join test below) |
| 115-130 | start, end, loop start, loop end: four high bytes each, >> 9 = sample, low 9 bits = fraction | **verified**: decoded loops join with median jump 0.74 slopes vs 7.3 when shifted, 89 % vs 31 % clean |
| 131 | sample rate | see below |
| 132-133 | key range | verified (matches the key map) |

Sample end is the index of the last real sample. Loop points are **fractional** (a loop end such as 262.75 tunes
the loop to a whole number of periods), so the engine keeps them as doubles and reads data past the loop end.

**Sample rate (word 131).** 12-70: rate = 625,000 / word Hz (**verified**: 21 = 29,761.9 Hz, the ASR-10's own
rate, plus 14, 16, 20; measured from tuned-loop lengths to within 0.1-0.3 %). 1: 44,100 Hz (**verified**, measured
44,026 ± 0.3 %). 0: measured at 47,723 Hz ± 0.3 %; the parser uses **47,619 Hz (= 1 / 21 µs) as an estimate**, and
48,000 Hz cannot be excluded; 1,591 wavesamples (13 %) use it. Other values (27 wavesamples) are unknown and
play at 29,761.9 Hz with a warning.

**Known gaps:** envelopes, filter, LFO, layer flags, bend range units, the volume and pan curves, the trailer
block, and the 16 key-map entries and 3 instruments that come out silent (their layers reference wavesamples
that hold no audio). Stereo wavesamples and the EPS classic's 13-bit variant have not been identified.

## 4. Bank file — implemented (EpsLin), checked against EpsLin's own bank reader

Types 4 (EPS), 23 (EPS-16+), 30 (ASR-10). Offsets into the Ensoniq file: bank name 0x08-0x1F one character per
16-bit word (high byte), instrument mask 0x20, then 9 records (8 instruments and the song) from 0x22, 16 bytes
each on EPS / EPS-16+ and 28 on the ASR-10. Record byte 0: >= 0x80 copy of another instrument (low nibble + 1),
0x7F deleted, else the path depth; byte 2 media (0 floppy, SCSI ID + 1); odd bytes 3-15 the disk label; even
bytes 4, 6, ... the directory slot at each level, then the instrument's slot. A bank longer than 3 blocks carries
an effect at 0x600, its name one character per word from 0x60A. A bank refers to instruments by disk label and
slot; `Bank::resolve` finds them on the current disk and says when they live on another one. Our output matches
`epslin -b` on the same file field for field. Not yet checked against a bank saved by the hardware.

The "one character per 16-bit word, high byte" encoding of names matches what is known of instrument files, which
supports the idea that instrument parameters are also stored one per word.

## Sources
- **EpsLin v1.42** (Juha Forsten, GPL), `eps_lin_lu2.c` from the Ensoniq_EFE2HFEv2 toolkit (hxc2001.com): file
  system, ID / OS blocks, file types, EFE header, EDE / EDA, GKH, bank files. Primary source.
- HxC disk layouts in the same toolkit (ENSONIQ_DD_800KB, HD_1600KB, 2550KB, 5100KB): sector numbering, geometry.
- EnsoniqFS (Thoralt Franz) and EpsLin / EpsLinNeo (Juha Forsten): disk file system, as summarised in the epstool
  project (github.com/mikewolak/epstool, which also documents its own EPS-classic instrument observations).
- Chicken Systems, "Ensoniq Disk Tools" and "MIDI-Disk Tools" manuals: Giebler formats, instrument structure,
  EDE / EDA sizes.
- Chicken Systems Translator format notes (EPS / ASR): 8 layers, 127 wavesamples, patch selects.
- Ensoniq ASR-10 Musician's Manual: disk capacities (Ensoniq format 800 / 1600 KB), parameter ranges.
- HxC Floppy Emulator: HFE v1 format.
- ConvertWithMoss (Jürgen Moßgraber) reads EPS / EPS-16+ / ASR-10 disks since v19; its reader is the best
  cross-check available and should be compared against once real files are in hand.
