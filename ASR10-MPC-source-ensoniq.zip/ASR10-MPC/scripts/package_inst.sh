#!/usr/bin/env bash
# Build asr10_inst.so (ASR10 Instrument) for the MPC (32-bit ARM hard-float), verify it, and assemble
# dist/ASR10-Instrument-0.1.0-mpc-armv7.zip. Same checks as package.sh. NOT yet run on a device.
set -euo pipefail
cd "$(dirname "$0")/.."
VERSION=0.1.0; NAME="ASR10-Instrument-$VERSION"; SO=build/arm/asr10_inst.so

if command -v arm-linux-gnueabihf-g++ >/dev/null; then make arm-inst
elif command -v docker >/dev/null; then make docker-inst
else echo "Need arm-linux-gnueabihf-g++ (apt install g++-arm-linux-gnueabihf) or Docker."; exit 1; fi

# verify it is something the MPC can load, by the properties of the known-good effect build
REF=""; [ -f build/arm/asr10.so ] && REF=build/arm/asr10.so
bash scripts/check_arm.sh "$SO" $REF

rm -rf "dist/$NAME"; mkdir -p "dist/$NAME/payload/vst"
cp "$SO" "dist/$NAME/payload/vst/asr10_inst.so"
cp mpc/inst/install.sh mpc/inst/uninstall.sh mpc/inst/plugin.xml mpc/plugin_list.awk "dist/$NAME/"
cp mpc/INSTALL_INST.md "dist/$NAME/INSTALL.md"
chmod +x "dist/$NAME/"*.sh
( cd "dist/$NAME" && sha256sum INSTALL.md install.sh uninstall.sh plugin.xml plugin_list.awk payload/vst/asr10_inst.so > SHA256SUMS )
( cd dist && rm -f "$NAME-mpc-armv7.zip" && zip -qr "$NAME-mpc-armv7.zip" "$NAME" )
echo "Built dist/$NAME-mpc-armv7.zip"
