#!/usr/bin/env bash
# Verify that a plugin .so is something the MPC can load, by the same properties as the known-good ASR10 effect
# (ASR10-1.2.0-mpc-armv7). Usage:  scripts/check_arm.sh PLUGIN.so [REFERENCE.so]
# With a reference, its ELF flags and ARM build attributes must match exactly.
set -uo pipefail
SO="${1:?usage: check_arm.sh PLUGIN.so [REFERENCE.so]}"; REF="${2:-}"
RE="${READELF:-readelf}"; fail=0
bad() { echo "  FAIL: $*"; fail=1; }
ok()  { echo "  ok:   $*"; }
echo "$SO"
H=$($RE -h "$SO" 2>&1); A=$($RE -A "$SO" 2>&1)
grep -q 'Class:.*ELF32' <<<"$H"                      && ok "32-bit ELF"            || bad "not 32-bit ELF"
grep -q 'Machine:.*ARM' <<<"$H"                      && ok "ARM"                   || bad "not ARM"
grep -q 'hard-float ABI' <<<"$H"                     && ok "hard-float ABI (EABI5)" || bad "not hard-float"
grep -q 'Tag_CPU_arch: v7' <<<"$A"                   && ok "ARMv7"                 || bad "not ARMv7"
grep -q 'Tag_FP_arch: VFPv3-D16' <<<"$A"             && ok "VFPv3-D16"             || bad "FPU is not VFPv3-D16"
grep -q 'Tag_THUMB_ISA_use: Thumb-2' <<<"$A"         && ok "Thumb-2"               || bad "not Thumb-2"
grep -q 'Tag_ABI_VFP_args: VFP registers' <<<"$A"    && ok "VFP register args"     || bad "soft-float calling convention"
NEEDED=$($RE -d "$SO" | sed -n 's/.*Shared library: \[\(.*\)\]/\1/p' | tr '\n' ' ')
for l in $NEEDED; do case "$l" in libm.so.6|libc.so.6|libpthread.so.0) ;; *) bad "unexpected dependency $l (only libc, libm, libpthread are allowed)";; esac; done
[ -z "$(tr -d ' ' <<<"$NEEDED")" ] || ok "NEEDED: $NEEDED"
if $RE --dyn-syms "$SO" | grep -Eq '@(GLIBCXX|CXXABI|GCC_)|_Znw|_Zdl|__cxa_|__gxx_personality'; then bad "C++ runtime symbols (libstdc++ / libgcc_s) are referenced"; else ok "no libstdc++ / libgcc_s symbols"; fi
if $RE --dyn-syms "$SO" | grep -q ' VSTPluginMain'; then ok "exports VSTPluginMain"; else bad "VSTPluginMain not exported"; fi
MAXG=$($RE -V "$SO" | grep -o 'GLIBC_[0-9.]*' | sort -uV | tail -1)
[ -z "$MAXG" ] || { ok "highest glibc symbol $MAXG"; [ "$(printf '%s\n' "$MAXG" GLIBC_2.34 | sort -V | tail -1)" = GLIBC_2.34 ] || bad "needs $MAXG, newer than GLIBC_2.34"; }
if [ -n "$REF" ]; then
  for k in 'Flags:' 'Tag_CPU_arch:' 'Tag_CPU_arch_profile:' 'Tag_THUMB_ISA_use:' 'Tag_FP_arch:' 'Tag_ABI_VFP_args:' 'Tag_ABI_FP_number_model:'; do
    a=$( { $RE -h "$SO"; $RE -A "$SO"; } | grep -m1 -F "$k" | sed 's/^ *//')
    b=$( { $RE -h "$REF"; $RE -A "$REF"; } | grep -m1 -F "$k" | sed 's/^ *//')
    [ "$a" = "$b" ] && ok "matches reference: $a" || bad "differs from reference: '$a' vs '$b'"
  done
fi
[ $fail = 0 ] && echo "PASS" || { echo "FAILED"; exit 1; }
