// ensoniq_inspect - look inside Ensoniq EPS / EPS-16+ / ASR-10 disk images and files, on a computer or on the MPC.
//
//   ensoniq_inspect IMAGE info                  container, geometry, signatures
//   ensoniq_inspect IMAGE tree                  every directory and file
//   ensoniq_inspect IMAGE extract PATH OUT      write one Ensoniq file (raw, no Giebler header)
//   ensoniq_inspect IMAGE probe PATH            hex dump + text found in a file (for mapping the instrument format)
//   ensoniq_inspect IMAGE bank PATH             a bank's instruments, resolved on this disk
//   ensoniq_inspect FILE.efe|.efa probe|bank    same for a Giebler single-file image
//
// "probe" output is what's needed to finish the instrument parser: run it on a few instruments and send it.
#include "../src/ensoniq/ens_bank.h"
#include <stdio.h>
#include <string.h>

using namespace ens;

static void hexdump (const uint8_t* p, size_t n, size_t base)
{
    for (size_t i = 0; i < n; i += 16)
    {
        printf ("%06zx  ", base + i);
        for (size_t k = 0; k < 16; ++k) i + k < n ? printf ("%02x ", p[i + k]) : printf ("   ");
        printf (" ");
        for (size_t k = 0; k < 16 && i + k < n; ++k) putchar (p[i + k] >= 32 && p[i + k] < 127 ? p[i + k] : '.');
        putchar ('\n');
    }
}

// Printable runs, both packed (one char per byte) and spread (one char per 16-bit word, as the EPS stores
// parameter names in RAM format). Names of layers and wavesamples show up here and locate their records.
static void strings (const uint8_t* p, size_t n)
{
    for (int stride = 1; stride <= 2; ++stride)
        for (int phase = 0; phase < stride; ++phase)
        {
            size_t start = 0, len = 0;
            for (size_t i = (size_t) phase; i < n; i += (size_t) stride)
            {
                const bool pr = p[i] >= 32 && p[i] < 127;
                if (pr) { if (len == 0) start = i; ++len; }
                if (! pr || i + (size_t) stride >= n)
                {
                    if (len >= 6)
                    {
                        printf ("  %s @0x%06zx: \"", stride == 1 ? "packed" : "spread", start);
                        for (size_t k = 0; k < len; ++k) putchar (p[start + k * (size_t) stride]);
                        printf ("\"\n");
                    }
                    len = 0;
                }
            }
        }
}

static void probe (const uint8_t* p, size_t n)
{
    printf ("size: %zu bytes (%zu blocks)\n\ntext found:\n", n, n / 512);
    strings (p, n < 65536 ? n : 65536);
    const size_t show = n < 2048 ? n : 2048;
    printf ("\nfirst %zu bytes:\n", show);
    hexdump (p, show, 0);
    // where the parameters stop and sample data starts is unknown; show the block energy profile
    printf ("\nper-block activity (share of non-zero bytes), first 64 blocks:\n");
    for (size_t b = 0; b * 512 < n && b < 64; ++b)
    {
        size_t nz = 0; for (size_t k = 0; k < 512 && b * 512 + k < n; ++k) nz += p[b * 512 + k] != 0;
        printf ("%3zu:%3zu%%%s", b, nz * 100 / 512, (b % 8 == 7) ? "\n" : "  ");
    }
    printf ("\n");
}

static void printBank (const Bank& b, const Volume* v)
{
    printf ("bank \"%s\" (%s), instrument mask 0x%02x%s%s\n", b.name, fileTypeName (b.type), b.mask,
            b.hasEffect ? ", effect " : "", b.hasEffect ? b.effectName : "");
    for (int j = 0; j < 9; ++j)
    {
        const BankRef& r = j < 8 ? b.inst[j] : b.song;
        printf ("  %s%d: ", j < 8 ? "inst " : "song ", j < 8 ? j + 1 : 0);
        switch (r.kind)
        {
            case BankRef::NONE:    printf ("-\n"); break;
            case BankRef::DELETED: printf ("deleted\n"); break;
            case BankRef::COPY:    printf ("copy of instrument %d\n", r.copyOf); break;
            case BankRef::REF:
            {
                printf ("disk \"%s\" media %u path", r.label, r.media);
                for (int k = 0; k < r.depth; ++k) printf ("/%u", r.path[k]);
                printf ("/%u", r.slot);
                Entry e; char err[160];
                if (v) { if (b.resolve (*v, r, e, err, sizeof err, j == 8)) printf (" -> %s", e.name); else printf (" -> (%s)", err); }
                printf ("\n");
                break;
            }
        }
    }
}

static void tree (const Volume& v, uint32_t dirBlock, int depth, int& budget)
{
    Dir d; char err[160];
    if (depth > 12 || --budget < 0) return;
    if (! v.readDir (dirBlock, d, err, sizeof err)) { printf ("%*s[error: %s]\n", depth * 2, "", err); return; }
    for (int i = 0; i < d.n; ++i)
    {
        const Entry& e = d.e[i];
        if (e.type == FT_PARENT) continue;
        bool known; const char* tn = fileTypeName (e.type, &known);
        printf ("%*s%-12s  %s%s (%u)  %u blocks  @%u%s\n", depth * 2, "", e.name, tn, known ? "" : "?", e.type,
                e.sizeBlocks, e.start, e.multi ? "  multi-file part" : "");
        if (e.type == FT_DIR) tree (v, e.start, depth + 1, budget);
    }
}

int main (int argc, char** argv)
{
    if (argc < 3) { fprintf (stderr, "usage: %s IMAGE info|tree|extract PATH OUT|probe PATH|bank PATH\n", argv[0]); return 2; }
    const char* path = argv[1];
    const char* cmd = argv[2];
    char err[160] {};

    Image img;
    if (! img.open (path, err, sizeof err))
    {
        GieblerFile gf; char e2[160] {};
        if (strcmp (cmd, "bank") == 0 && gf.open (path, e2, sizeof e2))
        {
            Bank b;
            if (! b.parse (gf.data.p, gf.data.n, gf.type, e2, sizeof e2)) { fprintf (stderr, "%s: %s\n", path, e2); return 1; }
            printBank (b, nullptr);
            return 0;
        }
        if (strcmp (cmd, "probe") == 0 && gf.open (path, e2, sizeof e2))
        {
            printf ("Giebler single file: \"%s\", %s (%u), %u blocks%s\n", gf.name, fileTypeName (gf.type), gf.type,
                    gf.sizeBlocks, gf.sizeMatches ? "" : " (header size does not match the data)");
            probe (gf.data.p, gf.data.n);
            gf.release();
            return 0;
        }
        fprintf (stderr, "%s: %s\n", path, err);
        return 1;
    }
    Volume v;
    if (! v.open (img, err, sizeof err)) { fprintf (stderr, "%s: file system: %s\n", path, err); return 1; }

    if (strcmp (cmd, "info") == 0)
    {
        printf ("container: %s (%s)\n", imageKindName (img.kind), img.note);
        printf ("label: \"%s\"\n", v.label);
        printf ("blocks: %u in image, %u per ID block%s, %u free per OS block%s\n", img.numBlocks, v.totalBlocks,
                v.hasId ? "" : " (no ID signature)", v.freeBlocks, v.hasOs ? "" : " (no OS signature)");
        printf ("OS version on disk %u.%02u, ROM %u.%02u\n", v.diskOs[0], v.diskOs[1], v.romOs[0], v.romOs[1]);
    }
    else if (strcmp (cmd, "tree") == 0) { int budget = 4096; tree (v, 3, 0, budget); }
    else if (strcmp (cmd, "bank") == 0 && argc >= 4)
    {
        Entry e; Bytes data; Bank b;
        if (! v.find (argv[3], e, err, sizeof err) || ! v.readFile (e, data, err, sizeof err)
            || ! b.parse (data.p, data.n, e.type, err, sizeof err)) { fprintf (stderr, "%s: %s\n", argv[3], err); return 1; }
        printBank (b, &v);
        data.release();
    }
    else if ((strcmp (cmd, "extract") == 0 || strcmp (cmd, "probe") == 0) && argc >= 4)
    {
        Entry e; Bytes data;
        if (! v.find (argv[3], e, err, sizeof err) || ! v.readFile (e, data, err, sizeof err))
        { fprintf (stderr, "%s: %s\n", argv[3], err); return 1; }
        if (cmd[0] == 'p')
        {
            printf ("%s: %s (type %u), %u blocks, type-info byte 0x%02x\n", e.name, fileTypeName (e.type), e.type,
                    e.sizeBlocks, e.typeInfo);
            probe (data.p, data.n);
        }
        else
        {
            if (argc < 5) { fprintf (stderr, "extract needs an output file\n"); return 2; }
            FILE* o = fopen (argv[4], "wb");
            if (! o || fwrite (data.p, 1, data.n, o) != data.n) { fprintf (stderr, "cannot write %s\n", argv[4]); return 1; }
            fclose (o);
            printf ("wrote %zu bytes\n", data.n);
        }
        data.release();
    }
    else { fprintf (stderr, "unknown command\n"); return 2; }
    img.close();
    return 0;
}
