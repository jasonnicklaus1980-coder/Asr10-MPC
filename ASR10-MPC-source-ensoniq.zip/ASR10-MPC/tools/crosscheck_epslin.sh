#!/usr/bin/env bash
# Cross-check src/ensoniq against EpsLin v1.42 (J. Forsten, GPL): EpsLin formats real-layout ASR-10 and EPS disks,
# puts files on them and converts them to EDA / EDE; ensoniq_inspect must read back exactly what went in.
#   tools/crosscheck_epslin.sh path/to/eps_lin_lu2.c [os.efe ...]
# (eps_lin_lu2.c ships in the Ensoniq_EFE2HFEv2 toolkit; it is the Windows build, patched here for Linux.)
set -euo pipefail
SRC=${1:?path to eps_lin_lu2.c}; shift
ROOT=$(cd "$(dirname "$0")/.." && pwd)
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
sed -e 's|#if 1 //def __CYGWIN__|#if 0|' -e 's|^#define open _open||' -e 's|^#define O_RDONLY _O_RDONLY||' \
    -e 's|if(-1 /\*-1 /\*ioctl(fd, FDSETPRM , &g)\*/\*/ < 0) {|if(-1 < 0) {|' "$SRC" > "$W/epslin.c"
gcc -w -O0 -U_FORTIFY_SOURCE -D_FORTIFY_SOURCE=0 "$W/epslin.c" -o "$W/epslin"
make -s -C "$ROOT" inspect >/dev/null
I="$ROOT/build/native/ensoniq_inspect"
fail=0; pass=0
ok()  { pass=$((pass+1)); echo "  ok   $*"; }
bad() { fail=$((fail+1)); echo "  FAIL $*"; }

# test instruments as Giebler EFEs (type 3), random contents, sizes chosen to span several FAT blocks
mkefe() {  # name blocks type out
  python3 - "$1" "$2" "$3" "$4" <<'PY'
import sys, os
name, blocks, typ, out = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
h = bytearray(512); h[0:2] = b'\r\n'; h[2:18] = b'Eps File:       '; h[18:30] = name.ljust(12).encode()
h[47:50] = b'\r\n\x1a'; h[0x32] = typ; h[0x34:0x36] = blocks.to_bytes(2,'big'); h[0x36:0x38] = blocks.to_bytes(2,'big')
open(out,'wb').write(bytes(h) + os.urandom(blocks*512))
PY
}
cd "$W"
mkefe "SMALL INST" 3 3 small.efe
mkefe "BIG INST" 400 3 big.efe
mkefe "MID INST" 57 3 mid.efe

for kind in asr eps; do
  echo "== $kind disk written by EpsLin"
  ./epslin -l XCHECK -fi disk_$kind.img $kind >/dev/null 2>&1
  for os in "$@"; do ./epslin -p0 disk_$kind.img "$os" >/dev/null 2>&1 && break; done
  ./epslin -p1 disk_$kind.img small.efe big.efe mid.efe >/dev/null 2>&1 || true
  ext=$([ $kind = asr ] && echo eda || echo ede)
  ./epslin -c disk_$kind.img disk_$kind.$ext >/dev/null 2>&1
  for img in disk_$kind.img disk_$kind.$ext; do
    if "$I" $img info > info.txt 2>&1; then ok "$img opens: $(head -1 info.txt)"; else bad "$img: $(cat info.txt)"; continue; fi
    grep -q 'label: "XCHECK"' info.txt && ok "$img label XCHECK" || bad "$img label: $(grep label info.txt)"
    "$I" $img tree > tree.txt
    for f in small big mid; do
      n=$(python3 -c "import sys;print(open('$f.efe','rb').read()[18:30].decode().rstrip())")
      if "$I" $img extract "$n" out.bin >/dev/null 2>&1 && cmp -s out.bin <(tail -c +513 $f.efe); then ok "$img: '$n' byte-identical"
      else bad "$img: '$n' differs or missing"; fi
    done
  done
  cmp -s <("$I" disk_$kind.img tree) <("$I" disk_$kind.$ext tree) && ok "img and $ext give the same tree" || bad "img/$ext trees differ"
done
echo; echo "crosscheck: $pass passed, $fail failed"
[ $fail -eq 0 ]
