// Render notes of an instrument from an Ensoniq disk image / CD image to a WAV file, through the same parser and
// engine the plugin uses. Raw sample playback: key map, velocity layers, tuned loops and sample rate conversion only;
// envelopes and filters are not decoded yet, so this will NOT sound like the hardware.
//   ensoniq_render IMAGE "DIR/INSTRUMENT NAME" out.wav [key[:vel] ...]      (default keys: 48 60 72 at velocity 100)
#include "../src/ensoniq/ens_instrument_file.h"
#include "../src/engine/ens_engine.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
using namespace ens;

static void freeInst (Instrument* i) { i->releaseAudio(); delete i; }
static void le32 (FILE* f, uint32_t v) { fputc (v & 255, f); fputc ((v >> 8) & 255, f); fputc ((v >> 16) & 255, f); fputc (v >> 24, f); }
static void le16 (FILE* f, uint16_t v) { fputc (v & 255, f); fputc (v >> 8, f); }

int main (int argc, char** argv)
{
    if (argc < 4) { fprintf (stderr, "usage: %s IMAGE \"DIR/INSTRUMENT\" out.wav [key[:vel] ...]\n", argv[0]); return 2; }
    char err[200] {};
    Image img; Volume vol; Entry en;
    if (! img.open (argv[1], err, sizeof err) || ! vol.open (img, err, sizeof err)) { fprintf (stderr, "%s: %s\n", argv[1], err); return 1; }
    if (! vol.find (argv[2], en, err, sizeof err)) { fprintf (stderr, "%s: %s\n", argv[2], err); return 1; }
    Instrument* in = new Instrument(); ParseInfo info;
    if (! parseInstrumentEntry (vol, en, *in, info, err, sizeof err)) { fprintf (stderr, "parse: %s\n", err); return 1; }
    printf ("%s: %d layer(s), %d wavesample(s) (%d copies), %zu audio frames, %d effect block(s)\n", in->name, info.layers, info.wavesamples, info.copies, info.audioFrames, info.effectBlocks);
    for (int l = 0; l < in->numLayers; ++l)
        if (in->layer[l].enabled) printf ("  layer %d: velocity %d-%d\n", l + 1, in->layer[l].velLo, in->layer[l].velHi);
    for (int w = 0; w < in->numWs; ++w)
        if (in->ws[w].data) printf ("  ws %3d: keys %3d-%3d root %3d  %8.1f Hz  loop %d  %u frames\n", w + 1, in->ws[w].keyLo, in->ws[w].keyHi, in->ws[w].rootKey, in->ws[w].sampleRate, (int) in->ws[w].loop, in->ws[w].frames);

    std::vector<int> keys, vels;
    for (int a = 4; a < argc; ++a) { int k = 0, v = 100; sscanf (argv[a], "%d:%d", &k, &v); keys.push_back (k); vels.push_back (v); }
    if (keys.empty()) { keys = { 48, 60, 72 }; vels = { 100, 100, 100 }; }

    const float sr = 44100.f;
    Engine e; e.prepare (sr); e.setInstrument (in, freeInst); e.render (nullptr, nullptr, 0);
    std::vector<float> L, R; const int noteLen = (int) (sr * 1.5f), tail = (int) (sr * 0.6f);
    for (size_t i = 0; i < keys.size(); ++i)
    {
        std::vector<float> bl ((size_t) (noteLen + tail)), br (bl.size());
        e.noteOn ((uint8_t) keys[i], (uint8_t) vels[i]);
        e.render (bl.data(), br.data(), noteLen);
        e.noteOff ((uint8_t) keys[i]);
        e.render (bl.data() + noteLen, br.data() + noteLen, tail);
        L.insert (L.end(), bl.begin(), bl.end()); R.insert (R.end(), br.begin(), br.end());
    }
    FILE* f = fopen (argv[3], "wb");
    if (! f) { perror (argv[3]); return 1; }
    const uint32_t bytes = (uint32_t) (L.size() * 4);
    fwrite ("RIFF", 1, 4, f); le32 (f, 36 + bytes); fwrite ("WAVEfmt ", 1, 8, f); le32 (f, 16); le16 (f, 1); le16 (f, 2);
    le32 (f, (uint32_t) sr); le32 (f, (uint32_t) sr * 4); le16 (f, 4); le16 (f, 16); fwrite ("data", 1, 4, f); le32 (f, bytes);
    for (size_t i = 0; i < L.size(); ++i)
    {
        le16 (f, (uint16_t) (int16_t) lrintf (fmaxf (-1.f, fminf (1.f, L[i])) * 32767.f));
        le16 (f, (uint16_t) (int16_t) lrintf (fmaxf (-1.f, fminf (1.f, R[i])) * 32767.f));
    }
    fclose (f);
    printf ("wrote %s (%zu notes, %.1f s)\n", argv[3], keys.size(), L.size() / sr);
    e.shutdown (freeInst);
    return 0;
}
