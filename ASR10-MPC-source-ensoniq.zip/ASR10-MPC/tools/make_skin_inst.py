#!/usr/bin/env python3
"""Generate the MPC screen skin for the ASR10 Instrument plugin, in the same ASR-10 front-panel style as the effect's
skin (tools/make_skin.py, whose drawing code and MPC rules are reused: square filmstrip frames, skin folder
"<manufacturer> - VST - <plugin>").

Layout: floppy drive; the ASR-10's Volume slider and an Instrument slider; the fluorescent display (instrument name,
disk name, layers / wavesamples / patch / voices); a row of step keys like the arrow keys of the ASR-10's Load page
(DISK -/+, INST -10/-1/+1/+10: a slider cannot pick one of 500+ instruments); PATCH 1-4, VOICES 31 / 20, and a
DISK LIST key that re-reads /sdcard/Ensoniq. Controls bind to "Parameter N" = VST parameter index (src/asr10_inst.cpp).
Usage: python3 tools/make_skin_inst.py [preview.png]        (needs Pillow)
"""
import json, os, random, shutil, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import make_skin as S
from make_skin import Image, ImageDraw, font, text_c, spaced, slanted, PRINT, PRINT_DIM, VFD_BG, VFD_TXT, VFD_DIM, VFD_COL, NAME_COL, PANEL, W, H, KEY_W, KEY_H

ROOT = S.ROOT
SKIN_DIR = os.path.join(ROOT, "mpc", "skin", "GlueBus - VST - ASR10 Instrument")
OUT = os.path.join(SKIN_DIR, "Plugin Skins")
S.SKIN_DIR, S.OUT = SKIN_DIR, OUT                       # key_group_defs() writes its key images to S.OUT
VERSION = "0.1.0.0"

# parameter indices: must match the enum in src/asr10_inst.cpp
P = dict(disk=0, inst=1, patch=2, volume=3, voices=4, info=5, rescan=6,
         inst_m10=7, inst_m1=8, inst_p1=9, inst_p10=10, disk_m=11, disk_p=12, fx=13, fxname=14)
S.P = P                                                 # S.bind() looks parameters up here

SLIDERS = [("volume", "VOLUME", True, 222), ("inst", "INSTRUMENT", False, 346)]
VFD = S.VFD
NAV_X, NAV_Y, NAV_GAP = 486, 300, 10.8
NAV = [("disk_m", "DISK -"), ("disk_p", "DISK +"), ("inst_m10", "INST -10"), ("inst_m1", "INST -1"), ("inst_p1", "INST +1"), ("inst_p10", "INST +10")]
GROUPS = [("patch", "PATCH  SELECT", ["1", "2", "3", "4"], 486, 440, 100, 24.7),
          ("voices", "VOICES", ["31  ASR-10", "20  EPS-16+"], 1000, 150, 108, 24),
          ("fx", "EFFECTS", ["OFF", "ON", "MORE"], 1000, 350, 76, 10)]
FXNAME = (1000, 392, 248, 26)             # shows the effect the instrument names, e.g. "~HALL REVERB"
RESCAN = (1000, 250, 108)
QLINKS = ["inst", "disk", "volume", "patch", "voices", "fx", "inst_m1", "inst_p1", "disk_m", "disk_p", "inst_m10", "inst_p10", "rescan"]

def nav_x(i): return NAV_X + i * (KEY_W + NAV_GAP)
def group_x(g, i): return g[3] + i * (g[5] + g[6])

def background():
    random.seed(9)
    im = Image.new("RGB", (W, H), PANEL); px = im.load()
    for y in range(H):
        for x in range(W):
            n = random.randint(-2, 2); px[x, y] = (PANEL[0] + n, PANEL[1] + n, PANEL[2] + n)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, W, 4], fill=(44, 44, 46))
    S.floppy(d, 24, 210)
    d.text((26, 326), spaced("3.5\"  DISK  DRIVE"), font=font(11), fill=PRINT_DIM)
    for key, lab, show, sx in SLIDERS:                   # slider scales
        cx = sx + S.SLIDER_W / 2
        y0, y1 = S.SLIDER_Y + S.FY + S.TRAVEL0, S.SLIDER_Y + S.FY + S.TRAVEL1
        for j in range(21):
            y = y1 + (y0 - y1) * j / 20; long_ = j % 5 == 0
            d.line([cx - 34 - (6 if long_ else 0), y, cx - 30, y], fill=PRINT if long_ else PRINT_DIM, width=1)
            d.line([cx + 30, y, cx + 34 + (6 if long_ else 0), y], fill=PRINT if long_ else PRINT_DIM, width=1)
    vx, vy, vw, vh = VFD
    d.rounded_rectangle([vx - 10, vy - 10, vx + vw + 10, vy + vh + 10], radius=6, fill=(4, 4, 5), outline=(52, 52, 54), width=2)
    d.rectangle([vx, vy, vx + vw, vy + vh], fill=VFD_BG)
    for yy in range(vy, vy + vh, 3): d.line([vx, yy, vx + vw, yy], fill=(8, 22, 22))
    d.line([vx + 12, vy + 68, vx + vw - 12, vy + 68], fill=VFD_DIM, width=1)
    f_lab = font(11)
    d.text((NAV_X, NAV_Y - 38), spaced("LOAD") + "   ·   " + "step through the disks and instruments", font=f_lab, fill=PRINT_DIM)
    for i, (k, lab) in enumerate(NAV): text_c(d, nav_x(i) + KEY_W / 2, NAV_Y - 12, lab, f_lab, PRINT)
    for g in GROUPS:
        key, title, opts, x, y, kw, gap = g
        d.text((x, y - 44), spaced(title), font=font(12), fill=PRINT)
        for i, o in enumerate(opts): text_c(d, group_x(g, i) + kw / 2, y - 12, o, f_lab, PRINT)
    rx, ry, rw = RESCAN
    d.text((rx, ry - 44), spaced("DISK  LIST"), font=font(12), fill=PRINT)
    text_c(d, rx + rw / 2, ry - 12, "RESCAN", f_lab, PRINT)
    slanted(im, (996, 452), "ASR-10", font(54, "DejaVuSans.ttf"), PRINT)
    sub = spaced("INSTRUMENT  PLAYER"); tw = d.textlength(sub, font=font(10))
    d.text((W - 24 - tw, 526), sub, font=font(10), fill=PRINT_DIM)
    d.text((486, 552), spaced("RAW  PLAYBACK  ·  NO  ENVELOPES  OR  FILTERS  YET  ·  FX  ARE  APPROXIMATIONS"), font=font(10), fill=PRINT_DIM)
    d.line([486, 366, 960, 366], fill=(46, 46, 48), width=1)
    return im

def build():
    if os.path.isdir(SKIN_DIR): shutil.rmtree(SKIN_DIR)
    os.makedirs(OUT)
    defs = []
    S.fader_strip().save(os.path.join(OUT, "asr_fader.png"), optimize=True)
    sw, sh = S.SLIDER_W, S.SLIDER_H
    for with_value in (False, True):
        parts = [S.focus((0, 0, sw, sh)), S.label("Name", 14, NAME_COL, (0, 4, sw, 22), case="Upper Case"),
                 S.comp("Knob", "Knob", {"version": 5, "knobType": "FilmStrip", "filmStrip": "asr_fader.png", "numFrames": S.NUMFRAMES, "invert": False,
                      "dragOrientation": "Vertical", "handleName": "Data"}, S.bounds(((sw - S.FS) // 2, S.FY, S.FS, S.FS)))]
        if with_value: parts.append(S.label("Value", 18, VFD_COL, (0, S.FY + S.FH + 6, sw, 28), case="Upper Case"))
        defs.append({"key": "asrSliderV" if with_value else "asrSlider", "value": S.definition(
            [S.action("Mouse Down", "Q-Link"), S.action("Double Click", "Show Overlay", "knob overlay"), S.action("Enter Pressed", "Show Overlay", "knob overlay")], parts)})
    for g in GROUPS: S.key_group_defs(g[0], len(g[2]), g[5], defs)
    # one toggle key per step / rescan: every press flips the parameter, every flip steps once in the plugin
    def toggle_key(name, w, on, off):
        S.asr_key(True, w).save(os.path.join(OUT, on)); S.asr_key(False, w).save(os.path.join(OUT, off))
        defs.append({"key": name, "value": S.definition([S.action("Mouse Down", "Q-Link"), S.action("Enter Pressed", "Toggle Switch")], [
            S.comp("Button", "Button", {"version": 2, "onImage": on, "offImage": off, "buttonId": 1, "numButtonsInGroup": 1,
                   "handleName": "Data", "gestureBehaviour": "Instant"}, S.bounds((0, 0, w, KEY_H + 10)))])})
    toggle_key("asrNav", KEY_W, "asr_nav_on.png", "asr_nav_off.png")
    toggle_key("asrRescan", RESCAN[2], "asr_rescan_on.png", "asr_rescan_off.png")

    background().save(os.path.join(OUT, "asr_bg.png"), optimize=True)
    comps = [S.comp("Background", "Image", {"version": 2, "imageType": "Regular", "colour": "0", "image": "asr_bg.png"}, S.bounds((0, 0, W, H)))]
    for key, lab, show, sx in SLIDERS:
        comps.append(S.comp(lab.title(), "asrSliderV" if show else "asrSlider", {"version": 1, "handleName": "Data"},
                            S.bounds((sx, S.SLIDER_Y, S.SLIDER_W, S.SLIDER_H), focus="Yes", show="Hide"), S.bind(key)))
    vx, vy, vw, vh = VFD                                # the display: instrument name, disk name, then info / patch / voices
    comps.append(S.bound_label("Instrument name", "inst", 34, VFD_COL, (vx + 14, vy + 6, vw - 28, 40), case="Upper Case"))
    comps.append(S.bound_label("Disk name", "disk", 15, VFD_COL, (vx + 14, vy + 44, vw - 28, 22), case="Original"))
    third = (vw - 28) // 3
    for k, prm in enumerate(("info", "patch", "voices")):
        comps.append(S.bound_label(f"Display {prm}", prm, 17, VFD_COL, (vx + 14 + k * third, vy + 76, third, 30)))
    for i, (k, lab) in enumerate(NAV):
        comps.append(S.comp(lab, "asrNav", {"version": 1, "handleName": "Data"}, S.bounds((nav_x(i), NAV_Y - 10, KEY_W, KEY_H + 10), focus="Yes" if i == 0 else "No", show="Hide"), S.bind(k)))
    for g in GROUPS:
        key, title, opts, x, y, kw, gap = g
        for i, o in enumerate(opts):
            comps.append(S.comp(f"{title} {o}", f"asrKey_{key}_{i}", {"version": 1, "handleName": "Data"},
                                S.bounds((group_x(g, i), y - 10, kw, KEY_H + 10), focus="No", show="Hide"), S.bind(key)))
    rx, ry, rw = RESCAN
    fx0, fy0, fw0, fh0 = FXNAME
    comps.append(S.bound_label("FX name", "fxname", 15, VFD_COL, (fx0, fy0, fw0, fh0), case="Original"))
    comps.append(S.comp("Rescan", "asrRescan", {"version": 1, "handleName": "Data"}, S.bounds((rx, ry - 10, rw, KEY_H + 10), focus="No", show="Hide"), S.bind("rescan")))
    defs.append({"key": "ASR|Panel", "value": S.definition([], comps, "ff18181a")})
    tabs = [{"version": 3, "tabName": "ASR-10", "fnKeyIndex": 0, "fnKeySubIndex": 0, "qlinkBoundsData": ["0 0 0 0"],
             "componentName": "ASR|Panel", "initialSize": f"0 0 {W} {H}", "scale": 1.0}]
    tui = {"pageData": {"version": 1, "componentDefinitions": {"version": 2, "importFiles": [
               "/usr/share/Akai/Content/Synths/Generic/Generic Knob Overlay.json", "/usr/share/Akai/Content/Synths/Generic/Generic Menu Overlay.json"],
               "localComponentDefinitions": defs}, "info": {"version": 1, "type": "CompleteDescription"}, "tabs": tabs}}
    json.dump(tui, open(os.path.join(OUT, "TUI.json"), "w"), indent=4)
    qmap = {f"Q-Link {i + 1}": P[k] for i, k in enumerate(QLINKS)}
    q = {"version": 4, "info": {"version": 1, "type": "CompleteDescription"},
         "Screen Mode Q-Links": {"version": 4, "map": [{"Tab": 1, "SubTab": 1, "Bank Direction": "Column", "Q-Links": qmap}]}, "Program Mode Q-Links": qmap}
    for fn in ("Q-Links.json", "Q-Links - 8by1.json"): json.dump(q, open(os.path.join(OUT, fn), "w"), indent=4)
    open(os.path.join(SKIN_DIR, "version.xml"), "w").write(
        "<?xml version='1.0' encoding='utf-8'?>\n<plugincontent version=\"1.0\">\n\t<identifier>gluebus.vst.asr10instrument</identifier>\n"
        f"\t<version>{VERSION}</version>\n</plugincontent>\n")
    print("skin written to", SKIN_DIR)

def preview(path):                                       # typical state; MPC draws the live labels itself
    im = Image.open(os.path.join(OUT, "asr_bg.png")).convert("RGBA"); d = ImageDraw.Draw(im)
    strip = Image.open(os.path.join(OUT, "asr_fader.png")); fx0 = (S.FS - S.FW) // 2
    for key, lab, show, sx in SLIDERS:
        fr = round((0.75 if key == "volume" else 0.06) * (S.FRAMES - 1))
        im.alpha_composite(strip.crop((fx0, fr * S.FS, fx0 + S.FW, fr * S.FS + S.FH)), (int(sx + (S.SLIDER_W - S.FW) / 2), S.SLIDER_Y + S.FY))
        text_c(d, sx + S.SLIDER_W / 2, S.SLIDER_Y + 15, lab, font(13), PRINT)
        if show: text_c(d, sx + S.SLIDER_W / 2, S.SLIDER_Y + S.FY + S.FH + 20, "102", font(16), VFD_TXT)
    vx, vy, vw, vh = VFD
    text_c(d, vx + vw / 2, vy + 26, "DML-ORGAN", font(30), VFD_TXT)
    text_c(d, vx + vw / 2, vy + 55, "Ensoniq - ASR Demo CD-ROM.iso", font(14), VFD_TXT)
    third = (vw - 28) // 3
    for k, t in enumerate(("2L 2WS RAW", "1", "31 ASR10")): text_c(d, vx + 14 + k * third + third / 2, vy + 91, t, font(15), VFD_TXT)
    on = lambda w, a: Image.open(os.path.join(OUT, f"asr_{'nav' if w == KEY_W else 'key_' + str(w)}_{'on' if a else 'off'}.png" if w == KEY_W else f"asr_key_{w}_{'on' if a else 'off'}.png"))
    for i in range(len(NAV)): im.alpha_composite(on(KEY_W, False), (int(nav_x(i)), NAV_Y - 10))
    sel = dict(patch=0, voices=0, fx=1)
    for g in GROUPS:
        for i in range(len(g[2])): im.alpha_composite(on(g[5], i == sel[g[0]]), (int(group_x(g, i)), g[4] - 10))
    text_c(d, FXNAME[0] + FXNAME[2] / 2, FXNAME[1] + FXNAME[3] / 2, "~HALL REVERB", font(15), VFD_TXT)
    im.alpha_composite(Image.open(os.path.join(OUT, "asr_rescan_off.png")), (RESCAN[0], RESCAN[1] - 10))
    im.convert("RGB").save(path)

if __name__ == "__main__":
    build()
    if len(sys.argv) > 1: preview(sys.argv[1])
