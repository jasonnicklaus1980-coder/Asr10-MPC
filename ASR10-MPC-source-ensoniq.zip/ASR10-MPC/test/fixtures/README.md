# Real Ensoniq test files

The parser tests in `test/ensoniq_test.cpp` use synthetic disks. Real files go here to verify the formats and
to build the instrument parser. They are not committed (commercial libraries are copyrighted): add them locally.

Currently used when present: `ASR353OS.efe`, `ASR161OS.efe`, `EPS16OS.efe` (Ensoniq OS files from the
Ensoniq_EFE2HFEv2 toolkit; the `.e1f1e` files there renamed to `.efe`). These check the EFE header and file
types, but an OS file contains no sounds. Also `ASRblank.img` and `ASRblank.hfe`: a blank ASR-10 HD floppy in
both formats, which must decode to the same disk.

Still needed, most useful first:
1. One ASR-10 disk image (`.img`, `.hfe`, `.eda`) with a multi-sampled instrument that uses more than one layer
   or a velocity split.
2. One EPS-16+ disk image or `.efe` with a drum kit (many wavesamples, one key each).
3. One instrument with a looped sample (sustained pad, string or organ).
4. Any `.ede` / `.eda` file, to confirm the Giebler bitmap layout.
5. If available: what the hardware shows for these (root key, key range, loop start/end, sample rate).

Quick checks, on a computer or on the MPC over SSH:

    make inspect
    ./build/native/ensoniq_inspect DISK.img info
    ./build/native/ensoniq_inspect DISK.img tree
    ./build/native/ensoniq_inspect DISK.img probe "FOLDER/INSTRUMENT NAME" > probe.txt

If the files can't be shared, `info`, `tree` and `probe` output for the instruments above is enough to start.

Cross-check against EpsLin (needs `eps_lin_lu2.c` from the Ensoniq_EFE2HFEv2 toolkit):

    tools/crosscheck_epslin.sh path/to/eps_lin_lu2.c test/fixtures/ASR353OS.efe

## What the instrument parser was decoded from
The instrument layout in `docs/ENSONIQ_FORMATS.md` section 3 comes from the **ASR Demo CD-ROM** image (581
instruments), which is *not* part of this package. With your copy of the image:

    make realtest ISO="Ensoniq - ASR Demo CD-ROM.iso"      # parses and plays every instrument, checks a real organ's pitch
    make render && build/native/ensoniq_render "Ensoniq - ASR Demo CD-ROM.iso" "DEMO SOUNDS1/DEMO SNDS 6/DML-ORGAN" organ.wav 48 60 72
