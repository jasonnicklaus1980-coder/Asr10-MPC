// Offline VST2 host test for the ASR10 Instrument plugin: loads the .so, points it at a folder holding a synthetic
// instrument file (and, when ENS_REAL_ISO is set, the real ASR demo CD), then plays MIDI through the plugin API the
// way an MPC would: selection through parameters, loading on the worker thread, note on / off, sustain, volume,
// project chunk save / restore, clean close.
#include "vst2.h"
#include <dlfcn.h>
#include <unistd.h>
#include <sys/stat.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

static int fails = 0;
#define CHECK(c, ...) do { if (! (c)) { ++fails; printf ("FAIL %s:%d: ", __FILE__, __LINE__); printf (__VA_ARGS__); printf ("\n"); } } while (0)
enum { P_DISK, P_INST, P_PATCH, P_VOLUME, P_VOICES, P_INFO, P_RESCAN, P_COUNT };

typedef std::vector<uint8_t> Buf;
static void setSize (uint8_t* b, size_t bytes) { const size_t s = bytes / 16; b[0] = (uint8_t) s; b[2] = (uint8_t) (s >> 12); b[3] = (uint8_t) (((s >> 8) & 15) << 4); }
static void setId (uint8_t* b, int id) { b[4] = (uint8_t) ((id << 6) >> 8); b[5] = (uint8_t) ((id << 6) & 255); }
static void nameAt (uint8_t* b, size_t off, const char* s) { for (int k = 0; k < 12; ++k) b[off + 2 * k] = (uint8_t) (k < (int) strlen (s) ? s[k] : ' '); }
static void pos (uint8_t* b, int word, double v) { const uint32_t p = (uint32_t) llround (v * 512.0); for (int k = 0; k < 4; ++k) b[10 + 2 * (word + k)] = (uint8_t) (p >> (24 - 8 * k)); }

// whole file = 4 blocks of 512 bytes, as on a disk. One layer, one looped wavesample (sine, 4 periods per 270.52 samples at 29761.9 Hz, root key 69), as a Giebler .efe
static Buf makeEfe (const char* name)
{
    Buf f (0x290, 0);
    nameAt (f.data(), 0x0a, name);
    f[0x2c] = f[0x2e] = f[0x30] = f[0x32] = 1;
    { const size_t o = f.size(); f.resize (o + 0xE0, 0); uint8_t* b = &f[o]; b[0] = 0x0e; b[4] = 6; setId (b, 25); nameAt (b, 10, "LAYER");
      b[0x22 + 8] = 127; for (int k = 0; k < 88; ++k) b[0x30 + 2 * k] = 1; }
    { const size_t bytes = 0x120 + 440 * 2; const size_t o = f.size(); f.resize (o + bytes, 0); uint8_t* b = &f[o]; setSize (b, bytes); setId (b, 34);
      nameAt (b, 10, "SINE");
      auto W = [&] (int k, int v) { b[10 + 2 * k] = (uint8_t) v; };
      W (80, 69); W (84, 13); W (99, 127); W (105, 3); W (114, 2); pos (b, 119, 280); pos (b, 127, 270.52);
      W (131, 21); W (132, 0); W (133, 127); W (134, 13); W (136, 6);
      for (int i = 0; i < 440; ++i) { const int16_t v = (int16_t) llround (0.5 * 32767 * sin (2 * M_PI * 4 * i / 270.52)); b[0x120 + 2 * i] = (uint8_t) ((uint16_t) v >> 8); b[0x121 + 2 * i] = (uint8_t) v; } }
    Buf g (512, 0);                                     // Giebler header
    g[0] = 0x0D; g[1] = 0x0A; memcpy (&g[2], "Eps File:", 9); memset (&g[0x12], ' ', 12); memcpy (&g[0x12], name, strlen (name));
    g[0x32] = 3; g[0x34] = (uint8_t) ((f.size() / 512) >> 8); g[0x35] = (uint8_t) (f.size() / 512);
    g.insert (g.end(), f.begin(), f.end());
    return g;
}

static AEffect* make (const char* so, void*& lib)
{
    lib = dlopen (so, RTLD_NOW);
    if (! lib) { printf ("dlopen: %s\n", dlerror()); return nullptr; }
    typedef AEffect* (*Main) (audioMasterCallback);
    Main m = (Main) dlsym (lib, "VSTPluginMain");
    if (! m) return nullptr;
    return m ([] (AEffect*, int32_t, int32_t, intptr_t, void*, float) -> intptr_t { return 2400; });
}
static intptr_t D (AEffect* e, int op, int idx = 0, intptr_t val = 0, void* p = nullptr, float opt = 0) { return e->dispatcher (e, op, idx, val, p, opt); }
static std::string disp (AEffect* e, int i) { char b[64] {}; D (e, effGetParamDisplay, i, 0, b); return b; }
static bool waitFor (AEffect* e, int param, const char* want, int ms = 8000)
{
    for (int t = 0; t < ms; t += 10) { if (disp (e, param) == want) return true; usleep (10000); }
    return false;
}
static bool waitNot (AEffect* e, int param, const char* notThis, int ms = 15000)   // until display differs (and isn't LOADING)
{
    for (int t = 0; t < ms; t += 10) { const std::string s = disp (e, param); if (s != notThis && s != "LOADING" && s != "SCANNING") return true; usleep (10000); }
    return false;
}
static void midi (AEffect* e, int frame, uint8_t s, uint8_t a, uint8_t b)
{
    struct { int32_t n; intptr_t r; VstEvent* ev[2]; } evs;
    VstMidiEvent m {}; m.type = kVstMidiType; m.byteSize = sizeof m; m.deltaFrames = frame; m.midiData[0] = (char) s; m.midiData[1] = (char) a; m.midiData[2] = (char) b;
    evs.n = 1; evs.r = 0; evs.ev[0] = (VstEvent*) &m; evs.ev[1] = nullptr;
    D (e, effProcessEvents, 0, 0, &evs);
}
static std::vector<float> run (AEffect* e, int frames, int block = 512)
{
    std::vector<float> L ((size_t) frames), R ((size_t) frames);
    for (int p = 0; p < frames; p += block) { const int n = frames - p < block ? frames - p : block; float* out[2] { &L[(size_t) p], &R[(size_t) p] }; e->processReplacing (e, nullptr, out, n); }
    return L;
}
static double peak (const std::vector<float>& x, size_t a = 0, size_t b = (size_t) -1) { double m = 0; for (size_t i = a; i < x.size() && i < b; ++i) { if (! std::isfinite (x[i])) return 1e9; m = std::fmax (m, std::fabs (x[i])); } return m; }
static double freq (const std::vector<float>& x, double sr, size_t from)
{
    std::vector<double> t;
    for (size_t i = from + 1; i < x.size(); ++i) if (x[i - 1] < 0.f && x[i] >= 0.f) t.push_back ((double) (i - 1) + x[i - 1] / (x[i - 1] - x[i]));
    return t.size() < 3 ? 0 : sr * (double) (t.size() - 1) / (t.back() - t.front());
}

int main (int argc, char** argv)
{
    if (argc < 2) { printf ("usage: %s asr10_inst.so\n", argv[0]); return 2; }
    char dir[] = "/tmp/asr10_inst_XXXXXX";
    if (! mkdtemp (dir)) return 2;
    setenv ("ASR10_DISK_DIR", dir, 1);
    { Buf b = makeEfe ("TEST SINE"); char p[300]; snprintf (p, sizeof p, "%s/test sine.efe", dir); FILE* f = fopen (p, "wb"); fwrite (b.data(), 1, b.size(), f); fclose (f); }
    const char* iso = getenv ("ENS_REAL_ISO");
    if (iso) { char p[300]; snprintf (p, sizeof p, "%s/zz demo cd.iso", dir); if (symlink (iso, p) != 0) perror ("symlink"); }

    void* lib; AEffect* e = make (argv[1], lib);
    CHECK (e && e->magic == kEffectMagic, "plugin entry");
    if (! e) return 1;
    CHECK ((e->flags & effFlagsIsSynth) && e->numInputs == 0 && e->numOutputs == 2 && e->numParams == P_COUNT, "synth flags / io");
    CHECK (D (e, effGetPlugCategory) == kPlugCategSynth, "category synth");
    CHECK (D (e, effCanDo, 0, 0, (void*) "receiveVstMidiEvent") == 1, "canDo midi");
    D (e, effSetSampleRate, 0, 0, nullptr, 44100.f); D (e, effMainsChanged, 0, 1);

    // --- scan finds the file, it loads on the worker thread
    CHECK (waitFor (e, P_INST, "TEST SINE"), "instrument loads; INSTRUMENT shows '%s'", disp (e, P_INST).c_str());
    CHECK (disp (e, P_DISK) == "test sine.efe", "DISK shows '%s'", disp (e, P_DISK).c_str());
    CHECK (disp (e, P_INFO) == "1L 1WS RAW", "INFO shows '%s' (must say RAW)", disp (e, P_INFO).c_str());

    // --- notes: pitch of the tuned loop, through the MIDI path
    midi (e, 0, 0x90, 69, 100);
    std::vector<float> x = run (e, 32768);
    CHECK (peak (x) > 0.05 && peak (x) <= 1.0, "note on makes sound (peak %.3f)", peak (x));
    const double want = 4.0 * 29761.9 / 270.52, f0 = freq (x, 44100, 4096);
    CHECK (std::fabs (1200 * std::log2 (f0 / want)) < 4, "plays %.3f Hz, want %.3f", f0, want);
    midi (e, 0, 0x80, 69, 0);
    x = run (e, 44100);
    CHECK (peak (x, 40000) < 1e-4, "note off releases to silence (tail peak %.5f)", peak (x, 40000));

    // --- sample-accurate timing inside a block
    midi (e, 1000, 0x90, 69, 100);
    x = run (e, 2048, 2048);                      // one block: the event's deltaFrames must lie inside it
    CHECK (peak (x, 0, 1000) == 0.0 && peak (x, 1100) > 0.01, "note starts at frame 1000 (before: %.5f, after: %.3f)", peak (x, 0, 1000), peak (x, 1100));
    midi (e, 0, 0xB0, 123, 0); run (e, 4096);

    // --- sustain pedal, volume, all-notes-off
    midi (e, 0, 0xB0, 64, 127); midi (e, 0, 0x90, 60, 100); midi (e, 0, 0x80, 60, 0);
    x = run (e, 22050);
    CHECK (peak (x, 10000) > 0.05, "sustain pedal holds the released note (%.3f)", peak (x, 10000));
    midi (e, 0, 0xB0, 64, 0); run (e, 44100);
    e->setParameter (e, P_VOLUME, 0.f); run (e, 22050);
    midi (e, 0, 0x90, 64, 120); x = run (e, 8192);
    CHECK (peak (x, 4096) < 1e-4, "volume 0 is silent (%.6f)", peak (x, 4096));
    e->setParameter (e, P_VOLUME, 0.8f); midi (e, 0, 0xB0, 123, 0); run (e, 8192);

    // --- project chunk round trip into a second instance
    void* chunk = nullptr; const int n = (int) D (e, effGetChunk, 0, 0, &chunk);
    CHECK (n > 10 && chunk && strncmp ((char*) chunk, "ASRI1\n", 6) == 0 && strstr ((char*) chunk, "inst=TEST SINE"), "chunk text");
    e->setParameter (e, P_PATCH, 1.f); e->setParameter (e, P_VOICES, 1.f);
    void* lib2; AEffect* e2 = make (argv[1], lib2);
    D (e2, effSetSampleRate, 0, 0, nullptr, 44100.f);
    char saved[700]; memcpy (saved, chunk, (size_t) n + 1);
    D (e2, effSetChunk, 0, n, saved);
    CHECK (waitFor (e2, P_INST, "TEST SINE"), "restored project reselects the instrument (shows '%s')", disp (e2, P_INST).c_str());
    CHECK (std::fabs (e2->getParameter (e2, P_VOLUME) - 0.8f) < 0.01f, "volume restored");
    D (e2, effClose);

    // --- the real CD
    if (iso)
    {
        CHECK (waitNot (e, P_DISK, "NO DISKS"), "disks listed");
        e->setParameter (e, P_RESCAN, 1.f); e->setParameter (e, P_RESCAN, 0.f);
        usleep (300000);
        e->setParameter (e, P_DISK, 1.f);                                   // "zz demo cd.iso" sorts last
        CHECK (waitNot (e, P_INST, "TEST SINE"), "CD instruments load");
        const std::string first = disp (e, P_INST);
        e->setParameter (e, P_VOICES, 0.f); e->setParameter (e, P_PATCH, 0.f);
        int sounded = 0, tried = 0;
        for (int k = 0; k <= 580; k += 29)                                   // a spread of instruments across the whole CD
        {
            e->setParameter (e, P_INST, k / 580.f); usleep (20000);
            if (! waitNot (e, P_INST, "")) { CHECK (false, "instrument %d never finished loading", k); continue; }
            ++tried;
            midi (e, 0, 0x90, 60, 100); midi (e, 0, 0x90, 48, 100);
            x = run (e, 16384);
            if (peak (x) > 0.005) ++sounded;
            CHECK (peak (x) <= 1.0, "instrument %d output bounded (%.3f)", k, peak (x));
            midi (e, 0, 0xB0, 123, 0); run (e, 2048);
        }
        printf ("real CD through the plugin: first instrument '%s'; %d of %d sampled instruments sound\n", first.c_str(), sounded, tried);
        CHECK (sounded * 10 >= tried * 8, "at least 80%% of sampled instruments should sound on C3+C4 (%d of %d)", sounded, tried);
        e->setParameter (e, P_DISK, 1.f);
    }
    D (e, effClose);                                                          // joins the worker, frees everything
    dlclose (lib); dlclose (lib2);
    printf (fails ? "\n%d FAILURE(S)\n" : "\nALL INSTRUMENT PLUGIN TESTS PASSED\n", fails);
    return fails ? 1 : 0;
}
