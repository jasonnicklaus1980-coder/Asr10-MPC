// Tests for the instrument file parser (src/ensoniq/ens_instrument_file) and its hand-over to the sound engine.
//  1. a synthetic instrument written in the layout documented in docs/ENSONIQ_FORMATS.md section 3
//  2. fuzzing: truncated and corrupted files must fail cleanly or play safely
//  3. if ENS_REAL_ISO points at the ASR demo CD image: every instrument on it is parsed, played and measured
#include "../src/ensoniq/ens_instrument_file.h"
#include "../src/engine/ens_engine.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

using namespace ens;
static int failures = 0;
#define CHECK(c, ...) do { if (! (c)) { ++failures; printf ("FAIL %s:%d: ", __FILE__, __LINE__); printf (__VA_ARGS__); printf ("\n"); } } while (0)
static void freeInst (Instrument* i) { i->releaseAudio(); delete i; }

// ---------------------------------------------------------------- synthetic file writer ----------------------
typedef std::vector<uint8_t> Buf;
static void setSize (uint8_t* b, size_t bytes) { const size_t s = bytes / 16; b[0] = (uint8_t) s; b[2] = (uint8_t) (s >> 12); b[3] = (uint8_t) (((s >> 8) & 15) << 4); }
static void setId (uint8_t* b, int id) { b[4] = (uint8_t) ((id << 6) >> 8); b[5] = (uint8_t) ((id << 6) & 255); }
static void nameAt (uint8_t* b, size_t off, const char* s) { for (int k = 0; k < 12; ++k) b[off + 2 * k] = (uint8_t) (k < (int) strlen (s) ? s[k] : ' '); }
static void pos (uint8_t* b, int word, double v) { const uint32_t p = (uint32_t) llround (v * 512.0); for (int k = 0; k < 4; ++k) b[10 + 2 * (word + k)] = (uint8_t) (p >> (24 - 8 * k)); }

struct WsSpec { int number, copyOf; const char* name; int rateWord, loopMode, keyLo, keyHi, root, fine; double start, end, ls, le; std::vector<int16_t> data; };

static void addLayer (Buf& f, int n, const char* name, int velLo, int velHi, const int (*keymap)[88])
{
    const size_t o = f.size(); f.resize (o + 0xE0, 0);
    uint8_t* b = &f[o]; b[0] = 0x0e; b[4] = 0x06; setId (b, 24 + n); nameAt (b, 10, name);
    b[0x22 + 6] = (uint8_t) velLo; b[0x22 + 8] = (uint8_t) velHi;
    for (int k = 0; k < 88; ++k) b[0x30 + 2 * k] = (uint8_t) (*keymap)[k];
}
static void addWs (Buf& f, const WsSpec& w)
{
    const size_t bytes = 0x120 + (w.copyOf ? 0 : w.data.size() * 2);
    const size_t o = f.size(); f.resize (o + bytes, 0);
    uint8_t* b = &f[o]; setSize (b, bytes); setId (b, 33 + w.number);
    nameAt (b, 10, w.name);
    auto W = [&] (int k, int v) { b[10 + 2 * k] = (uint8_t) v; };
    W (12, w.copyOf); W (80, w.root); W (84, 13); W (86, w.fine); W (99, 100); W (105, 3); W (114, w.loopMode);
    pos (b, 115, w.start); pos (b, 119, w.end); pos (b, 123, w.ls); pos (b, 127, w.le);
    W (131, w.rateWord); W (132, w.keyLo); W (133, w.keyHi); W (134, 13); W (136, 6);
    if (! w.copyOf) for (size_t i = 0; i < w.data.size(); ++i) { b[0x120 + 2 * i] = (uint8_t) ((uint16_t) w.data[i] >> 8); b[0x121 + 2 * i] = (uint8_t) w.data[i]; }
}
static std::vector<int16_t> sine (double cycles, int frames, double amp = 0.5)   // `cycles` periods over the first `frames`
{
    std::vector<int16_t> v ((size_t) frames);
    for (int i = 0; i < frames; ++i) v[(size_t) i] = (int16_t) llround (amp * 32767.0 * sin (2 * M_PI * cycles * i / 270.52));
    return v;
}

// A scrambled-on-purpose instrument: effect block first, wavesamples not in number order, a copy, a pitch table.
static Buf makeInstrument()
{
    Buf f (0x290, 0);
    nameAt (f.data(), 0x0a, "TESTINST");
    f[0x2c] = 3; f[0x2e] = 1; f[0x30] = 2; f[0x32] = 3;
    { const size_t o = f.size(); f.resize (o + 0x680, 0); f[o] = 0x68; f[o + 4] = 0x28; f[o + 5] = 0x80; }     // effect

    static int km1[88], km2[88];
    for (int k = 0; k < 88; ++k) { km1[k] = (k + 21 < 60) ? 1 : 2; km2[k] = 3; }
    addLayer (f, 1, "SOFT LAYER", 0, 63, &km1);
    { WsSpec w { 2, 0, "RAMP", 1, 0, 60, 108, 72, 0, 0.0, 63.0, 0.0, 0.0, {} };
      for (int i = 0; i < 64; ++i) w.data.push_back ((int16_t) (i * 400 - 12000));
      addWs (f, w); }
    { WsSpec w { 1, 0, "SINE LOOP", 21, 2, 21, 59, 69, 0, 0.0, 280.0, 0.0, 270.52, sine (4, 288) };
      addWs (f, w); }
    { const size_t o = f.size(); f.resize (o + 0xE0, 0); f[o] = 0x0e; f[o + 4] = 0x04; setId (&f[o], 17); }    // pitch table
    addLayer (f, 2, "HARD LAYER", 64, 127, &km2);
    { WsSpec w { 3, 1, "SINE COPY", 0, 2, 21, 108, 57, 0, 0.0, 280.0, 0.0, 270.52, {} };
      addWs (f, w); }
    return f;
}

// ---------------------------------------------------------------- measuring --------------------------------
static std::vector<float> run (Engine& e, int frames)
{
    std::vector<float> L ((size_t) frames), R ((size_t) frames);
    for (int p = 0; p < frames; p += 256) e.render (&L[(size_t) p], &R[(size_t) p], std::min (256, frames - p));
    return L;
}
static double freqOf (const std::vector<float>& x, double sr, size_t from = 2048)
{
    std::vector<double> t;
    for (size_t i = from + 1; i < x.size(); ++i)
        if (x[i - 1] < 0.f && x[i] >= 0.f) t.push_back ((double) (i - 1) + x[i - 1] / (x[i - 1] - x[i]));
    if (t.size() < 3) return 0.0;
    return sr * (double) (t.size() - 1) / (t.back() - t.front());
}
// fundamental by normalised autocorrelation (zero crossings overcount waveforms with harmonics)
static double f0Of (const std::vector<float>& x, double sr, size_t from, size_t len)
{
    double e0 = 0; for (size_t i = from; i < from + len; ++i) e0 += (double) x[i] * x[i];
    std::vector<double> r;
    for (size_t lag = 20; lag < 3000; ++lag)
    {
        double s = 0; for (size_t i = from; i < from + len; ++i) s += (double) x[i] * x[i + lag];
        r.push_back (s / e0);
    }
    double mx = -1; for (double v : r) mx = std::max (mx, v);
    for (size_t k = 1; k + 1 < r.size(); ++k)
        if (r[k] >= 0.95 * mx && r[k] >= r[k - 1] && r[k] >= r[k + 1])
        {
            const double y0 = r[k - 1], y1 = r[k], y2 = r[k + 1];
            const double off = 0.5 * (y0 - y2) / (y0 - 2 * y1 + y2);       // parabolic interpolation of the peak
            return sr / ((double) (k + 20) + off);
        }
    return 0;
}
static double cents (double a, double b) { return 1200.0 * log2 (a / b); }
static bool sane (const std::vector<float>& x) { for (float v : x) if (! std::isfinite (v) || std::fabs (v) > 1.f) return false; return true; }

static void syntheticTests()
{
    const Buf f = makeInstrument();
    Instrument* in = new Instrument(); ParseInfo info; char err[160] {};
    CHECK (parseInstrument (f.data(), f.size(), *in, info, err, sizeof err), "synthetic parse: %s", err);
    CHECK (strcmp (in->name, "TESTINST") == 0, "name '%s'", in->name);
    CHECK (info.layers == 2 && info.wavesamples == 3 && info.copies == 1 && info.effectBlocks == 1 && info.pitchTables == 1 && info.unknownBlocks == 0,
           "counts: layers %d ws %d copies %d fx %d pt %d unknown %d", info.layers, info.wavesamples, info.copies, info.effectBlocks, info.pitchTables, info.unknownBlocks);
    CHECK (in->numLayers == 2 && in->numWs == 3, "numLayers %d numWs %d", in->numLayers, in->numWs);
    CHECK (in->layer[0].velLo == 0 && in->layer[0].velHi == 63 && in->layer[1].velLo == 64 && in->layer[1].velHi == 127, "velocity windows");
    CHECK (strcmp (in->layer[1].name, "HARD LAYER") == 0, "layer name '%s'", in->layer[1].name);
    const Layer& L1 = in->layer[0];
    CHECK (L1.hasKeyMap && L1.keyMap[21] == 1 && L1.keyMap[59] == 1 && L1.keyMap[60] == 2 && L1.keyMap[108] == 2, "key map edges");
    CHECK (L1.keyMap[5] == 1 && L1.keyMap[127] == 2, "keys outside 21..108 use the edge entries");
    CHECK (in->layer[1].keyMap[69] == 3, "layer 2 maps to wavesample 3");
    CHECK (in->patchSelectMask[0] == 3 && in->patchSelectMask[1] == 1 && in->patchSelectMask[2] == 2 && in->patchSelectMask[3] == 3, "patch select masks");
    const WaveSample& a = in->ws[0]; const WaveSample& r = in->ws[1]; const WaveSample& c = in->ws[2];
    CHECK (strcmp (a.name, "SINE LOOP") == 0 && strcmp (r.name, "RAMP") == 0, "ws names '%s' '%s'", a.name, r.name);
    CHECK (a.frames == 288 && a.data && a.data[100] == sine (4, 288)[100], "audio of wavesample 1 (frames %u)", a.frames);
    CHECK (c.data == a.data && c.frames == a.frames, "copy shares the original's audio");
    CHECK (r.frames == 64 && r.data && r.data[10] == 10 * 400 - 12000, "audio of wavesample 2");
    CHECK (a.loop == LOOP_FORWARD && std::fabs (a.loopEndF - 270.52) < 1.0 / 512 && a.loopStartF == 0.0, "fractional loop end %.4f", a.loopEndF);
    CHECK (a.loopEnd == 271 && a.end == 281, "loop end %u, end %u", a.loopEnd, a.end);
    CHECK (r.loop == LOOP_OFF_FORWARD && r.end == 64, "one-shot end %u", r.end);
    CHECK (a.rootKey == 69 && a.keyLo == 21 && a.keyHi == 59 && c.rootKey == 57, "root keys / ranges");
    CHECK (std::fabs (a.sampleRate - 29761.9f) < 0.5f && std::fabs (r.sampleRate - 44100.f) < 0.5f && std::fabs (c.sampleRate - 47619.05f) < 0.5f, "rates %.1f %.1f %.1f", a.sampleRate, r.sampleRate, c.sampleRate);
    CHECK (info.rateEstimated == 1 && info.rateUnknown == 0, "rate flags: estimated %d unknown %d", info.rateEstimated, info.rateUnknown);

    // played through the engine: pitch of the tuned loop, velocity layer switch, key split, copy
    Engine e; e.prepare (44100);
    e.setInstrument (in, freeInst);
    e.render (nullptr, nullptr, 0);
    const double want = 4.0 * 29761.9 / 270.52;                        // the loop holds 4 periods of its sine
    e.noteOn (59, 30);                                                   // soft layer, lower zone: wavesample 1, root 69
    double fr = freqOf (run (e, 16384), 44100);
    CHECK (std::fabs (cents (fr, want * pow (2.0, -10.0 / 12))) < 3, "tuned fractional loop plays at %.3f Hz, want %.3f", fr, want * pow (2.0, -10.0 / 12));
    e.allNotesOff(); run (e, 4096);
    e.noteOn (69, 100);                       // hard layer -> the copy (root 57): an octave up, plays the shared audio
    fr = freqOf (run (e, 16384), 44100);
    CHECK (std::fabs (cents (fr, want * 2 * 47619.05 / 29761.9)) < 3, "copy plays at %.3f Hz, want %.3f", fr, want * 2 * 47619.05 / 29761.9);
    e.allNotesOff(); run (e, 4096);
    e.noteOn (60, 30); run (e, 256);
    CHECK (e.activeVoices() == 1, "key 60 soft: ramp one-shot (%d voices)", e.activeVoices());
    run (e, 8192);
    CHECK (e.activeVoices() == 0, "one-shot ends on its own");
    printf ("synthetic instrument: parsed, key map / velocity layers / copy / fractional loop pitch (%.2f Hz) ok\n", fr);
    e.shutdown (freeInst);
}

static uint32_t rngState = 12345;
static uint32_t rnd() { rngState ^= rngState << 13; rngState ^= rngState >> 17; rngState ^= rngState << 5; return rngState; }

static void fuzzTests()
{
    const Buf good = makeInstrument();
    int refused = 0, accepted = 0;
    for (int t = 0; t < 600; ++t)
    {
        Buf f = good;
        if (t % 3 == 0) f.resize (rnd() % f.size());                                     // truncation
        else for (int k = 0, n = 1 + (int) (rnd() % 12); k < n; ++k) f[rnd() % f.size()] ^= (uint8_t) (1 << (rnd() % 8));
        Instrument* in = new Instrument(); ParseInfo info; char err[160] {};
        if (! parseInstrument (f.data(), f.size(), *in, info, err, sizeof err)) { ++refused; delete in; continue; }
        ++accepted;
        Engine e; e.prepare (44100); e.setInstrument (in, freeInst); e.render (nullptr, nullptr, 0);
        for (int k = 20; k < 110; k += 7) e.noteOn ((uint8_t) k, (uint8_t) (20 + rnd() % 100));
        CHECK (sane (run (e, 4096)), "fuzz %d: output not finite/bounded", t);
        e.shutdown (freeInst);
    }
    printf ("fuzz: 600 damaged files: %d refused with a message, %d parsed and played safely\n", refused, accepted);
}

// ---------------------------------------------------------------- real instruments --------------------------
struct Real { Volume* v; int found = 0, parsed = 0, failed = 0, silent = 0, unsafe = 0, ws = 0, copies = 0, missing = 0, badKm = 0, est = 0, unk = 0, fixes = 0, unknownBlocks = 0, fx = 0; };

static void walkDir (Real& R, uint32_t dirBlock, const char* path, int depth)
{
    Dir d; char err[160] {};
    if (depth > 8 || ! R.v->readDir (dirBlock, d, err, sizeof err)) return;
    for (int i = 0; i < d.n; ++i)
    {
        const Entry& en = d.e[i];
        char full[256]; snprintf (full, sizeof full, "%s/%s", path, en.name);
        if (en.type == FT_DIR) { walkDir (R, en.start, full, depth + 1); continue; }
        if (en.type != FT_INSTRUMENT) continue;
        ++R.found;
        Instrument* in = new Instrument(); ParseInfo info;
        if (! parseInstrumentEntry (*R.v, en, *in, info, err, sizeof err)) { ++R.failed; printf ("  not parsed: %s: %s\n", full, err); delete in; continue; }
        ++R.parsed; R.ws += info.wavesamples; R.copies += info.copies; R.missing += info.missingCopyRefs; R.badKm += info.badKeymapRefs;
        R.est += info.rateEstimated; R.unk += info.rateUnknown; R.fixes += info.sanitizeFixes; R.unknownBlocks += info.unknownBlocks; R.fx += info.effectBlocks;
        Engine e; e.prepare (44100); e.setInstrument (in, freeInst); e.render (nullptr, nullptr, 0);
        int played = 0;
        for (int l = 0; l < in->numLayers; ++l)
        {
            const Layer& L = in->layer[l];
            if (! L.enabled) continue;
            for (int k = 60; k < 128 + 60; ++k) { const int key = k % 128; if (L.keyMap[key]) { e.noteOn ((uint8_t) key, (uint8_t) ((L.velLo + L.velHi) / 2 ? (L.velLo + L.velHi) / 2 : 1)); ++played; break; }
        } }
        std::vector<float> x = run (e, 8192);
        double peak = 0; for (float v : x) peak = std::max (peak, (double) std::fabs (v));
        if (! sane (x)) { ++R.unsafe; printf ("  unsafe output: %s\n", full); }
        if (played && peak < 1e-3) ++R.silent;
        e.shutdown (freeInst);
    }
}

// pitch of a real tuned organ loop, played end to end (parse -> key map -> loop -> engine)
static void realPitch (Volume& v)
{
    Entry en; char err[160] {};
    if (! v.find ("DEMO SOUNDS1/DEMO SNDS 6/DML-ORGAN", en, err, sizeof err)) { printf ("(DML-ORGAN not found)\n"); return; }
    Instrument* in = new Instrument(); ParseInfo info;
    CHECK (parseInstrumentEntry (v, en, *in, info, err, sizeof err), "DML-ORGAN: %s", err);
    const WaveSample& w = in->ws[0];
    const double wantHz = w.sampleRate / ((w.loopEndF - w.loopStartF) / 2.0);       // two cycles per loop (verified by ear of the data)
    Engine e; e.prepare (44100); e.setInstrument (in, freeInst); e.render (nullptr, nullptr, 0);
    e.noteOn (w.rootKey, 100);
    const std::vector<float> x = run (e, 40000);
    const double fr = f0Of (x, 44100, 8192, 16384);
    const double rootHz = 440.0 * pow (2.0, (w.rootKey - 69) / 12.0);
    double off = std::fmod (cents (fr, rootHz) + 600.0 + 12000.0, 1200.0) - 600.0;      // modulo an octave: the loop holds two similar cycles
    CHECK (std::fabs (off) < 25, "DML-ORGAN at its root key %d: %.2f Hz, key is %.2f Hz (%.1f cents off, octave folded)", w.rootKey, fr, rootHz, off);
    printf ("real DML-ORGAN played at root key %d: %.2f Hz (key %.2f Hz, %+.1f cents modulo an octave; loop %.2f..%.2f at %.1f Hz)\n", w.rootKey, fr, rootHz, off, w.loopStartF, w.loopEndF, w.sampleRate);
    (void) wantHz;
    e.shutdown (freeInst);
}

int main()
{
    syntheticTests();
    fuzzTests();
    const char* iso = getenv ("ENS_REAL_ISO");
    if (! iso) printf ("(real instruments skipped: set ENS_REAL_ISO to the ASR demo CD image)\n");
    else
    {
        char err[160] {};
        Image img; Volume vol;
        CHECK (img.open (iso, err, sizeof err) && vol.open (img, err, sizeof err), "open %s: %s", iso, err);
        Real R; R.v = &vol;
        walkDir (R, 3, "", 0);
        printf ("real CD: %d instruments found, %d parsed, %d failed; %d wavesamples (%d copies), %d effect blocks, %d unidentified blocks\n",
                R.found, R.parsed, R.failed, R.ws, R.copies, R.fx, R.unknownBlocks);
        printf ("         missing copy sources %d, bad key map entries %d, rate estimated for %d, rate unknown for %d, bounds fixed %d times\n", R.missing, R.badKm, R.est, R.unk, R.fixes);
        printf ("         played every instrument: %d silent, %d unsafe\n", R.silent, R.unsafe);
        CHECK (R.found > 500 && R.failed == 0, "all real instruments must parse (%d of %d failed)", R.failed, R.found);
        CHECK (R.unsafe == 0, "no instrument may produce non-finite or out-of-range output");
        CHECK (R.silent * 50 <= R.parsed, "at most 2%% of instruments may play silent (%d of %d)", R.silent, R.parsed);
        realPitch (vol);
    }
    printf (failures ? "\n%d FAILURE(S)\n" : "\nALL INSTRUMENT TESTS PASSED\n", failures);
    return failures ? 1 : 0;
}
