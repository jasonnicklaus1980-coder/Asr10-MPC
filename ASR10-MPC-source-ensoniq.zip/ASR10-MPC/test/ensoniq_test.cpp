// Tests for the Ensoniq container and file system modules, on synthetic disks built here from the documented
// layout. They prove the code does what docs/ENSONIQ_FORMATS.md describes; they cannot prove the description
// matches real disks - that needs real ASR-10 / EPS-16+ images (see test/fixtures/README.md).
#include "../src/ensoniq/ens_bank.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>

using namespace ens;
static int failures = 0;
#define CHECK(c, ...) do { if (! (c)) { ++failures; printf ("FAIL %s:%d: ", __FILE__, __LINE__); printf (__VA_ARGS__); printf ("\n"); } } while (0)

// ---------------------------------------------------------------- synthetic disk -------------------------
struct Disk
{
    std::vector<uint8_t> d;
    uint32_t n;
    explicit Disk (uint32_t blocks) : d ((size_t) blocks * 512, 0), n (blocks) {}
    uint8_t* blk (uint32_t b) { return &d[(size_t) b * 512]; }
    void put16 (uint8_t* p, uint32_t v) { p[0] = (uint8_t) (v >> 8); p[1] = (uint8_t) v; }
    void put32 (uint8_t* p, uint32_t v) { p[0] = (uint8_t) (v >> 24); p[1] = (uint8_t) (v >> 16); p[2] = (uint8_t) (v >> 8); p[3] = (uint8_t) v; }
    void fat (uint32_t b, uint32_t next)
    {
        uint8_t* p = blk (5 + b / 170) + (b % 170) * 3;
        p[0] = (uint8_t) (next >> 16); p[1] = (uint8_t) (next >> 8); p[2] = (uint8_t) next;
    }
    void format()
    {
        for (size_t k = 0; k < d.size(); k += 2) { d[k] = 0x6D; d[k + 1] = 0xB6; }    // Ensoniq format fill
        const uint32_t fatBlocks0 = (n + 169) / 170;
        memset (blk (0), 0, (size_t) (5 + fatBlocks0) * 512);
        uint8_t* id = blk (1);
        memcpy (id + 31, "TESTDSK", 7);
        id[1] = 0x80; put16 (id + 4, 10); put16 (id + 6, 2); put16 (id + 8, 80); put16 (id + 10, 512);
        put32 (id + 14, n); id[18] = 0x1E; id[19] = 2; id[38] = 'I'; id[39] = 'D';
        uint8_t* os = blk (2); os[28] = 'O'; os[29] = 'S';
        blk (4)[510] = 'D'; blk (4)[511] = 'R';
        const uint32_t fatBlocks = (n + 169) / 170;
        for (uint32_t k = 0; k < fatBlocks; ++k) { blk (5 + k)[510] = 'F'; blk (5 + k)[511] = 'B'; }
        for (uint32_t b = 0; b < 5 + fatBlocks; ++b) fat (b, 1);
    }
    void dir (uint32_t first) { memset (blk (first), 0, 1024); blk (first + 1)[510] = 'D'; blk (first + 1)[511] = 'R'; }
    void entry (uint32_t dirBlock, int slot, uint8_t type, const char* name, uint32_t size, uint32_t start)
    {
        uint8_t* p = blk (dirBlock) + slot * 26;   // slots 0..18 fit in the first block (19*26 = 494)
        p[1] = type;
        memset (p + 2, ' ', 12); memcpy (p + 2, name, strlen (name));
        put16 (p + 14, size); put16 (p + 16, size); put32 (p + 18, start);
    }
    void chain (const std::vector<uint32_t>& blocks, uint8_t seed)
    {
        for (size_t i = 0; i < blocks.size(); ++i)
        {
            fat (blocks[i], i + 1 < blocks.size() ? blocks[i + 1] : 1);
            for (int k = 0; k < 512; ++k) blk (blocks[i])[k] = (uint8_t) (seed + i * 7 + k);
        }
    }
};

static Disk makeDisk()
{
    Disk dk (1600);
    dk.format();
    dk.entry (3, 0, FT_INSTRUMENT, "PIANO", 5, 20);
    dk.chain ({ 20, 21, 40, 41, 42 }, 11);                     // fragmented on purpose
    dk.entry (3, 1, FT_DIR, "DRUMS", 2, 30);
    dk.fat (30, 31); dk.fat (31, 1);
    dk.dir (30);
    dk.entry (30, 0, FT_PARENT, "", 0, 3);
    dk.entry (30, 1, FT_INSTRUMENT, "KIT 1", 3, 50);
    dk.chain ({ 50, 51, 52 }, 99);
    dk.entry (3, 2, FT_INSTRUMENT, "BROKEN", 4, 60);
    dk.chain ({ 60, 61 }, 5);                                  // FAT says 2 blocks, directory says 4
    return dk;
}

static bool writeFile (const char* path, const void* p, size_t n)
{
    FILE* f = fopen (path, "wb"); if (! f) return false;
    const bool ok = fwrite (p, 1, n, f) == n; fclose (f); return ok;
}

static void checkVolume (const Image& img, Disk& ref, const char* what)
{
    char err[160] {};
    Volume v;
    CHECK (v.open (img, err, sizeof err), "%s: open volume: %s", what, err);
    CHECK (v.hasId && v.hasOs && v.totalBlocks == 1600, "%s: ID/OS block (%d %d %u)", what, v.hasId, v.hasOs, v.totalBlocks);
    Dir root;
    CHECK (v.readRoot (root, err, sizeof err) && root.n == 3, "%s: root has %d entries: %s", what, root.n, err);
    Entry e; Bytes data;
    CHECK (v.find ("piano", e, err, sizeof err) && v.readFile (e, data, err, sizeof err), "%s: PIANO: %s", what, err);
    const uint32_t chainP[] { 20, 21, 40, 41, 42 };
    bool same = data.n == 5 * 512;
    for (int i = 0; same && i < 5; ++i) same = memcmp (data.p + i * 512, ref.blk (chainP[i]), 512) == 0;
    CHECK (same, "%s: PIANO content follows the fragmented FAT chain", what);
    data.release();
    CHECK (v.find ("DRUMS/KIT 1", e, err, sizeof err) && v.readFile (e, data, err, sizeof err) && data.n == 1536
           && memcmp (data.p, ref.blk (50), 1536) == 0, "%s: DRUMS/KIT 1 in a subdirectory: %s", what, err);
    data.release();
    CHECK (v.find ("BROKEN", e, err, sizeof err) && ! v.readFile (e, data, err, sizeof err) && strstr (err, "2 of 4"),
           "%s: short FAT chain is reported (%s)", what, err);
    CHECK (! v.find ("DRUMS/NOPE", e, err, sizeof err), "%s: missing file reported", what);
}

// ---------------------------------------------------------------- HFE writer (MFM) -----------------------
struct Mfm
{
    std::vector<uint8_t> cells; int prev = 0;
    void cell (int c) { cells.push_back ((uint8_t) c); }
    void byte (uint8_t v)
    {
        for (int b = 7; b >= 0; --b) { const int d = (v >> b) & 1; cell ((! prev && ! d) ? 1 : 0); cell (d); prev = d; }
    }
    void sync() { for (int b = 15; b >= 0; --b) cell ((0x4489 >> b) & 1); prev = 1; }
};

static std::vector<uint8_t> makeHfe (Disk& dk, int corruptTrack)
{
    const int tracks = 80, sides = 2, spt = 10, sideBytes = 12800;
    std::vector<uint8_t> f (1024 + (size_t) tracks * sideBytes * 2, 0);
    memcpy (&f[0], "HXCPICFE", 8); f[9] = tracks; f[10] = sides; f[11] = 0; f[12] = 250 & 255; f[13] = 0;
    f[14] = 300 & 255; f[15] = 300 >> 8; f[18] = 1; f[19] = 0;
    for (int t = 0; t < tracks; ++t)
    {
        const uint32_t off = 2 + (uint32_t) t * (sideBytes * 2 / 512), len = sideBytes * 2;
        f[512 + t * 4] = (uint8_t) off; f[513 + t * 4] = (uint8_t) (off >> 8);
        f[514 + t * 4] = (uint8_t) len; f[515 + t * 4] = (uint8_t) (len >> 8);
        for (int s = 0; s < sides; ++s)
        {
            Mfm m;
            for (int i = 0; i < 60; ++i) m.byte (0x4E);
            for (int r = 0; r < spt; ++r)
            {
                for (int i = 0; i < 12; ++i) m.byte (0);
                uint8_t id[10] { 0xA1, 0xA1, 0xA1, 0xFE, (uint8_t) t, (uint8_t) s, (uint8_t) r, 2 };
                const uint16_t c1 = crc16Ccitt (id, 8); id[8] = (uint8_t) (c1 >> 8); id[9] = (uint8_t) c1;
                m.sync(); m.sync(); m.sync();
                for (int i = 3; i < 10; ++i) m.byte (id[i]);
                for (int i = 0; i < 22; ++i) m.byte (0x4E);
                for (int i = 0; i < 12; ++i) m.byte (0);
                std::vector<uint8_t> ds (4 + 512 + 2);
                ds[0] = ds[1] = ds[2] = 0xA1; ds[3] = 0xFB;
                memcpy (&ds[4], dk.blk ((uint32_t) ((t * sides + s) * spt + r)), 512);
                const uint16_t c2 = crc16Ccitt (ds.data(), 516); ds[516] = (uint8_t) (c2 >> 8); ds[517] = (uint8_t) c2;
                if (t == corruptTrack && s == 0 && r == 3) ds[100] ^= 0x40;   // bad data CRC
                m.sync(); m.sync(); m.sync();
                for (size_t i = 3; i < ds.size(); ++i) m.byte (ds[i]);
                for (int i = 0; i < 40; ++i) m.byte (0x4E);
            }
            while (m.cells.size() < (size_t) sideBytes * 8) m.byte (0x4E);
            m.cells.resize ((size_t) sideBytes * 8);
            for (int k = 0; k < sideBytes; ++k)
            {
                uint8_t v = 0;
                for (int b = 0; b < 8; ++b) v |= (uint8_t) (m.cells[(size_t) k * 8 + b] << b);     // LSB first
                f[(size_t) off * 512 + (size_t) (k / 256) * 512 + (size_t) s * 256 + (size_t) (k % 256)] = v;
            }
        }
    }
    return f;
}

// ---------------------------------------------------------------- Giebler disk writer --------------------
// As EpsLin's ConvertFromImage: skip bitmap at 0xA0 (EDE), set bit = block free in the FAT, then a 0x1A byte.
static uint32_t fatOf (Disk& dk, uint32_t b)
{
    const uint8_t* p = dk.blk (5 + b / 170) + (b % 170) * 3;
    return ((uint32_t) p[0] << 16) | ((uint32_t) p[1] << 8) | p[2];
}
static std::vector<uint8_t> makeGiebler (Disk& dk)
{
    std::vector<uint8_t> f (512, 0x20);
    f[0] = 0x0D; f[1] = 0x0A; memcpy (&f[2], "EPS-16 Disk", 11); f[0x4E] = 0x0D; f[0x4F] = 0x0A;
    f[0xA0 - 3] = 0x0D; f[0xA0 - 2] = 0x0A; f[0xA0 - 1] = 0x1A; f[511] = 0x03;
    for (uint32_t b = 0; b < 1600; ++b)
    {
        if (b % 8 == 0) f[0xA0 + b / 8] = 0;
        if (fatOf (dk, b) == 0) f[0xA0 + b / 8] |= (uint8_t) (0x80 >> (b & 7));
    }
    for (uint32_t b = 0; b < 1600; ++b) if (fatOf (dk, b) != 0) f.insert (f.end(), dk.blk (b), dk.blk (b) + 512);
    f.push_back (0x1A);
    return f;
}

// ---------------------------------------------------------------- bank writer -------------------------------
static void bankRec (std::vector<uint8_t>& d, int j, size_t rec, int depth, const uint8_t* path, uint8_t slot, const char* label)
{
    uint8_t* r = &d[0x22 + (size_t) j * rec];
    r[0] = (uint8_t) depth; r[1] = 0xFF; r[2] = 0;
    for (int k = 0; k < 7; ++k) r[3 + 2 * k] = (uint8_t) label[k];
    for (int k = 0; k < depth; ++k) r[4 + 2 * k] = path[k];
    r[4 + 2 * depth] = slot;
}

static bool fileExists (const char* p) { FILE* f = fopen (p, "rb"); if (f) fclose (f); return f != nullptr; }

int main()
{
    char err[160] {};
    Disk dk = makeDisk();

    // raw image
    CHECK (writeFile ("/tmp/ens_test.img", dk.d.data(), dk.d.size()), "write img");
    Image raw;
    CHECK (raw.open ("/tmp/ens_test.img", err, sizeof err) && raw.kind == IMG_RAW, "raw open: %s", err);
    checkVolume (raw, dk, "raw");
    raw.close();

    // HFE, clean and with one bad sector
    std::vector<uint8_t> hfe = makeHfe (dk, -1);
    CHECK (writeFile ("/tmp/ens_test.hfe", hfe.data(), hfe.size()), "write hfe");
    Image h;
    CHECK (h.open ("/tmp/ens_test.hfe", err, sizeof err) && h.kind == IMG_HFE && h.numBlocks == 1600 && h.badSectors == 0,
           "hfe open: %s (%u blocks, %u bad)", err, h.numBlocks, h.badSectors);
    bool same = true; uint8_t b[512];
    for (uint32_t k = 0; k < 1600 && same; ++k) { h.read (k, b); same = memcmp (b, dk.blk (k), 512) == 0; }
    CHECK (same, "hfe: every block decodes to the original");
    checkVolume (h, dk, "hfe");
    h.close();
    hfe = makeHfe (dk, 4);
    writeFile ("/tmp/ens_test_bad.hfe", hfe.data(), hfe.size());
    CHECK (h.open ("/tmp/ens_test_bad.hfe", err, sizeof err) && h.badSectors == 1, "hfe with a bad CRC: %u bad (%s)", h.badSectors, err);
    h.close();
    memcpy (&hfe[0], "HXCHFEV3", 8);
    writeFile ("/tmp/ens_test_v3.hfe", hfe.data(), hfe.size());
    CHECK (! h.open ("/tmp/ens_test_v3.hfe", err, sizeof err) && strstr (err, "v3"), "HFE v3 is refused clearly (%s)", err);

    // Giebler disk image
    std::vector<uint8_t> g = makeGiebler (dk);
    writeFile ("/tmp/ens_test.ede", g.data(), g.size());
    Image gi;
    CHECK (gi.open ("/tmp/ens_test.ede", err, sizeof err) && gi.kind == IMG_GIEBLER_DISK, "giebler open: %s", err);
    printf ("giebler: %s\n", gi.note);
    same = gi.numBlocks == 1600;
    for (uint32_t k = 0; k < 1600 && same; ++k) { gi.read (k, b); same = memcmp (b, dk.blk (k), 512) == 0; }
    CHECK (same, "giebler: every block rebuilt, free blocks as 6D B6");
    checkVolume (gi, dk, "giebler");
    gi.close();
    // same image written by a Mac tool (every 0A -> 0D 0A) and without the extension
    std::vector<uint8_t> mac;
    for (size_t k = 0; k < g.size(); ++k) { if (g[k] == 0x0A) mac.push_back (0x0D); mac.push_back (g[k]); }
    // (the header's leading 0D 0A becomes 0D 0D 0A, which is how EpsLin detects such files)
    writeFile ("/tmp/ens_test_mac.ede", mac.data(), mac.size());
    CHECK (gi.open ("/tmp/ens_test_mac.ede", err, sizeof err) && strstr (gi.note, "Mac"), "Mac line endings undone: %s %s", err, gi.note);
    checkVolume (gi, dk, "giebler-mac");
    gi.close();

    // GKH (EpsLin's reading of it: "II", tags from 8, 0x0A geometry, 0x0B length/offset)
    std::vector<uint8_t> gk (58, 0);
    gk[0] = 'I'; gk[1] = 'I'; gk[4] = 'I'; gk[6] = 2;
    gk[8] = 0x0A; gk[10] = 80; gk[12] = 2; gk[14] = 10;
    gk[18] = 0x0B; gk[20] = 0x00; gk[21] = 0x80; gk[22] = 0x0C; gk[24] = 58;
    gk.insert (gk.end(), dk.d.begin(), dk.d.end());
    writeFile ("/tmp/ens_test.gkh", gk.data(), gk.size());
    Image gh;
    CHECK (gh.open ("/tmp/ens_test.gkh", err, sizeof err) && gh.kind == IMG_GKH && gh.numBlocks == 1600, "gkh: %s", err);
    checkVolume (gh, dk, "gkh");
    gh.close();

    // Giebler single file, header as EpsLin writes it
    std::vector<uint8_t> efe (512, 0);
    efe[0] = 0x0D; efe[1] = 0x0A; memcpy (&efe[2], "Eps File:       PIANO       Instr            ", 45);
    efe[47] = 0x0D; efe[48] = 0x0A; efe[49] = 0x1A; efe[0x32] = FT_INSTRUMENT; efe[0x35] = 2; efe[0x37] = 2;
    efe.insert (efe.end(), dk.blk (20), dk.blk (20) + 1024);
    writeFile ("/tmp/ens_test.efe", efe.data(), efe.size());
    GieblerFile gf;
    CHECK (gf.open ("/tmp/ens_test.efe", err, sizeof err) && gf.data.n == 1024 && gf.type == FT_INSTRUMENT
           && strcmp (gf.name, "PIANO") == 0 && gf.sizeBlocks == 2 && gf.sizeMatches, "efe: %s '%s'", err, gf.name);
    gf.release();

    // Bank: ASR-10 bank pointing at PIANO (root slot 0), DRUMS/KIT 1 (slot 1 -> slot 1), a copy, a deleted slot,
    // and one on another disk
    {
        std::vector<uint8_t> bk (4 * 512, 0);
        const char* nm = "MY BANK     ";
        for (int k = 0; k < 12; ++k) bk[0x08 + 2 * k] = (uint8_t) nm[k];
        bk[0x20] = 0x1F;
        const size_t rec = 28;
        bankRec (bk, 0, rec, 0, nullptr, 0, "TESTDSK");
        const uint8_t p1[] { 1 };
        bankRec (bk, 1, rec, 1, p1, 1, "TESTDSK");
        bk[0x22 + 2 * rec] = 0x80;                       // copy of instrument 1
        bk[0x22 + 3 * rec] = 0x7F;                       // deleted
        bankRec (bk, 4, rec, 0, nullptr, 0, "OTHER  ");
        for (int j = 5; j < 9; ++j) bk[0x22 + (size_t) j * rec] = 0x80;
        const char* fx = "HALL REVERB ";
        for (int k = 0; k < 12; ++k) bk[0x600 + 10 + 2 * k] = (uint8_t) fx[k];
        Bank bank;
        CHECK (bank.parse (bk.data(), bk.size(), FT_ASR_BANK, err, sizeof err), "bank parse: %s", err);
        CHECK (strcmp (bank.name, "MY BANK") == 0 && bank.mask == 0x1F && bank.hasEffect && strcmp (bank.effectName, "HALL REVERB") == 0,
               "bank header: '%s' mask %x fx '%s'", bank.name, bank.mask, bank.effectName);
        CHECK (bank.inst[2].kind == BankRef::COPY && bank.inst[2].copyOf == 1 && bank.inst[3].kind == BankRef::DELETED,
               "bank copy/deleted records");
        Image ri; Volume v; Entry e;
        ri.open ("/tmp/ens_test.img", err, sizeof err); v.open (ri, err, sizeof err);
        CHECK (strcmp (v.label, "TESTDSK") == 0, "disk label '%s'", v.label);
        CHECK (bank.resolve (v, bank.inst[0], e, err, sizeof err) && strcmp (e.name, "PIANO") == 0, "bank inst 1 -> PIANO: %s", err);
        CHECK (bank.resolve (v, bank.inst[1], e, err, sizeof err) && strcmp (e.name, "KIT 1") == 0, "bank inst 2 -> DRUMS/KIT 1: %s", err);
        CHECK (! bank.resolve (v, bank.inst[4], e, err, sizeof err) && strstr (err, "another disk"), "bank inst 5 elsewhere: %s", err);
        ri.close();
        std::vector<uint8_t> shortBank (100, 0);
        CHECK (! bank.parse (shortBank.data(), shortBank.size(), FT_ASR_BANK, err, sizeof err), "short bank refused");
    }

    // Real blank ASR-10 HD floppy as IMG and HFE (test/fixtures, not committed): both must read as the same
    // formatted, empty Ensoniq disk
    if (fileExists ("test/fixtures/ASRblank.img") && fileExists ("test/fixtures/ASRblank.hfe"))
    {
        Image ri, rh; Volume vi, vh; Dir di, dh;
        const bool oi = ri.open ("test/fixtures/ASRblank.img", err, sizeof err) && vi.open (ri, err, sizeof err) && vi.readRoot (di, err, sizeof err);
        CHECK (oi, "real blank IMG: %s", err);
        const bool oh = rh.open ("test/fixtures/ASRblank.hfe", err, sizeof err) && vh.open (rh, err, sizeof err) && vh.readRoot (dh, err, sizeof err);
        CHECK (oh, "real blank HFE: %s", err);
        if (oi && oh)
        {
            CHECK (ri.numBlocks == 3200 && rh.numBlocks == 3200 && rh.badSectors == 0, "3200 blocks each, HFE %u bad", rh.badSectors);
            CHECK (strcmp (vi.label, "DISK000") == 0 && vi.freeBlocks == 3176 && di.n == 0 && dh.n == 0,
                   "label '%s', %u free (ASR-10 manual: 3176), %d entries", vi.label, vi.freeBlocks, di.n);
            unsigned diff = 0; uint8_t x[512], y[512];
            for (uint32_t k = 0; k < 3200; ++k) { ri.read (k, x); rh.read (k, y); diff += memcmp (x, y, 512) != 0; }
            CHECK (diff == 0, "HFE decodes to the IMG block for block (%u differ)", diff);
            printf ("real blank ASR-10 floppy: IMG and HFE identical over 3200 blocks, label %s, %u free\n", vi.label, vi.freeBlocks);
        }
        ri.close(); rh.close();
    }
    else printf ("(skipped, not present: test/fixtures/ASRblank.img / .hfe)\n");

    // Real files, when present (test/fixtures is not committed): Ensoniq's own ASR-10 OS as a Giebler EFE
    const char* realOs[] { "test/fixtures/ASR353OS.efe", "test/fixtures/ASR161OS.efe", "test/fixtures/EPS16OS.efe" };
    for (const char* rp : realOs)
    {
        if (! fileExists (rp)) { printf ("(skipped, not present: %s)\n", rp); continue; }
        GieblerFile os;
        CHECK (os.open (rp, err, sizeof err) && os.sizeMatches, "%s: %s", rp, err);
        bool known; const char* tn = fileTypeName (os.type, &known);
        printf ("real file %s: name '%s', type %u (%s), %u blocks, header matches data: %s\n", rp, os.name, os.type, tn,
                os.sizeBlocks, os.sizeMatches ? "yes" : "NO");
        CHECK (known && (os.type == FT_ASR_OS || os.type == FT_E16_OS), "%s: OS type", rp);
        os.release();
    }
    CHECK (! raw.open ("/tmp/ens_test.efe", err, sizeof err) && strstr (err, "single-file"), "efe given as a disk is explained (%s)", err);


    // not Ensoniq at all
    std::vector<uint8_t> junk (1600 * 512, 0x55);
    writeFile ("/tmp/ens_junk.img", junk.data(), junk.size());
    CHECK (! raw.open ("/tmp/ens_junk.img", err, sizeof err), "junk refused");

    printf (failures ? "\n%d FAILURE(S)\n" : "\nALL ENSONIQ PARSER TESTS PASSED\n", failures);
    return failures ? 1 : 0;
}
