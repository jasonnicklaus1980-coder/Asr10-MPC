// Tests for the approximate effects (src/dsp/fx_approx.h). They check what can be checked without an ASR-10: that the
// effect named in an instrument maps to sensible algorithms, reverb times, echo timing, stability (nothing blows up
// or rings forever), bypass, and CPU cost. They do NOT show the effects sound like the hardware's.
#include "../src/dsp/fx_approx.h"
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace ens;
static int failures = 0;
#define CHECK(c, ...) do { if (! (c)) { ++failures; printf ("FAIL %s:%d: ", __FILE__, __LINE__); printf (__VA_ARGS__); printf ("\n"); } } while (0)

static std::vector<uint8_t> kinds (const char* name) { FxPlan p; fxPlanFromName (name, p); return std::vector<uint8_t> (p.kind, p.kind + p.n); }
static bool is (const char* name, std::initializer_list<uint8_t> k) { return kinds (name) == std::vector<uint8_t> (k); }

static void run (Fx& fx, std::vector<float>& L, std::vector<float>& R)
{
    for (size_t p = 0; p < L.size(); p += 256) fx.process (&L[p], &R[p], (int) std::min<size_t> (256, L.size() - p));
}
// RT60 from a Schroeder backward-integrated impulse response of the wet tail (fit between -5 and -35 dB, doubled)
static double rt60 (const std::vector<float>& x, double sr, size_t from)
{
    std::vector<double> e (x.size() + 1, 0.0);
    for (size_t i = x.size(); i-- > from;) e[i] = e[i + 1] + (double) x[i] * x[i];
    double t5 = -1, t35 = -1;
    for (size_t i = from; i < x.size(); ++i)
    {
        const double db = 10 * log10 (e[i] / e[from] + 1e-30);
        if (t5 < 0 && db <= -5) t5 = (double) i / sr;
        if (t35 < 0 && db <= -35) { t35 = (double) i / sr; break; }
    }
    return (t5 < 0 || t35 < 0) ? -1 : 2.0 * (t35 - t5);
}

int main()
{
    Fx* fx = new Fx();
    const float SR = 44100.f; fx->prepare (SR);

    // --- name -> effects, in the order they appear (kinds: 1 reverb 2 chorus 3 delay 4 phaser 5 trem 6 rotary 7 dist 8 comp 9 eq)
    CHECK (is ("HALL REVERB", { FX_REVERB }), "hall reverb");
    CHECK (is ("CHORUS+REVRB", { FX_CHORUS, FX_REVERB }), "chorus then reverb");
    CHECK (is ("CHOR+REV+DDL", { FX_CHORUS, FX_REVERB, FX_DELAY }), "chorus reverb delay");
    CHECK (is ("DDL+CHOR+REV", { FX_DELAY, FX_CHORUS, FX_REVERB }), "delay chorus reverb (order follows the name)");
    CHECK (is ("DUAL DELAYS", { FX_DELAY }), "dual delays");
    CHECK (is ("WURLIE--VERB", { FX_REVERB }) && is ("RUNNIN  VERB", { FX_REVERB }), "names ending in VERB are reverbs");
    CHECK (is ("GUITAR AMP1", {}) && is ("TRAVEL EFX", {}), "custom multi-effects are not guessed at");
    CHECK (is ("PHASER+REVRB", { FX_PHASER, FX_REVERB }), "phaser reverb");
    CHECK (is ("ROT.SPKR+REV", { FX_REVERB, FX_ROTARY }) || is ("ROT.SPKR+REV", { FX_ROTARY, FX_REVERB }), "rotary + reverb");
    CHECK (is ("EQ+CMPRESSOR", { FX_COMP, FX_EQ }) || is ("EQ+CMPRESSOR", { FX_EQ, FX_COMP }), "eq + compressor");
    CHECK (is ("DIST+CHO+REV", { FX_DIST, FX_CHORUS, FX_REVERB }) || is ("DIST+CHO+REV", { FX_CHORUS, FX_REVERB, FX_DIST }), "dist chorus reverb");
    CHECK (is ("31 VOICE 30K", {}) && is ("23 VOICE 44K", {}) && is ("", {}), "voice-count / empty names have no effect");
    CHECK (is ("EQ+TREM+DDL", { FX_TREM, FX_DELAY, FX_EQ }) || is ("EQ+TREM+DDL", { FX_EQ, FX_TREM, FX_DELAY }), "eq trem ddl");
    { FxPlan p; fxPlanFromName ("PARAM EQ", p); CHECK (p.implemented() == 0 && p.hasEq, "a lone EQ is not implemented and is flagged"); }
    { FxPlan h, r, l, s; fxPlanFromName ("HALL REVERB", h); fxPlanFromName ("ROOM REVERB", r); fxPlanFromName ("LARGE ROOM", l); fxPlanFromName ("SMALL ROOM", s);
      CHECK (h.reverbRt60 > l.reverbRt60 && l.reverbRt60 > r.reverbRt60 && r.reverbRt60 > s.reverbRt60, "reverb times ordered hall > large room > room > small room"); }
    printf ("names: parsed\n");

    // --- reverb decay time: measured against the target of each variant
    struct { const char* name; double want; } rv[] { { "HALL REVERB", 2.6 }, { "HOUSE REVERB", 1.5 }, { "ROOM REVERB", 0.9 }, { "SMALL ROOM", 0.5 } };
    double prev = 1e9;
    for (auto& c : rv)
    {
        fx->configure (c.name); fx->setLevel (1.f);
        std::vector<float> L ((size_t) (SR * 8), 0.f), R (L.size(), 0.f); L[0] = R[0] = 1.f;
        run (*fx, L, R);
        for (size_t i = 0; i < 64; ++i) { L[i] = 0; R[i] = 0; }                 // the dry impulse: the tail alone
        const double t = rt60 (L, SR, (size_t) (0.03 * SR));
        printf ("%-13s reverb time %.2f s (target %.2f)\n", c.name, t, c.want);
        CHECK (t > c.want * 0.65 && t < c.want * 1.35, "%s: %.2f s, target %.2f", c.name, t, c.want);
        CHECK (t < prev, "longer variants first"); prev = t;
    }

    // --- stability: full-scale noise through a long chain stays bounded; silence afterwards dies away
    fx->configure ("CHOR+REV+DDL"); fx->setLevel (2.f);
    { std::vector<float> L ((size_t) (SR * 10)), R (L.size()); unsigned s = 1;
      for (size_t i = 0; i < L.size(); ++i) { s = s * 1664525u + 1013904223u; L[i] = ((int) (s >> 8) / 8388608.f - 1.f); s = s * 1664525u + 1013904223u; R[i] = ((int) (s >> 8) / 8388608.f - 1.f); }
      run (*fx, L, R);
      double pk = 0; bool fin = true; for (size_t i = 0; i < L.size(); ++i) { pk = std::fmax (pk, std::fmax (std::fabs (L[i]), std::fabs (R[i]))); fin = fin && std::isfinite (L[i]) && std::isfinite (R[i]); }
      CHECK (fin && pk < 6.0, "full-scale noise stays bounded (peak %.2f)", pk);
      std::vector<float> a ((size_t) (SR * 25), 0.f), b (a.size(), 0.f); run (*fx, a, b);
      double tail = 0; for (size_t i = a.size() - 4410; i < a.size(); ++i) tail = std::fmax (tail, std::fmax (std::fabs (a[i]), std::fabs (b[i])));
      CHECK (tail < 1e-4, "tail dies away (peak %.6f after 25 s)", tail); printf ("stability: noise peak %.2f, tail after 25 s %.2g\n", pk, tail); }

    // --- echo timing of the delay
    fx->configure ("DUAL DELAYS"); fx->setLevel (1.f);
    { std::vector<float> L ((size_t) SR, 0.f), R (L.size(), 0.f); L[0] = R[0] = 1.f; run (*fx, L, R);
      size_t at = 0; float pk = 0; for (size_t i = 100; i < L.size(); ++i) if (std::fabs (L[i]) > pk) { pk = std::fabs (L[i]); at = i; }
      CHECK (std::llabs ((long long) at - (long long) (0.33 * SR)) <= 2, "first echo at %zu samples, want %d", at, (int) (0.33 * SR));
      CHECK (pk > 0.25f && pk < 0.4f, "echo level %.3f", pk); }

    // --- bypass at level 0, and effect-less names
    { const char* names[] { "HALL REVERB", "31 VOICE 30K" }; 
      for (int k = 0; k < 2; ++k) { fx->configure (names[k]); fx->setLevel (k == 0 ? 0.f : 1.f);
        std::vector<float> L (4096), R (4096), L0, R0; for (int i = 0; i < 4096; ++i) L[i] = R[i] = 0.5f * sinf (i * 0.05f); L0 = L; R0 = R; run (*fx, L, R);
        CHECK (L == L0 && R == R0, "%s: output unchanged (level %d)", names[k], k == 0 ? 0 : 1); } }

    // --- the other effects: bounded, and they do change the signal in the expected way
    { std::vector<float> in (44100); for (size_t i = 0; i < in.size(); ++i) in[i] = 0.5f * sinf (2 * 3.14159265f * 440.f * (float) i / SR);
      const char* names[] { "PHASER+REVRB", "DIST+CHO+REV", "EQ+CMPRESSOR", "EQ+TREM+DDL", "ROT.SPKR+REV" };
      for (const char* nm : names)
      { fx->configure (nm); fx->setLevel (1.f); std::vector<float> L = in, R = in; run (*fx, L, R);
        double pk = 0, diff = 0; bool fin = true; for (size_t i = 0; i < L.size(); ++i) { pk = std::fmax (pk, std::fabs (L[i])); diff += std::fabs (L[i] - in[i]); fin = fin && std::isfinite (L[i]); }
        CHECK (fin && pk < 3.0 && diff > 10.0, "%s: bounded (%.2f) and audible change (%.0f)", nm, pk, diff); }
      fx->configure ("TREMOLO"); fx->setLevel (1.f); std::vector<float> L = in, R = in; run (*fx, L, R);
      float mn = 9, mx = 0; for (size_t i = 4410; i < L.size(); i += 441) { float a = 0; for (size_t k = 0; k < 100; ++k) a = std::fmax (a, std::fabs (L[i + k])); mn = std::fmin (mn, a); mx = std::fmax (mx, a); }
      CHECK (mn < 0.75f * mx, "tremolo modulates the level (min %.2f max %.2f)", mn, mx);
      fx->configure ("EQ+CMPRESSOR"); std::vector<float> loud (44100), quiet (44100); for (size_t i = 0; i < loud.size(); ++i) { loud[i] = 0.9f * sinf (0.06f * i); quiet[i] = 0.03f * sinf (0.06f * i); }
      std::vector<float> l2 = loud, r2 = loud, l3 = quiet, r3 = quiet; run (*fx, l2, r2); fx->configure ("EQ+CMPRESSOR"); run (*fx, l3, r3);
      float pl = 0, pq = 0; for (size_t i = 20000; i < 44100; ++i) { pl = std::fmax (pl, std::fabs (l2[i])); pq = std::fmax (pq, std::fabs (l3[i])); }
      CHECK (pl / 0.9f < pq / 0.03f, "compressor reduces loud signals relative to quiet ones (%.2f vs %.2f)", pl / 0.9f, pq / 0.03f); }

    // --- CPU cost of a heavy chain
    fx->configure ("CHOR+REV+DDL"); fx->setLevel (1.f);
    { std::vector<float> L ((size_t) (SR * 10), 0.1f), R (L.size(), 0.1f);
      const auto t0 = std::chrono::steady_clock::now(); run (*fx, L, R);
      const double sec = std::chrono::duration<double> (std::chrono::steady_clock::now() - t0).count();
      printf ("CPU: chorus + reverb + delay, 10 s of audio in %.3f s (%.0fx realtime on this machine, -O%d)\n", sec, 10.0 / sec,
#ifdef __OPTIMIZE__
              2
#else
              0
#endif
              ); }
    delete fx;
    printf (failures ? "\n%d FAILURE(S)\n" : "\nALL FX TESTS PASSED\n", failures);
    return failures ? 1 : 0;
}
