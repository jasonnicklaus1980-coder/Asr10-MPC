// Tests for the sample playback engine (src/engine) on synthetic instruments. They check that the engine does
// what ens_instrument.h / ens_engine.h promise; how close that is to the hardware still needs recordings of a
// real ASR-10 playing the same instrument.
#include "../src/engine/ens_engine.h"
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <thread>
#include <vector>

using namespace ens;
static int failures = 0;
#define CHECK(c, ...) do { if (! (c)) { ++failures; printf ("FAIL %s:%d: ", __FILE__, __LINE__); printf (__VA_ARGS__); printf ("\n"); } } while (0)

static std::atomic<int> gFreed { 0 }, gMade { 0 };
static void freeInst (Instrument* i) { i->releaseAudio(); delete i; ++gFreed; }

// ---- building synthetic instruments ----
struct Builder
{
    Instrument* in = new Instrument();
    std::vector<std::vector<int16_t>> audio;
    Builder() { ++gMade; }
    int layer (uint8_t velLo = 0, uint8_t velHi = 127)
    {
        Layer& L = in->layer[in->numLayers]; L.velLo = velLo; L.velHi = velHi; L.firstWs = in->numWs; L.numWs = 0;
        return in->numLayers++;
    }
    WaveSample& ws (int layerIdx, std::vector<int16_t> data, float rate, uint8_t root, uint8_t lo = 0, uint8_t hi = 127)
    {
        WaveSample& w = in->ws[in->numWs++];
        in->layer[layerIdx].numWs++;
        audio.push_back (std::move (data));
        w.frames = (uint32_t) audio.back().size(); w.end = w.frames; w.sampleRate = rate; w.rootKey = root;
        w.keyLo = lo; w.keyHi = hi;
        w.ampEnv.time[0] = 0.f; w.ampEnv.release = 0.005f;
        w.fc1 = 20000.f; w.fc2 = 20.f; w.filterMode = 0;
        return w;
    }
    Instrument* done()
    {
        size_t total = 0; for (auto& a : audio) total += a.size();
        in->allocAudio (total);
        size_t off = 0;
        for (int i = 0; i < in->numWs; ++i)
        {
            memcpy (in->audio + off, audio[(size_t) i].data(), audio[(size_t) i].size() * 2);
            in->ws[i].data = in->audio + off; off += audio[(size_t) i].size();
        }
        return in;
    }
};
static std::vector<int16_t> sine (double hz, double rate, int frames, double amp = 0.5)
{
    std::vector<int16_t> v ((size_t) frames);
    for (int i = 0; i < frames; ++i) v[(size_t) i] = (int16_t) std::lround (amp * 32767.0 * std::sin (2 * M_PI * hz * i / rate));
    return v;
}

// ---- measuring ----
static std::vector<float> run (Engine& e, int frames, std::vector<float>* right = nullptr)
{
    std::vector<float> L ((size_t) frames), R ((size_t) frames);
    for (int p = 0; p < frames; p += 256) e.render (&L[(size_t) p], &R[(size_t) p], std::min (256, frames - p));
    if (right) *right = R;
    return L;
}
static double freqOf (const std::vector<float>& x, double sr, size_t from = 2048)
{
    std::vector<double> t;
    for (size_t i = from + 1; i < x.size(); ++i)
        if (x[i - 1] < 0.f && x[i] >= 0.f) t.push_back ((double) (i - 1) + x[i - 1] / (x[i - 1] - x[i]));
    if (t.size() < 3) return 0.0;
    return sr * (double) (t.size() - 1) / (t.back() - t.front());
}
static double rms (const std::vector<float>& x, size_t a, size_t b)
{
    double s = 0; for (size_t i = a; i < b && i < x.size(); ++i) s += (double) x[i] * x[i];
    return std::sqrt (s / (double) (b - a));
}
static double goertzelDb (const std::vector<float>& x, double hz, double sr, size_t from)
{
    const double w = 2 * M_PI * hz / sr, c = 2 * std::cos (w);
    double s1 = 0, s2 = 0; size_t n = 0;
    for (size_t i = from; i < x.size(); ++i, ++n) { const double s = x[i] + c * s1 - s2; s2 = s1; s1 = s; }
    const double p = s1 * s1 + s2 * s2 - c * s1 * s2;
    return 10 * std::log10 (p / ((double) n * n / 4) + 1e-30);
}
static double cents (double a, double b) { return 1200.0 * std::log2 (a / b); }

int main()
{
    const double k30 = 29761.9;
    for (float host : { 44100.f, 48000.f })
    {
        // 1. pitch: a 440 Hz sine recorded at 30k on A4, played across the keyboard, with fine tune and bend
        Engine e; e.prepare (host);
        Builder b; int l = b.layer();
        WaveSample& w = b.ws (l, sine (440, k30, 30000), (float) k30, 69);
        w.loop = LOOP_FORWARD; w.loopStart = 0;
        w.loopEnd = (uint32_t) std::lround (k30 / 440.0 * 400);             // 400 whole cycles
        e.setInstrument (b.done(), freeInst);
        struct { int key; float fine, bend; double want; } cases[] {
            { 69, 0, 0, 440 }, { 81, 0, 0, 880 }, { 57, 0, 0, 220 }, { 76, 0, 0, 440 * std::pow (2, 7 / 12.0) },
            { 69, 50, 0, 440 * std::pow (2, 50 / 1200.0) }, { 69, 0, 1, 440 * std::pow (2, 2 / 12.0) } };
        for (auto& c : cases)
        {
            e.render (nullptr, nullptr, 0);                                   // swap the instrument in
            const_cast<WaveSample&> (e.current()->ws[0]).fineCents = c.fine;
            e.pitchBend (c.bend);
            e.noteOn ((uint8_t) c.key, 100);
            const double f = freqOf (run (e, 16384), host);
            CHECK (std::fabs (cents (f, c.want)) < 3, "%.0f Hz host, key %d fine %.0f bend %.0f: %.2f Hz, want %.2f", host, c.key, c.fine, c.bend, f, c.want);
            e.noteOff ((uint8_t) c.key); run (e, 2048); e.pitchBend (0);
        }
        printf ("pitch at %.0f Hz host: 6 cases within 3 cents\n", host);
        e.shutdown (freeInst);
    }

    {   // 2. key split and 3. velocity layers
        Engine e; e.prepare (44100);
        Builder b;                                // a layer's wavesamples are added right after the layer
        int soft = b.layer (0, 63);
        auto& lo = b.ws (soft, sine (300, k30, 20000), (float) k30, 60, 0, 59);    lo.loop = LOOP_FORWARD; lo.loopEnd = (uint32_t) std::lround (k30 / 300 * 150);
        auto& hi = b.ws (soft, sine (500, k30, 20000), (float) k30, 60, 60, 127);  hi.loop = LOOP_FORWARD; hi.loopEnd = (uint32_t) std::lround (k30 / 500 * 250);
        int hard = b.layer (64, 127);
        auto& hv = b.ws (hard, sine (700, k30, 20000), (float) k30, 60);           hv.loop = LOOP_FORWARD; hv.loopEnd = (uint32_t) std::lround (k30 / 700 * 350);
        e.setInstrument (b.done(), freeInst);
        e.render (nullptr, nullptr, 0);
        e.noteOn (60, 40); double f = freqOf (run (e, 8192), 44100); e.noteOff (60); run (e, 2048);
        CHECK (std::fabs (cents (f, 500)) < 3, "key 60 soft -> upper zone 500 Hz: %.1f", f);
        e.noteOn (59, 40); f = freqOf (run (e, 8192), 44100); e.noteOff (59); run (e, 2048);
        CHECK (std::fabs (cents (f, 300 * std::pow (2, -1 / 12.0))) < 3, "key 59 soft -> lower zone: %.1f", f);
        e.noteOn (60, 100); f = freqOf (run (e, 8192), 44100); e.noteOff (60); run (e, 2048);
        CHECK (std::fabs (cents (f, 700)) < 3, "velocity 100 -> hard layer 700 Hz: %.1f", f);
        printf ("key split and velocity layers: ok\n");

        // 16. patch select: layer 2 (hard) off in patch-select position 1
        const_cast<Instrument*> (e.current())->patchSelectMask[1] = 0x01;
        e.patchSelect (1); e.noteOn (60, 100); run (e, 1024);
        CHECK (e.activeVoices() == 0, "patch select mutes the hard layer: %d voices", e.activeVoices());
        e.patchSelect (0); e.allNotesOff(); run (e, 2048);
        e.shutdown (freeInst);
    }

    {   // 4-7. loop modes on a rising ramp (so direction is visible)
        auto ramp = [] (int n) { std::vector<int16_t> v ((size_t) n); for (int i = 0; i < n; ++i) v[(size_t) i] = (int16_t) (-16000 + 32000.0 * i / n); return v; };
        const int N = 4410;                                                    // 0.1 s at 44.1 kHz, played at 44.1
        for (int mode = 0; mode < 5; ++mode)
        {
            Engine e; e.prepare (44100);
            Builder b; int l = b.layer();
            auto& w = b.ws (l, ramp (N), 44100.f, 60);
            w.loop = (LoopMode) mode; w.loopStart = 1000; w.loopEnd = 3000;
            w.ampEnv.release = 2.0f;                                           // long release: the loop mode decides
            e.setInstrument (b.done(), freeInst);
            e.render (nullptr, nullptr, 0);
            e.noteOn (60, 127);
            std::vector<float> x = run (e, 22050);                             // held 0.5 s
            const bool alive = e.activeVoices() == 1;
            double maxJump = 0; for (size_t i = 2; i < 8000; ++i) maxJump = std::max (maxJump, (double) std::fabs (x[i] - x[i - 1]));
            e.noteOff (60);
            std::vector<float> y = run (e, 22050);
            const bool aliveAfter = e.activeVoices() == 1;
            switch (mode)
            {
                case LOOP_OFF_FORWARD:
                    CHECK (! alive && x[100] < x[3000], "one-shot forward: rises, stops at the end (alive %d)", alive); break;
                case LOOP_OFF_BACKWARD:
                    CHECK (! alive && x[100] > x[3000], "one-shot backward: falls (plays reversed), stops"); break;
                case LOOP_FORWARD:
                    // wrap jump = 2000/4410 of a 32000 ramp, x 0.5 headroom x 0.707 centre pan = 0.157
                    CHECK (alive && aliveAfter && maxJump > 0.1, "loop forward: sustains, saw jump at the wrap (%.2f), keeps looping in release", maxJump); break;
                case LOOP_BIDIRECTIONAL:
                    CHECK (alive && maxJump < 0.01, "loop bidirectional: sustains with no jump (triangle), max step %.4f", maxJump); break;
                case LOOP_RELEASE:
                    CHECK (alive && ! aliveAfter, "loop+release: loops while held, then plays out and stops before the 2 s release ends"); break;
            }
            e.shutdown (freeInst);
        }
        printf ("loop modes: 5 checked\n");
    }

    {   // 8. envelope: velocity chooses between soft and hard levels; attack time; release
        Engine e; e.prepare (44100);
        Builder b; int l = b.layer();
        auto& w = b.ws (l, sine (440, 44100, 44100), 44100.f, 60);
        w.loop = LOOP_FORWARD; w.loopEnd = 44100;
        for (int i = 0; i < 5; ++i) { w.ampEnv.softLevel[i] = i == 0 ? 0.f : 0.2f; w.ampEnv.hardLevel[i] = i == 0 ? 0.f : 1.f; }
        w.ampEnv.time[0] = 0.1f; w.ampEnv.release = 0.1f;
        e.setInstrument (b.done(), freeInst);
        e.render (nullptr, nullptr, 0);
        e.noteOn (60, 1);   std::vector<float> s = run (e, 22050); e.noteOff (60); run (e, 8820);
        e.noteOn (60, 127); std::vector<float> h = run (e, 22050);
        const double ratio = rms (s, 11025, 22050) / rms (h, 11025, 22050);
        CHECK (std::fabs (ratio - (0.2 + 0.8 / 127)) < 0.02, "velocity 1 vs 127 sustain ratio %.3f", ratio);
        CHECK (rms (h, 0, 1100) < 0.5 * rms (h, 3300, 4400), "attack ramps up over 0.1 s");
        e.noteOff (60); std::vector<float> r = run (e, 8820);
        CHECK (rms (r, 6000, 8820) < 1e-4 && e.activeVoices() == 0, "release reaches 0 and frees the voice");
        printf ("envelope: velocity ratio %.3f, attack and release ok\n", ratio);
        e.shutdown (freeInst);
    }

    {   // 9. polyphony per mode, stealing the oldest
        for (EngineMode m : { MODE_ASR10, MODE_EPS16 })
        {
            Engine e; e.prepare (44100); e.setMode (m);
            Builder b; int l = b.layer();
            auto& w = b.ws (l, sine (440, 44100, 44100), 44100.f, 60); w.loop = LOOP_FORWARD; w.loopEnd = 44100;
            e.setInstrument (b.done(), freeInst);
            e.render (nullptr, nullptr, 0);
            for (int k = 30; k < 70; ++k) e.noteOn ((uint8_t) k, 100);
            run (e, 256);
            CHECK (e.activeVoices() == voicesFor (m), "%s: %d voices, want %d", m == MODE_ASR10 ? "ASR-10" : "EPS-16+", e.activeVoices(), voicesFor (m));
            e.shutdown (freeInst);
        }
        printf ("polyphony: ASR-10 31, EPS-16+ 20\n");
    }

    {   // 10. aliasing like the chip: a 9 kHz tone at 30k played 19 semitones up (27 kHz) folds to 17.1 kHz
        Engine e; e.prepare (44100);
        Builder b; int l = b.layer();
        auto& w = b.ws (l, sine (9000, k30, 60000, 0.9), (float) k30, 60); w.loop = LOOP_FORWARD; w.loopEnd = 60000;
        e.setInstrument (b.done(), freeInst);
        e.render (nullptr, nullptr, 0);
        e.noteOn (79, 127);
        std::vector<float> x = run (e, 16384);
        const double f = 9000 * std::pow (2, 19 / 12.0), alias = 44100 - f;
        const double a = goertzelDb (x, alias, 44100, 1024), ref = goertzelDb (x, 1000, 44100, 1024);
        CHECK (a > -20 && a - ref > 40, "alias at %.0f Hz: %.1f dB (1 kHz: %.1f dB)", alias, a, ref);
        printf ("aliasing: %.0f Hz tone folds to %.0f Hz at %.1f dB (no band-limiting, as OTTO)\n", f, alias, a);
        e.shutdown (freeInst);
    }

    {   // 11. 16-bit DAC and 12. filter
        Engine e; e.prepare (44100);
        Builder b; int l = b.layer();
        auto& q = b.ws (l, sine (1000, 44100, 44100, 0.00005), 44100.f, 60, 0, 59); q.loop = LOOP_FORWARD; q.loopEnd = 44100;
        auto& f4 = b.ws (l, sine (4000, 44100, 44100, 0.5), 44100.f, 60, 60, 60);  f4.loop = LOOP_FORWARD; f4.loopEnd = 44100;
        f4.filterMode = 3; f4.fc1 = 1000; f4.fc2 = 20000;
        auto& f2 = b.ws (l, sine (200, 44100, 44100, 0.5), 44100.f, 61, 61, 61);   f2.loop = LOOP_FORWARD; f2.loopEnd = 44100;
        f2.filterMode = 3; f2.fc1 = 1000; f2.fc2 = 20000;
        e.setInstrument (b.done(), freeInst);
        e.render (nullptr, nullptr, 0);
        e.noteOn (40, 127); std::vector<float> x = run (e, 8192); e.allNotesOff(); run (e, 4096);
        std::vector<float> lv; for (size_t i = 1024; i < x.size(); ++i) { bool seen = false; for (float v : lv) seen |= v == x[i]; if (! seen) lv.push_back (x[i]); }
        CHECK (lv.size() <= 3, "16-bit output: a -86 dB sine gives %zu levels", lv.size());
        e.noteOn (60, 127); const double r4 = rms (run (e, 8192), 4096, 8192); e.allNotesOff(); run (e, 4096);
        e.noteOn (61, 127); const double r2 = rms (run (e, 8192), 4096, 8192); e.allNotesOff(); run (e, 4096);
        const double cut = 20 * std::log10 (r4 / r2);
        CHECK (cut < -30, "4-pole low-pass at 1 kHz: 4 kHz is %.1f dB below 200 Hz", cut);
        printf ("16-bit DAC: %zu levels; OTTO LP3/LP1 at 1 kHz: 4 kHz %.1f dB\n", lv.size(), cut);
        e.shutdown (freeInst);
    }

    {   // 13-15. note-off layers, mono layers, sustain pedal
        Engine e; e.prepare (44100);
        Builder b;
        int main_ = b.layer();
        auto& a = b.ws (main_, sine (440, 44100, 44100), 44100.f, 60, 0, 59); a.loop = LOOP_FORWARD; a.loopEnd = 44100;
        int rel = b.layer();
        b.in->layer[rel].triggerOnRelease = true;
        b.ws (rel, sine (880, 44100, 4410), 44100.f, 60, 0, 59);                                  // short one-shot
        int mono = b.layer();
        b.in->layer[mono].mono = true;
        auto& m = b.ws (mono, sine (220, 44100, 44100), 44100.f, 60, 60, 127); m.loop = LOOP_FORWARD; m.loopEnd = 44100;
        e.setInstrument (b.done(), freeInst);
        e.render (nullptr, nullptr, 0);
        e.noteOn (50, 100); run (e, 512);
        CHECK (e.activeVoices() == 1, "note-off layer silent while the key is down (%d voices)", e.activeVoices());
        e.noteOff (50); run (e, 64);
        CHECK (e.activeVoices() == 2, "key up starts the note-off layer (%d voices)", e.activeVoices());
        run (e, 22050);
        CHECK (e.activeVoices() == 0, "both end");
        e.noteOn (70, 100); e.noteOn (72, 100); e.noteOn (74, 100); run (e, 256);
        CHECK (e.activeVoices() == 1, "mono layer keeps one voice (%d)", e.activeVoices());
        e.allNotesOff(); run (e, 4096);
        e.sustain (true); e.noteOn (40, 100); e.noteOff (40); run (e, 64);
        CHECK (e.activeVoices() == 2, "key up with the pedal down: held note + note-off layer (%d)", e.activeVoices());
        run (e, 22050);
        CHECK (e.activeVoices() == 1, "0.5 s later the pedal still holds the note, the note-off layer has ended (%d)", e.activeVoices());
        e.sustain (false); run (e, 22050);
        CHECK (e.activeVoices() == 0, "pedal up releases (%d)", e.activeVoices());
        printf ("note-off layers, mono layers, sustain pedal: ok\n");
        e.shutdown (freeInst);
    }

    {   // sanitize: broken ranges from a damaged file never make the engine read outside its data
        Builder b; int l = b.layer();
        auto& w = b.ws (l, sine (440, 44100, 1000), 44100.f, 60);
        w.end = 50000; w.loopStart = 900; w.loopEnd = 70000; w.loop = LOOP_BIDIRECTIONAL; w.keyLo = 90; w.keyHi = 10;
        b.in->layer[l].numWs = 40;
        Instrument* in = b.done();
        const int fixes = in->sanitize();
        CHECK (fixes >= 4 && in->ws[0].end == 1000 && in->ws[0].loopEnd == 1000 && in->layer[0].numWs == 1, "sanitize fixed %d things", fixes);
        Engine e; e.prepare (44100); e.setInstrument (in, freeInst); e.render (nullptr, nullptr, 0);
        for (int k = 0; k < 128; k += 3) e.noteOn ((uint8_t) k, 100);
        std::vector<float> x = run (e, 44100);
        bool finite = true; for (float v : x) finite &= std::isfinite (v) && std::fabs (v) <= 1.f;
        CHECK (finite, "output finite and bounded");
        e.shutdown (freeInst);
    }

    {   // hand-over under load: a loader thread swaps instruments while the audio thread plays
        gFreed = 0; gMade = 0;
        Engine e; e.prepare (44100);
        std::atomic<bool> stop { false };
        std::thread audio ([&] {
            std::vector<float> L (128), R (128);
            int k = 0;
            while (! stop) { e.noteOn ((uint8_t) (40 + (k++ % 40)), 100); e.render (L.data(), R.data(), 128); }
        });
        for (int i = 0; i < 2000; ++i)
        {
            Builder b; int l = b.layer();
            auto& w = b.ws (l, sine (220 + i % 500, 44100, 2000), 44100.f, 60); w.loop = LOOP_FORWARD; w.loopEnd = 2000;
            e.setInstrument (i % 97 == 0 ? (freeInst (b.done()), nullptr) : b.done(), freeInst);
            if (i % 7 == 0) std::this_thread::yield();
        }
        stop = true; audio.join();
        e.shutdown (freeInst);
        CHECK (gFreed == gMade, "every instrument freed exactly once: made %d, freed %d", gMade.load(), gFreed.load());
        printf ("hand-over: %d instruments swapped under load, all freed once\n", gMade.load());
    }

    {   // CPU: all 31 voices, filters moving, 10 s of audio
        Engine e; e.prepare (44100);
        Builder b; int l = b.layer();
        auto& w = b.ws (l, sine (440, k30, 60000), (float) k30, 60); w.loop = LOOP_FORWARD; w.loopEnd = 60000;
        w.filterMode = 1; w.fc1 = 3000; w.fc2 = 200; w.fc1EnvOct = 2; w.lfoPitchCents = 20;
        e.setInstrument (b.done(), freeInst); e.render (nullptr, nullptr, 0);
        for (int k = 40; k < 71; ++k) e.noteOn ((uint8_t) k, 100);
        std::vector<float> L (256), R (256);
        const auto t0 = std::chrono::steady_clock::now();
        for (int i = 0; i < 44100 * 10 / 256; ++i) e.render (L.data(), R.data(), 256);
        const double s = std::chrono::duration<double> (std::chrono::steady_clock::now() - t0).count();
        printf ("CPU: 31 voices, 10 s of audio in %.3f s (%.0fx realtime on this machine)\n", s, 10.0 / s);
        e.shutdown (freeInst);
    }

    printf (failures ? "\n%d FAILURE(S)\n" : "\nALL ENGINE TESTS PASSED\n", failures);
    return failures ? 1 : 0;
}
